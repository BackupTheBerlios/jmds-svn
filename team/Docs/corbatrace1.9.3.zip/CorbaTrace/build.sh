#! /bin/bash
export ANT_HOME=/tmp/jakarta-ant-1.5.1
export JAVA_HOME=/usr/local/opt/LANGAGES/JAVA/jdk1.4.0
export ORB_HOME=/usr/local/opt/CORBA/ORBACUS/JOB-4.1.2
export PATH=${ANT_HOME}/bin:${JAVA_HOME}/bin:${ORB_HOME}/bin:${PATH}
export CLASSPATH=${CLASSPATH}:${ORB_HOME}/lib/OB.jar

