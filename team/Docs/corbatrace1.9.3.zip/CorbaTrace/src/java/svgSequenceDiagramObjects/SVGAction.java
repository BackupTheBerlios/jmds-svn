package svgSequenceDiagramObjects;

import org.w3c.dom.*;


/**
 * SVGAction generates an action on the SVG Sequence Diagram.
 *
 * @author FRANCHETEAU Aurelien
 */

public class SVGAction extends SVGSequenceDiagramObject{

    private String length;

    public SVGAction(String x,String y,String length){
	super(x,y);
	this.length = length;
    }
    
    //===========================================================
    // Access Methods
    //===========================================================

    public String getLength(){
	return length;
    }
    public void setLength(String length){
	this.length = length;
    }
    /** creates a SVG Action child of the Element svgRoot in the Document doc in svgNS namespace. 
     */
    public void createSVGAction(String svgNS,Document doc,Element svgRoot){
	Element rectangle = doc.createElementNS(svgNS, "rect");
	rectangle.setAttributeNS(null, "x", x);
	rectangle.setAttributeNS(null, "y", y);
        rectangle.setAttributeNS(null, "width","10");
        rectangle.setAttributeNS(null, "height",length);
	rectangle.setAttributeNS(null, "style", "fill:white;stroke:black");
	svgRoot.appendChild(rectangle);
    }
}
