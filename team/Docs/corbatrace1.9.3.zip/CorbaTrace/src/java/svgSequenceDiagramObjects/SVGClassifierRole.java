package  svgSequenceDiagramObjects;

import org.w3c.dom.*;

/**
 * SVGClasssifierRole is an abstract class for Classifier Role(Instance,Concurrent Object,User).
 *
 * @author FRANCHETEAU Aurelien
 */

public class SVGClassifierRole extends SVGSequenceDiagramObject{

    protected String svgNS;
    protected Document document;
    protected Element element;
    //x1 and y1 are the co-ordinates of the started point of the time axis
    protected Integer x1; 
    protected Integer y1;
    //lenght of time axis
    protected int length;
    //height of the classifierRole
    protected Integer height;
    //width of the classifierRole
    protected Integer width;

    /** Constructor takes the names of the instance and of the class.
     *  x and y are the co-ordinates of the point which locates the instance on the SVG sequence diagram.
     *  The fird and fourth parameters are the height and width of the classifier role.
     */
    
    public SVGClassifierRole(String x,String y,String height,String width){
	super(x,y);
	x1 = new Integer(0);
	y1 = new Integer(0);
	length = 0;
	Integer h = new Integer(height);
	Integer w = new Integer(width);
	this.height = h;
	this.width = w;
	svgNS = null;
	document = null;
	element = null;

    }
     //===========================================================
    // Access Methods
    //===========================================================

    public Integer getX1(){
	return x1;
    } 
    public Integer getY1(){
	return y1;
    }
    public int getWidth(){
	return width.intValue();
    }
    public int getHeight(){
	return height.intValue();
    } 
    /** return the length of the time axis of the classifier role
     */
    public int getLength(){
	return length  ;
    }

    /**return the y coordinate of the last point of the time axis
     */
    public int getYLength(){
	return((this.getHeight())+(this.getLength()));
    }

    /** creates the time axis of the classifierRole with its length.  
    */
    public void addTimeAxis(String length){
	this.length = (new Integer(length)).intValue();
	Integer y2 = new Integer((y1.intValue())+((new Integer(length)).intValue()));
	SVGDashedLine svgDL = new SVGDashedLine(x1.toString(),y1.toString(),x1.toString(),y2.toString());
	svgDL.createSVGDashedLine(svgNS,document,element);
    }
    
    /** creates an action on the time axis of the classifierRole with its length and startY (y start of the action from the begining of the time axis).  
     */
    public void addAction(String startY,String length){
	Integer startX = new Integer((x1.intValue())-5);
	Integer absoluteStartY = new Integer((y1.intValue())+((new Integer(startY)).intValue()));
	SVGAction svgA = new SVGAction(startX.toString(),absoluteStartY.toString(),length);
	svgA.createSVGAction(svgNS,document,element);
    }
 /** creates an asynchronous message from ClassifierRole c1 to ClassifierRole c2, from yC1 to yC2(y co-ordinates from the begining of the c1 time axis and c2 time axis ) with the text txt.
  */
    public void addAsynchronousMessage(SVGClassifierRole c2,String yC1,String yC2,String txt){
	Integer xC1 = new Integer(0);
	Integer xC2 = new Integer(0);
	if((x1.intValue())<=((c2.getX1()).intValue())){
	    xC1 = new Integer((x1.intValue())+5);
	    xC2 =  new Integer(((c2.getX1()).intValue())-5);
	}
	else{
	    xC1 = new Integer((x1.intValue())-5);
	    xC2 =  new Integer(((c2.getX1()).intValue())+5);
	}
	Integer absoluteStartYC1 = new Integer((y1.intValue())+((new Integer(yC1)).intValue()));
	Integer absoluteStartYC2 = new Integer(((c2.getY1()).intValue())+((new Integer(yC2)).intValue()));
        SVGAsynchronousCommunication svgAC = new SVGAsynchronousCommunication(xC1.toString(),absoluteStartYC1.toString(),xC2.toString(),absoluteStartYC2.toString(),txt);
	svgAC.createSVGAsynchronousCommunication(svgNS,document,element);
	    
	}
/** creates a procedure call message or other flow of control from ClassifierRole c1 to ClassifierRole c2, from yC1 to yC2(y co-ordinates from the begining of the c1 time axis and c2 time axis ) with the text txt.
  */
    public void addProcedureCallMessage(SVGClassifierRole c2,String yC1,String yC2,String txt){
	Integer xC1 = new Integer(0);
	Integer xC2 = new Integer(0);
	if((x1.intValue())<=((c2.getX1()).intValue())){
	    xC1 = new Integer((x1.intValue())+5);
	    xC2 =  new Integer(((c2.getX1()).intValue())-5);
	}
	else{
	    xC1 = new Integer((x1.intValue())-5);
	    xC2 =  new Integer(((c2.getX1()).intValue())+5);
	}
	Integer absoluteStartYC1 = new Integer((y1.intValue())+((new Integer(yC1)).intValue()));
	Integer absoluteStartYC2 = new Integer(((c2.getY1()).intValue())+((new Integer(yC2)).intValue()));
        SVGProcedureCall svgPC = new SVGProcedureCall(xC1.toString(),absoluteStartYC1.toString(),xC2.toString(),absoluteStartYC2.toString(),txt);
	svgPC.createSVGProcedureCall(svgNS,document,element);
	    
	}	
/** creates a return from procedure call message from ClassifierRole c1 to ClassifierRole c2, from yC1 to yC2(y co-ordinates from the begining of the c1 time axis and c2 time axis ).
  */
    public void addReturnFromProcedureCallMessage(SVGClassifierRole c2,String yC1,String yC2){
	Integer xC1 = new Integer(0);
	Integer xC2 = new Integer(0);
	if((x1.intValue())<=((c2.getX1()).intValue())){
	    xC1 = new Integer((x1.intValue())+5);
	    xC2 =  new Integer(((c2.getX1()).intValue())-5);
	}
	else{
	    xC1 = new Integer((x1.intValue())-5);
	    xC2 =  new Integer(((c2.getX1()).intValue())+5);
	}
	Integer absoluteStartYC1 = new Integer((y1.intValue())+((new Integer(yC1)).intValue()));
	Integer absoluteStartYC2 = new Integer(((c2.getY1()).intValue())+((new Integer(yC2)).intValue()));
        SVGReturnFromProcedureCall svgRFPC = new SVGReturnFromProcedureCall(xC1.toString(),absoluteStartYC1.toString(),xC2.toString(),absoluteStartYC2.toString());
	svgRFPC.createSVGReturnFromProcedureCall(svgNS,document,element);
	    
    }
    /**creates a message which is stopped before its delivery. The first parameter is the length which the message stop, the second one, the time when it was sent. The third is the direction(right or left).
     */
    public void addAbortMessage(String end,String time,String direction){

	Integer yC1 = new Integer(time);
	Integer xC1 = new Integer(0);
	Integer x2 = new Integer(0);

	if(direction.compareTo("right")==0){
	    xC1 = new Integer((x1.intValue())+5);
	    x2 = new Integer((xC1.intValue())+((new Integer(end)).intValue()));
	}
	else{
	    xC1 = new Integer((x1.intValue())-5);
	    x2 = new Integer((xC1.intValue())-((new Integer(end)).intValue()));
	}
       	Integer absoluteStartYC1 = new Integer((y1.intValue())+((new Integer(time)).intValue()));

        SVGFilledLine svgFL = new SVGFilledLine(xC1.toString(),absoluteStartYC1.toString(),x2.toString(),absoluteStartYC1.toString());
	svgFL.createSVGFilledLine(svgNS,document,element);
	
	SVGCross svgC = new SVGCross(x2.toString(),absoluteStartYC1.toString());
	svgC.createSVGCross(svgNS,document,element);
    }
 /**creates a return message which is stopped before its delivery. The first parameter is the length which the message stop, the second one, the time when it was sent. The third is the direction(right or left).
     */
    public void addAbortReturnMessage(String end,String time,String direction){

	Integer yC1 = new Integer(time);
	Integer xC1 = new Integer(0);
	Integer x2 = new Integer(0);

	if(direction.compareTo("right")==0){
	    xC1 = new Integer((x1.intValue())+5);
	    x2 = new Integer((xC1.intValue())+((new Integer(end)).intValue()));
	}
	else{
	    xC1 = new Integer((x1.intValue())-5);
	    x2 = new Integer((xC1.intValue())-((new Integer(end)).intValue()));
	}
       	Integer absoluteStartYC1 = new Integer((y1.intValue())+((new Integer(time)).intValue()));

        SVGDashedLine svgFL = new SVGDashedLine(xC1.toString(),absoluteStartYC1.toString(),x2.toString(),absoluteStartYC1.toString());
	svgFL.createSVGDashedLine(svgNS,document,element);
	
	SVGCross svgC = new SVGCross(x2.toString(),absoluteStartYC1.toString());
	svgC.createSVGCross(svgNS,document,element);
    }

    /**creates a comment on the time axis. The first parameter is the length of the link between time axis and comment, the second one, the time. The third is the direction(right or left) of the comment in comparison with the time axis.
     */
    public void addComment(String end,String time,String direction,String text){

	Integer yC1 = new Integer(time);
	Integer xC1 = new Integer(0);
	Integer x2 = new Integer(0);

	if((direction.compareTo("left")==0)||(direction.compareTo("left-center")==0)){
	    xC1 = new Integer((x1.intValue())-5);
	    x2 = new Integer((xC1.intValue())-((new Integer(end)).intValue()));
	}
	else{
	    xC1 = new Integer((x1.intValue())+5);
	    x2 = new Integer((xC1.intValue())+((new Integer(end)).intValue()));
	}
       	Integer absoluteStartYC1 = new Integer((y1.intValue())+((new Integer(time)).intValue()));
	Integer absoluteEndYC1;
	
	if((direction.compareTo("left-center") == 0) ||(direction.compareTo("right-center") == 0)) 
	    absoluteEndYC1 = new Integer((y1.intValue())+((new Integer(time)).intValue()));
	else 
	    absoluteEndYC1 = new Integer((y1.intValue())+((new Integer(time)).intValue()-25));

        SVGDashedLine svgDL = new SVGDashedLine(xC1.toString(),absoluteStartYC1.toString(),x2.toString(),absoluteEndYC1.toString());
	svgDL.createSVGDashedLine(svgNS,document,element);
	
	SVGComment svgC = new SVGComment(x2.toString(),(new Integer(absoluteEndYC1.intValue()-8)).toString(),text);
	svgC.createSVGComment(svgNS,document,element,direction);
    }
    /** creates a cross(at the co-ordinate yCross) which symbolises the end of the object.
     */
    public void addCross(String yCross){
	Integer absoluteYCross = new Integer((y1.intValue())+((new Integer(yCross)).intValue()));
        SVGCross svgC = new SVGCross(x1.toString(),absoluteYCross.toString());
	svgC.createSVGCross(svgNS,document,element);
    }	
}
