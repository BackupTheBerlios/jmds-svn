package svgSequenceDiagramObjects;

import org.w3c.dom.*;


/**
 * SVGCross generates a cross on the svg sequence diagram.
 *
 * @author FRANCHETEAU Aurelien
 */

public class SVGCross extends SVGSequenceDiagramObject{


    /** Constructor takes x and y are the co-ordinates of the point which 
     *locates the cross on the sequence diagram.
     */
    
    public SVGCross(String x,String y){
	super(x,y);	
    }
    

    
   
    /** creates  svgcross(the child of svgRoot) in the document doc. 
     */
    public void createSVGCross(String svgNS,Document doc,Element svgRoot){
	
	Integer point1X = new Integer(((new Integer(x)).intValue())-8);
	Integer point1Y = new Integer(((new Integer(y)).intValue())-8);
	Integer point2X = new Integer(((new Integer(x)).intValue())+8);
	Integer point3Y = new Integer(((new Integer(y)).intValue())+10);
		
	Element cross = doc.createElementNS(svgNS,"path");
	cross.setAttributeNS(null,"d","M "+point1X.toString()+" "+point1Y.toString()+" L "+point2X.toString()+" "+point3Y.toString()+" M "+point2X.toString()+" "+point1Y.toString()+" L "+point1X.toString()+" "+point3Y.toString() );
	cross.setAttributeNS(null,"fill","none");
	cross.setAttributeNS(null,"stroke","black");
	cross.setAttributeNS(null,"stroke-width","3");
	
	svgRoot.appendChild(cross);
    }
}
