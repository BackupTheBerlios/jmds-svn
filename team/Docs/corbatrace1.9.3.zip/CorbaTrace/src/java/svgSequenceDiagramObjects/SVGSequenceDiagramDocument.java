package svgSequenceDiagramObjects;

import org.w3c.dom.*;
import java.util.Vector;
import java.math.BigDecimal;



/**
 * The SVGSequenceDiagramDocument  class creates the root Element of the SVG Document and initializes the time scale, the maxinmun time of the SVGSequenDiagram and the number of actors presant on the diagram. The goal of this class is to provide time scale and optimize the size of the diagram in comparaison of the size of the frame. 
 * To create a diagram with pixel unit, do not use this class. 
 * 
 * @author FRANCHETEAU Aurelien
 */

public class SVGSequenceDiagramDocument{

    private String svgNS;
    private Document doc;
    private Element svgRoot;
    private String width;
    private String height;
    private String margin;
    //endWidth is the latest x coordinate
    private int endWidth;
    //endHeight is the latest y coordinate
    private int endHeight;
    //G element of the doc
    private Element g;
    //vector of all classifier role
    private Vector classifierRole;
    //interval between classifierRole on the diagram
    private String interval;

    
    

    /** Constructor takes the svg namespace, the svg document and the root element of the document. TimeUnit parameter is the time unit("s" for second,"ms" millisecond...). MaxTime parameter is the maximun duration of the diagram. Its time unit must be the same of the parameter Time Unit. ActorNumber is the number of actors which appear on the diagram. 
     */
    
    public SVGSequenceDiagramDocument(String svgNS,Document doc,Element svgRoot){
    
	this.svgNS = svgNS;
	this.doc = doc;
	this.svgRoot = svgRoot;
	width = "700";
	height = "500";
	margin = "10";
	endWidth = (new Integer(margin)).intValue();
	endHeight = (new Integer(margin)).intValue();
	interval = "50";
	classifierRole = new Vector();
	createGElement();
	createMarkers();
    }
    
    //===========================================================
    // Access Methods
    //===========================================================

     
    public String getSvgNS(){
	return svgNS;
    } 
    public Document getDocument(){
	return doc;
    }
    public Element getSvgRoot(){
	return svgRoot;
    }
      public String getWidth(){
	return width;
    } 
     public String getHeight(){
	return height;
    }
    public String getMargin(){
	return margin;
    }
    public String getInterval(){
	return interval;
    }

    /** Methode createSVGFrame creates the frame of the document. Parameters are the width and the height of the frame. 
    */
    
    public void createSVGFrame(String width,String height){
	this.height = height;
	this.width = width;
	svgRoot.setAttributeNS(null, "width", width);
	svgRoot.setAttributeNS(null, "height", height);
    }
    /** Methode createSVGFrame creates the frame of the document. Parameters are the width and the height of the frame. The third one is the margin of the document(bottom,top left and right). 
    */
    
    public void createSVGFrame(String width,String height,String margin){
	this.height = height;
	this.width = width;
	svgRoot.setAttributeNS(null, "width", width);
	svgRoot.setAttributeNS(null, "height", height);
	endWidth = (new Integer(margin)).intValue();
	endHeight = (new Integer(margin)).intValue();
    }
    /** Methode createSVGFrame creates the frame of the document. Parameters are the width and the height of the frame. The third one is the margin of the document(bottom,top left and right).Parameter interval is space between two classifier role on the diagram. 
    */
    
    public void createSVGFrame(String width,String height,String margin,String interval){
	this.height = height;
	this.width = width;
	svgRoot.setAttributeNS(null, "width", width);
	svgRoot.setAttributeNS(null, "height", height);
	endWidth = (new Integer(margin)).intValue();
	endHeight = (new Integer(margin)).intValue();
	this.interval = interval; 
    }
    /** Methode createSVGFrame without parameters, creates the frame of the document with the size 700 * 500 and the margin 10.*/
    
     public void createSVGFrame(){
	svgRoot.setAttributeNS(null, "width", width);
	svgRoot.setAttributeNS(null, "height", height);
    }
    
    // Methode which add a g element to svgRoot to provide scale

     private void createGElement(){
	g = doc.createElementNS(svgNS,"g");
	g.setAttributeNS(null, "transform","scale(1)");
	svgRoot.appendChild(g);
	
    }

    // Methode which create marker for arrowhead
    private void createMarkers(){
	 //marker definition for asynchronous communication 
	 Element definition1 = doc.createElementNS(svgNS,"defs");
	 //Arrow
	 Element marker1 = doc.createElementNS(svgNS,"marker");
	 marker1.setAttributeNS(null,"id","svgAsynchronousCommunicationArrowhead");
	 marker1.setAttributeNS(null,"viewBox","0 0 50 50");
	 marker1.setAttributeNS(null,"refX","0");
	 marker1.setAttributeNS(null,"refY","25");
	 marker1.setAttributeNS(null,"markerUnits","strokeWidth");
	 marker1.setAttributeNS(null,"markerWidth","15");
	 marker1.setAttributeNS(null,"markerHeight","12");
	 marker1.setAttributeNS(null,"orient","auto");
	 Element markerPath1 = doc.createElementNS(svgNS,"path");
	 markerPath1.setAttributeNS(null,"d","M 0 0 L 50 25 L 0 25 L 50 25 L 0 50");
	 markerPath1.setAttributeNS(null,"fill","none");
	 markerPath1.setAttributeNS(null,"stroke","black");
	 markerPath1.setAttributeNS(null,"stroke-width","4");
	 marker1.appendChild(markerPath1);
	 definition1.appendChild(marker1);
	 g.appendChild(definition1);
	  
	 //marker definition for procedure call
	 Element definition2 = doc.createElementNS(svgNS,"defs");
	 //Arrow
	 Element marker2 = doc.createElementNS(svgNS,"marker");
	 marker2.setAttributeNS(null,"id","svgProcedureCallArrowhead");
	 marker2.setAttributeNS(null,"viewBox","0 0 50 50");
	 marker2.setAttributeNS(null,"refX","0");
	 marker2.setAttributeNS(null,"refY","25");
	 marker2.setAttributeNS(null,"markerUnits","strokeWidth");
	 marker2.setAttributeNS(null,"markerWidth","15");
	 marker2.setAttributeNS(null,"markerHeight","12");
	 marker2.setAttributeNS(null,"orient","auto");
	 Element markerPath2 = doc.createElementNS(svgNS,"path");
	 markerPath2.setAttributeNS(null,"d","M 0 0 L 50 25 L 0 25 L 50 25 L 0 50 z");
	 markerPath2.setAttributeNS(null,"fill","black");
	 markerPath2.setAttributeNS(null,"stroke","black");
	 markerPath2.setAttributeNS(null,"stroke-width","3");
	 marker2.appendChild(markerPath2);
	 definition2.appendChild(marker2);
	 g.appendChild(definition2);
	 
	 //marker definition for return from procedure call
	 Element definition3 = doc.createElementNS(svgNS,"defs");
	 //Arrow
	 Element marker3 = doc.createElementNS(svgNS,"marker");
	 marker3.setAttributeNS(null,"id","svgReturnFromProcedureCallArrowhead");
	 marker3.setAttributeNS(null,"viewBox","0 0 50 50");
	 marker3.setAttributeNS(null,"refX","0");
	 marker3.setAttributeNS(null,"refY","25");
	 marker3.setAttributeNS(null,"markerUnits","strokeWidth");
	 marker3.setAttributeNS(null,"markerWidth","15");
	 marker3.setAttributeNS(null,"markerHeight","12");
	 marker3.setAttributeNS(null,"orient","auto");
	 Element markerPath3 = doc.createElementNS(svgNS,"path");
	 markerPath3.setAttributeNS(null,"d","M 0 0 L 50 25 L 0 25 L 50 25 L 0 50");
	 markerPath3.setAttributeNS(null,"fill","none");
	 markerPath3.setAttributeNS(null,"stroke","black");
	 markerPath3.setAttributeNS(null,"stroke-width","4");
	 marker3.appendChild(markerPath3);
	 definition3.appendChild(marker3);
	 g.appendChild(definition3);
    }
    // Methode which calculate the maximun time of the diagram
    private int maxTime(){
	int timeMax = 0;
	for(int i = 0;i<classifierRole.size();i++){
	    

	    if(timeMax < (((SVGClassifierRole)(classifierRole.elementAt(i))).getYLength())+(new Integer(((SVGClassifierRole)(classifierRole.elementAt(i))).getY()).intValue()))
		//	timeMax = ((SVGClassifierRole)(classifierRole.elementAt(i))).getYLength();
		timeMax =  (((SVGClassifierRole)(classifierRole.elementAt(i))).getYLength())+(new Integer(((SVGClassifierRole)(classifierRole.elementAt(i))).getY()).intValue());
	}
    return timeMax;
    }

    /** Methode which calculate global scale to enlarge the document horizontally and vertically in the frame.
	This methode must be called at the end of the construction of the document.
    */
    public void calculateScale(){
	int w = (new Integer(width)).intValue();
	int h = (new Integer(height)).intValue();
	int m = (new Integer(margin)).intValue();
	endHeight = endHeight+maxTime();

	BigDecimal scale1 = new BigDecimal(w);
	BigDecimal den1 = new BigDecimal(endWidth+m);
	scale1 = scale1.divide(den1,2,BigDecimal.ROUND_DOWN);
	
	BigDecimal scale2 = new BigDecimal(h);
	BigDecimal den2 = new BigDecimal(endHeight+m);
	scale2 = scale2.divide(den2,2,BigDecimal.ROUND_DOWN);
	
	String scaleAt = "scale("+(scale1.min(scale2)).toString()+")";
        //add new scale
	
	g.removeAttributeNS(null,"transform");
	g.setAttributeNS(null, "transform",scaleAt);	
	
    }
    
    /** Methode which calculate horizontal scale to enlarge the document horizontally in the frame.
	This methode must be called at the end of the construction of the document.
     */
    public void calculateHScale(){
	int w = (new Integer(width)).intValue();
	int m = (new Integer(margin)).intValue();

	BigDecimal scaleH = new BigDecimal(w);
	BigDecimal den = new BigDecimal(endWidth+m);
	scaleH = scaleH.divide(den,2,BigDecimal.ROUND_DOWN);
	
	String scaleAt = "scale("+scaleH.toString()+" 1)";
        //add new scale
	
	g.removeAttributeNS(null,"transform");
	g.setAttributeNS(null, "transform",scaleAt);
    }


    /** Methode addInstance add an instance actor on the document with its name and class.  
    */
    public SVGInstance addInstance(String instanceName,String className ){
	
	if(!(classifierRole.isEmpty()))
	    endWidth = endWidth + ((new Integer(interval)).intValue());

	String x = (new Integer(endWidth)).toString();
	String y = (new Integer(margin)).toString();
	SVGInstance instance = new SVGInstance(x,y,instanceName,className);
	instance.createSVGInstance(svgNS,doc,g);
	endWidth = endWidth + instance.getWidth();

	classifierRole.addElement(instance);
	
	return instance;
	
    } 
/** Methode addUser add a user with its name on the document.  
    */
    public SVGUser addUser(String name){
	
	if(!(classifierRole.isEmpty()))
	    endWidth = endWidth + ((new Integer(interval)).intValue());

	String x = (new Integer(endWidth)).toString();
	String y = (new Integer(margin)).toString();
	SVGUser user = new SVGUser(x,y,name);
	user.createSVGUser(svgNS,doc,g);
	endWidth = endWidth + user.getWidth();

	classifierRole.addElement(user);
	
	return user;
	
    } 
    /** Methode addConcurrentObject add a concurrent object with its name on the document.  
    */
    public SVGConcurrentObject addConcurrentObject(String name){

	if(!(classifierRole.isEmpty()))
	    endWidth = endWidth + ((new Integer(interval)).intValue());

	String x = (new Integer(endWidth)).toString();
	String y = (new Integer(margin)).toString();
	SVGConcurrentObject concurrentObject = new SVGConcurrentObject(x,y,name);
	concurrentObject.createSVGConcurrentObject(svgNS,doc,g);
	endWidth = endWidth + concurrentObject.getWidth();

	classifierRole.addElement(concurrentObject);

	return concurrentObject;
	
    } 

     /** Methode createInstance create an instance from another classifier role and return the new instance.First parameter is the message. cr is the classifierRole which creates the new one. time is the time where the new object appears. instanceName and className are the name and the class of the new instance. 
    */
    public SVGInstance createInstance(String message,SVGClassifierRole cr,String time,String instanceName,String className){
	
	if(!(classifierRole.isEmpty()))
	    endWidth = endWidth + ((new Integer(interval)).intValue());

	String x = (new Integer(endWidth)).toString();

	String y = (new Integer(((cr.getY1()).intValue())+(new Integer(time)).intValue())).toString();
	String yI = (new Integer((new Integer(y)).intValue()-20)).toString();
	//creation of the new instance
	SVGInstance instance = new SVGInstance(x,yI,instanceName,className);
	instance.createSVGInstance(svgNS,doc,g);
	String x1 = (new Integer(5+(cr.getX1().intValue())).toString());
	SVGProcedureCall svgAC = new SVGProcedureCall(x1,y,x,y,message);
	svgAC.createSVGProcedureCall(svgNS,doc,g);

	endWidth = endWidth + instance.getWidth();

	classifierRole.addElement(instance);
	
	return instance;
	
    }
/** Methode createUser create a user from another classifier role and return the new user.First parameter is the message. cr is the classifierRole which creates the new one. time is the time where the new object appears.name is the name of the user.  
    */  
    public SVGUser createUser(String message,SVGClassifierRole cr,String time,String name){
	
	if(!(classifierRole.isEmpty()))
	    endWidth = endWidth + ((new Integer(interval)).intValue());

	String x = (new Integer(endWidth)).toString();
	String y = (new Integer(((cr.getY1()).intValue())+(new Integer(time)).intValue())).toString();
	String yI = (new Integer((new Integer(y)).intValue()-13)).toString();
	//creation of the new user
	SVGUser user = new SVGUser(x,yI,name);
	user.createSVGUser(svgNS,doc,g);
	String x1 = (new Integer(5+(cr.getX1().intValue())).toString());
	SVGProcedureCall svgAC = new SVGProcedureCall(x1,y,x,y,message);
	svgAC.createSVGProcedureCall(svgNS,doc,g);
	endWidth = endWidth + user.getWidth();

	classifierRole.addElement(user);
	
	return user;
	
    }
/** Methode createConcurrentObject create a concurrent object from another classifier role and return the new object.Firs parameter is the message. cr is the classifierRole which creates the new one. time is the time where the new object appears.name is the name of the concurrent object.  
    */  
    public SVGConcurrentObject createConcurrentObject(String message,SVGClassifierRole cr,String time,String name){
	
	if(!(classifierRole.isEmpty()))
	    endWidth = endWidth + ((new Integer(interval)).intValue());

	String x = (new Integer(endWidth)).toString();
	String y = (new Integer(((cr.getY1()).intValue())+(new Integer(time)).intValue())).toString();
	String yI = (new Integer((new Integer(y)).intValue()-13)).toString();
	//creation of the new concurrentObject
	SVGConcurrentObject concurrentObject = new SVGConcurrentObject(x,yI,name);
	concurrentObject.createSVGConcurrentObject(svgNS,doc,g);
	String x1 = (new Integer(5+(cr.getX1().intValue())).toString());
	SVGProcedureCall svgAC = new SVGProcedureCall(x1,y,x,y,message);
	svgAC.createSVGProcedureCall(svgNS,doc,g);
	endWidth = endWidth + concurrentObject.getWidth();

	classifierRole.addElement(concurrentObject);
	
	return concurrentObject;
	
    }
    
}
