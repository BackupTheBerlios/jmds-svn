package svgSequenceDiagramObjects;

import org.w3c.dom.*;


/**
 * SVGRectangle generates rectangles on a svg diagram.
 *
 * @author FRANCHETEAU Aurelien
 */

public class SVGRectangle extends SVGSequenceDiagramObject{

    private String width;
    private String height;

    /** Constructor takes the coordinates of the first point of the rectangle its width and its height.
     */
    protected SVGRectangle(String x,String y,String width,String height){
	super(x,y);
	this.width = width;
	this.height = height;
    }
    
    //===========================================================
    // Access Methods
    //===========================================================

    protected String getWidth(){
	return width;
    }
    protected String getHeight(){
	return height;
    }
    protected void setWidht(String width){
	this.width = width;
    } 
    protected void setHeight(String height){
	this.height = height;
    }
    /** creates a SVG Rectangle child of the svgRoot element in the Document doc.
     */
    protected void createSVGRectangle(String svgNS,Document doc,Element svgRoot){
	
	Element rectangle = doc.createElementNS(svgNS, "rect");
	rectangle.setAttributeNS(null, "x", x);
	rectangle.setAttributeNS(null, "y", y);
        rectangle.setAttributeNS(null, "width",width.toString());
        rectangle.setAttributeNS(null, "height",height.toString());
	rectangle.setAttributeNS(null, "style", "fill:none;stroke:black");
	svgRoot.appendChild(rectangle);
    }
}
