package svgSequenceDiagramObjects;

import org.w3c.dom.*;

/**
 * SVGComment generates comment on svg sequence diagram
 *
 * @author FRANCHETEAU Aurelien
 */

public class SVGComment extends SVGSequenceDiagramObject{
    
    private String text;
    private Integer width;
    private Integer height;

    /** Constructors takes the coordinates of the fist point of the comment(x,y) and the text.
     */
    public SVGComment(String x,String y,String text){
	super(x,y);
	this.text = text;
    }
     
    //===========================================================
    // Access Methods
    //===========================================================

    public String getText(){
	return text;
    } 
    public void setText(String text){
	this.text = text;
    } 
     
    /** creates a SVGComment(the child of svgRoot) in the document doc. 
    */
    public void createSVGComment(String svgNS,Document doc,Element svgRoot){
	
	Text txt = doc.createTextNode(text);
	Integer txtLength = new Integer(txt.getLength()*5);
	Element comment = doc.createElementNS(svgNS,"text");
	int txtX =( new Integer(x)).intValue();
	Integer txtXi = new Integer(txtX+5);
	comment.setAttributeNS(null,"x",txtXi.toString());
	int txtY =( new Integer(y)).intValue();
	Integer txtYi = new Integer(txtY+8);
	comment.setAttributeNS(null,"y",txtYi.toString());
	comment.setAttributeNS(null,"style","font-size:8;font-family:Verdana");
	comment.setAttributeNS(null,"textLength",txtLength.toString());
	comment.appendChild(txt);
	svgRoot.appendChild(comment);

	//creating rectangle
        Integer w = new Integer((txt.getLength()*5)+15);
	Integer h =  new Integer(15);
	
	this.width = w;
        this.height = h;

	Element recComment = doc.createElementNS(svgNS,"path");
	recComment.setAttributeNS(null,"d","M "+x+" "+y+" L "+(new Integer(txtX+(w.intValue())-5)).toString()+" "+y+" L "+(new Integer(txtX+(w.intValue()))).toString()+" "+(new Integer(txtY+5)).toString()+" L "+(new Integer(txtX+(w.intValue())-5)).toString()+" "+(new Integer(txtY+5)).toString()+" L "+(new Integer(txtX+(w.intValue())-5)).toString()+" "+y+" M "+(new Integer(txtX+(w.intValue()))).toString()+" "+(new Integer(txtY+5)).toString()+" L "+(new Integer(txtX+(w.intValue()))).toString()+" "+(new Integer(txtY+(h.intValue()))).toString()+" L "+x+" "+(new Integer(txtY+(h.intValue()))).toString()+" L "+x+" "+y );
	recComment.setAttributeNS(null,"fill","none");
	recComment.setAttributeNS(null,"stroke","black");
	svgRoot.appendChild(recComment);

    }

    /** creates a SVGComment(the child of svgRoot) in the document doc with parameter direction. It is the same construction that the one without direction parameter but with another way. 
    */
    public void createSVGComment(String svgNS,Document doc,Element svgRoot,String direction){
	
	Text txt = doc.createTextNode(text);
	Integer txtLength = new Integer(txt.getLength()*5);
	Element comment = doc.createElementNS(svgNS,"text");
	int txtX= (new Integer(x)).intValue();

	Integer w = new Integer((txt.getLength()*5)+15);
	if((direction.compareTo("left")==0)||(direction.compareTo("left-center")==0))
	    txtX = txtX - (w.intValue());

	Integer txtXi = new Integer(txtX+5);
	comment.setAttributeNS(null,"x",txtXi.toString());
	int txtY =( new Integer(y)).intValue();
	Integer txtYi = new Integer(txtY+8);
	comment.setAttributeNS(null,"y",txtYi.toString());
	comment.setAttributeNS(null,"style","font-size:8;font-family:Verdana");
	comment.setAttributeNS(null,"textLength",txtLength.toString());
	comment.appendChild(txt);
	svgRoot.appendChild(comment);

	//creating rectangle
        
	Integer h =  new Integer(15);
	
	this.width = w;
        this.height = h;

	

	Element recComment = doc.createElementNS(svgNS,"path");
	recComment.setAttributeNS(null,"d","M "+(new Integer(txtX)).toString()+" "+y+" L "+(new Integer(txtX+(w.intValue())-5)).toString()+" "+y+" L "+(new Integer(txtX+(w.intValue()))).toString()+" "+(new Integer(txtY+5)).toString()+" L "+(new Integer(txtX+(w.intValue())-5)).toString()+" "+(new Integer(txtY+5)).toString()+" L "+(new Integer(txtX+(w.intValue())-5)).toString()+" "+y+" M "+(new Integer(txtX+(w.intValue()))).toString()+" "+(new Integer(txtY+5)).toString()+" L "+(new Integer(txtX+(w.intValue()))).toString()+" "+(new Integer(txtY+(h.intValue()))).toString()+" L "+(new Integer(txtX)).toString()+" "+(new Integer(txtY+(h.intValue()))).toString()+" L "+(new Integer(txtX)).toString()+" "+y );
	recComment.setAttributeNS(null,"fill","none");
	recComment.setAttributeNS(null,"stroke","black");
	svgRoot.appendChild(recComment);

    }    
}
