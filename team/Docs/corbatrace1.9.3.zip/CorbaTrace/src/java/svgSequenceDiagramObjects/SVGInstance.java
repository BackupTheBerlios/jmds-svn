package  svgSequenceDiagramObjects;

import org.w3c.dom.*;

/**
 * SVGInstance class creates the object instance on the SVG Sequence Diagram.
 *
 * @author FRANCHETEAU Aurelien
 */

public class SVGInstance extends SVGClassifierRole{

    private String instanceName;
    private String className;
    //private Integer width;
    //private Integer height;


    /** Constructor takes the names of the instance and of the class.
     *  x and y are the co-ordinates of the point which locates the instance on the SVG sequence diagram
     */
    
    public SVGInstance(String x,String y,String instanceName,String className){
	super(x,y,"0","0");
	this.instanceName = instanceName;
	this.className = className;
	//Integer initial = new Integer(0);
	//width = initial;
	//height = initial;
    }
    
    /** Constructor used with the SVGSequenceDiagramDocument class.
     *It takes only
     */
    //===========================================================
    // Access Methods
    //===========================================================

    public String getInstanceName(){
	return instanceName;
    }
    public String getClassName(){
	return className;
    }
    public void setInstanceName(String instanceName){
	this.instanceName= instanceName;
    } 
    public void setClassName(String className){
	this.className= className;
    }
    /** creates a SVGInstance(the child of svgRoot) in the document doc.  
     */
    public void createSVGInstance(String svgNS,Document doc,Element svgRoot){
	this.svgNS = svgNS;
	document = doc;
	element = svgRoot;

	//creating text
	Text txt = doc.createTextNode(instanceName+":"+className);
	Integer txtLength = new Integer(txt.getLength()*5);
	Element instance = doc.createElementNS(svgNS,"text");
	int txtX =( new Integer(x)).intValue();
	Integer txtXi = new Integer(txtX+10);
	instance.setAttributeNS(null,"x",txtXi.toString());
	int txtY =( new Integer(y)).intValue();
	Integer txtYi = new Integer(txtY+20);
	instance.setAttributeNS(null,"y",txtYi.toString());
	instance.setAttributeNS(null,"style","font-size:10;font-family:Verdana;text-decoration:underline");
	instance.setAttributeNS(null,"textLength",txtLength.toString());
	instance.appendChild(txt);
	svgRoot.appendChild(instance);

	//creating rectangle
        Integer w = new Integer((txt.getLength()*5)+25);
	Integer h =  new Integer(40);
	
	this.width = w;
        this.height = h;

	SVGRectangle rec = new SVGRectangle(x,y,width.toString(),height.toString());
	rec.createSVGRectangle(svgNS,document,element);

	//creating co-ordinates of the started point of the axis time
	x1 = new Integer((((((new Integer(x)).intValue())+(width.intValue()))-((new Integer(x)).intValue()))/2)+((new Integer(x)).intValue()));
	y1 = new Integer(((new Integer(y)).intValue())+(height.intValue()));

    }
   
}
