package svgSequenceDiagramObjects;
import org.w3c.dom.*;

/**
 * SVGUser generates a User on the SVG Sequence Diagram.
 *
 * @author FRANCHETEAU Aurelien
 */

public class SVGUser  extends SVGClassifierRole{

     /** Constructor takes x and y are the co-ordinates of the point which 
     *locates the user symbol on the sequence diagram.
     */
    protected String name;

    public SVGUser(String x,String y,String name){
	super(x,y,"40","18");
	this.name = name;
    }
    
  
    /** creates a SVGUser(the child of svgRoot) in the document doc. 
     */
    public void createSVGUser(String svgNS,Document doc,Element svgRoot){
	this.svgNS = svgNS;
	document = doc;
	element = svgRoot;

	Element head = doc.createElementNS(svgNS,"circle");
	head.setAttributeNS(null, "cx",x);
	head.setAttributeNS(null,"cy",y);
	head.setAttributeNS(null,"r","3");
	head.setAttributeNS(null,"fill","none");
	head.setAttributeNS(null,"stroke","black");
	
	Integer neckY = new Integer(((new Integer(y)).intValue())+4);
	Integer pelvisY = new Integer(((new Integer(y)).intValue())+17);
	Integer rightHandX = new Integer(((new Integer(x)).intValue())-9);
	Integer leftHandX = new Integer(((new Integer(x)).intValue())+9);
	Integer trunkY = new Integer(((new Integer(y)).intValue())+7);
	Integer footY = new Integer(((new Integer(y)).intValue())+26);
	
	Element body = doc.createElementNS(svgNS,"path");
	body.setAttributeNS(null,"d","M "+x+" "+neckY.toString()+" L "+x+" "+pelvisY.toString()+" M "+rightHandX.toString()+" "+trunkY.toString()+" L "+leftHandX.toString()+" "+trunkY.toString()+" M "+rightHandX.toString()+" "+footY.toString()+" L "+x+" "+pelvisY.toString()+" L "+leftHandX.toString()+" "+footY.toString() );
	body.setAttributeNS(null,"fill","none");
	body.setAttributeNS(null,"stroke","black");
	//add user name
	Text txt = doc.createTextNode(name);
	Element userName = doc.createElementNS(svgNS,"text");
	Integer textY = new Integer(((new Integer(y)).intValue())+36);
	userName.setAttributeNS(null,"x",x);
	userName.setAttributeNS(null,"y",textY.toString());
	userName.setAttributeNS(null,"style","font-size:10;font-family:Verdana;text-decoration:underline;text-anchor:middle");
      
	userName.appendChild(txt);
	svgRoot.appendChild(userName);
	svgRoot.appendChild(head);
	svgRoot.appendChild(body);
	//creating co-ordinates of the started point of the axis time
	x1 = new Integer(x);
	y1 = new Integer(((new Integer(y)).intValue())+40);
    }
}
