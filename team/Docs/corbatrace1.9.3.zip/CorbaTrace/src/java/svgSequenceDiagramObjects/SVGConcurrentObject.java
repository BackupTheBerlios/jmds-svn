package  svgSequenceDiagramObjects;

import org.w3c.dom.*;

/**
 * SVGConcurentObject class creates a concurrent object on the SVG Sequence Diagrem.
 *
 * @author FRANCHETEAU Aurelien
 */

public class SVGConcurrentObject extends SVGClassifierRole{

    private String name;

    /** Constructor takes the names of the concurrent object.
     *  x and y are the co-ordinates of the point which locates the instance on the SVG sequence diagram and finally its name in the third parameter
     */
    
    public SVGConcurrentObject(String x,String y,String name){
	super(x,y,"0","0");
	this.name = name;
    }
    

    //===========================================================
    // Access Methods
    //===========================================================

    public String getName(){
	return name;
    }
       public void setName(String name){
	this.name = name;
    } 
 
    /** creates a SVGConcurrentObject(the child of svgRoot) in the document doc.  
     */
    public void createSVGConcurrentObject(String svgNS,Document doc,Element svgRoot){
	this.svgNS = svgNS;
	document = doc;
	element = svgRoot;

	//creating text
	Text txt = doc.createTextNode(name);
	Integer txtLength = new Integer(txt.getLength()*5);
	Element concurrentObject = doc.createElementNS(svgNS,"text");
	int txtX =( new Integer(x)).intValue();
	Integer txtXi = new Integer(txtX+10);
	concurrentObject.setAttributeNS(null,"x",txtXi.toString());
	int txtY =( new Integer(y)).intValue();
	Integer txtYi = new Integer(txtY+20);
	concurrentObject.setAttributeNS(null,"y",txtYi.toString());
	concurrentObject.setAttributeNS(null,"style","font-size:10;font-weight:800;font-family:Verdana;text-decoration:underline");
	concurrentObject.setAttributeNS(null,"textLength",txtLength.toString());
	concurrentObject.appendChild(txt);
	svgRoot.appendChild(concurrentObject);

	//creating rectangle
        Integer w = new Integer((txt.getLength()*5)+25);
	Integer h =  new Integer(40);
	
	this.width = w;
        this.height = h;

	Element rectangle = doc.createElementNS(svgNS, "rect");
	rectangle.setAttributeNS(null, "x", x);
	rectangle.setAttributeNS(null, "y", y);
        rectangle.setAttributeNS(null, "width",width.toString());
        rectangle.setAttributeNS(null, "height",height.toString());
	rectangle.setAttributeNS(null, "style", "fill:none;stroke:black;stroke-width:3");
	svgRoot.appendChild(rectangle);


	//creating co-ordinates of the started point of the axis time
	x1 = new Integer((((((new Integer(x)).intValue())+(width.intValue()))-((new Integer(x)).intValue()))/2)+((new Integer(x)).intValue()));
	y1 = new Integer(((new Integer(y)).intValue())+(height.intValue()));

    }
   
}
