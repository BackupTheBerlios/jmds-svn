package svgSequenceDiagramObjects;
import org.w3c.dom.*;

/**
 * SVGProcedureCall generates a procedure call on the svg sequence diagram.
 *
 * @author FRANCHETEAU Aurelien
 */

public class SVGProcedureCall extends SVGMessage{

    
    private String text;

    
    public SVGProcedureCall(String x,String y,String x2,String y2,String text){
	super(x,y,x2,y2);
	this.text = text;
    }
    //===========================================================
    // Access Methods
    //===========================================================

    public String getText(){
	return text;
    }
    public void setText(String text){
	this.text = text;
    }

    /** creates a SVGProcedureCall(the child of svgRoot) in the document doc. 
    */
    public void createSVGProcedureCall(String svgNS,Document doc,Element svgRoot){
	

	//line
	Element line = doc.createElementNS(svgNS,"line");
	line.setAttributeNS(null,"x1",x);
	line.setAttributeNS(null,"y1",y);
	//x2b use to add marker at the end of the line
	Integer x2b = new Integer(0);
	if(((new Integer(x)).intValue())<=((new Integer(x2)).intValue())){
	    x2b = new Integer(((new Integer(x2)).intValue())-12);
	}
	else{	
	    x2b = new Integer(((new Integer(x2)).intValue())+12);
	}
	line.setAttributeNS(null,"x2",x2b.toString());
	line.setAttributeNS(null,"y2",y2);
	line.setAttributeNS(null,"stroke","black");
	line.setAttributeNS(null,"marker-end","url(#svgProcedureCallArrowhead)");
	svgRoot.appendChild(line);
	
	//message
	
	Integer messageX = new Integer(((((new Integer(x2)).intValue())-((new Integer(x)).intValue()))/2)+((new Integer(x)).intValue()));
	Integer messageY = new Integer((((((new Integer(y2)).intValue())-((new Integer(y)).intValue()))/2)+((new Integer(y)).intValue()))-5);

	Element message = doc.createElementNS(svgNS,"text");
	message.setAttributeNS(null,"x",messageX.toString());
	message.setAttributeNS(null,"y",messageY.toString());
	message.setAttributeNS(null,"style","text-anchor:middle;font-size:10;font-family:Verdana");
	Text msg = doc.createTextNode(text);
	message.appendChild(msg);
	svgRoot.appendChild(message);
    }
}
