package svgSequenceDiagramObjects;


/**
 * SVGLine is an abstract class for lines in svg sequence diagram.
 *
 * @author FRANCHETEAU Aurelien
 */

public abstract class SVGLine extends SVGSequenceDiagramObject{

    protected String x2;
    protected String y2;

    /** Constructor takes x and y which  are the co-ordinates of the start point  
     * and x2 and y2 the co-ordinates of the end point of the line.
     */
    
    public SVGLine(String x1,String y1,String x2,String y2){
	super(x1,y1);
	this.x2 = x2;
	this.y2 = y2;
    }
    
    //===========================================================
    // Access Methods
    //===========================================================

    public String getX2(){
	return x2;
    } 
    public String getY2(){
	return y2;
    }
    public void  setX2(String x2){
	this.x2 = x2;
    } 
    public void setY2(String y2){
	this.y2 = y2;
    }
         
}
