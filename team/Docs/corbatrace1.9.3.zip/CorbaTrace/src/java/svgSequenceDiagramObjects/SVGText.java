package svgSequenceDiagramObjects;

import org.w3c.dom.*;

/**
 * SVGText generates text on svg sequence diagram
 *
 * @author FRANCHETEAU Aurelien
 */

public class SVGText extends SVGSequenceDiagramObject{
    
    private String text;

    /** Constructors takes the coordinates of the fist point of the text(x,y) and the text.
     */
    public SVGText(String x,String y,String text){
	super(x,y);
	this.text = text;
    }
     
    //===========================================================
    // Access Methods
    //===========================================================

    public String getText(){
	return text;
    } 
    public void setText(String text){
	this.text = text;
    } 
     
    /** creates a SVGText(the child of svgRoot) in the document doc. 
    */
    public void createSVGText(String svgNS,Document doc,Element svgRoot){
	Element elt = doc.createElementNS(svgNS,"text");
        elt.setAttributeNS(null,"x",x);
	elt.setAttributeNS(null,"y",y);
	elt.setAttributeNS(null,"style","font-size:10;font-family:Verdana");
	Text txt = doc.createTextNode(text);
	elt.appendChild(txt);
	svgRoot.appendChild(elt);
    }

         
}
