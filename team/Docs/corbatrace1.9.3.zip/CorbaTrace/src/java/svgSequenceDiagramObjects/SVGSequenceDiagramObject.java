package svgSequenceDiagramObjects;

/**
 * Class SVGSequenceDiagramObject is the root of the package corbatrace.log2svg hierarchy. Every class of the package has SVGSequenceDiagramObject as a superclass.
 * 
 * @author FRANCHETEAU Aurelien
 */

public abstract class SVGSequenceDiagramObject{

    protected String x;
    protected String y;

    /** Constructor takes x and y are the co-ordinates of the point which 
     *locates the object on the sequence diagram.
     */
    
    public SVGSequenceDiagramObject(String x,String y){
	this.x = x;
	this.y = y;	
    }
    
    //===========================================================
    // Access Methods
    //===========================================================

    public String getX(){
	return x;
    } 
    public String getY(){
	return y;
    }
    public void  setX(String x){
	this.x = x;
    } 
    public void setY(String y){
	this.y = y;
    }
   
}
