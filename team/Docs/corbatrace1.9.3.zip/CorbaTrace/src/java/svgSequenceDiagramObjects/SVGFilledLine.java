package svgSequenceDiagramObjects;

import org.w3c.dom.*;

/**
 * SVGFilledLine generates a filled line on the svg sequence diagram.
 *
 * @author FRANCHETEAU Aurelien
 */

public class SVGFilledLine extends SVGLine{

    /** The constructor takes the coordinates of the started point of the line(x1,y1) and the end point(x2,y2).
     */
    protected SVGFilledLine(String x1,String y1,String x2,String y2){
	super(x1,y1,x2,y2);
    }
    

    /** creates a SVG Filled Line(the child of svgRoot) in the document doc. 
    */
    protected void createSVGFilledLine(String svgNS,Document doc,Element svgRoot){
	
	Element line = doc.createElementNS(svgNS,"line");
	line.setAttributeNS(null,"x1",x);
	line.setAttributeNS(null,"y1",y);
	line.setAttributeNS(null,"x2",x2);
	line.setAttributeNS(null,"y2",y2);
	line.setAttributeNS(null,"stroke","black");
	svgRoot.appendChild(line);
    }
}
