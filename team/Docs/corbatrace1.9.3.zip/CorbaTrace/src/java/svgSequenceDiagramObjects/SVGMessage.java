package svgSequenceDiagramObjects;

import org.w3c.dom.*;

/**
 * SVGMessage generates message in the svg sequence diagram
 *
 * @author FRANCHETEAU Aurelien
 */

public abstract class SVGMessage extends SVGSequenceDiagramObject{
    
    protected String x2;
    protected String y2;

    public SVGMessage(String x,String y,String x2,String y2){
	super(x,y);
	this.x2 = x2;
	this.y2 = y2;
	
    }
     
    //===========================================================
    // Access Methods
    //===========================================================

    public String getX2(){
	return x2;
    } 
    public String getY2(){
	return y2;
    }
    public void  setX2(String x2){
	this.x2 = x2;
    } 
    public void setY2(String y2){
	this.y2 = y2;
    }
     
           
}
