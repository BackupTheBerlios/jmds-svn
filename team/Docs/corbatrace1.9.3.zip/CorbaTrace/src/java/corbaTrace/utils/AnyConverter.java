/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 */
package corbaTrace.utils;

import org.omg.DynamicAny.*;
import org.omg.CORBA.*;
import java.util.*;

/**
 * This class is an utility class for find the type and the value of an Any
 * @author Etienne Juliot
 * @version 0.1
 */

public class AnyConverter {
    private static Hashtable typeNames_;
    private DynAnyFactory factory_;
    

    static
    {
        //
        // Put the names of the TCKind values in a hashtable
        //
        typeNames_ = new Hashtable();
        typeNames_.put(org.omg.CORBA.TCKind.tk_null, "null");
        typeNames_.put(org.omg.CORBA.TCKind.tk_void, "void");
        typeNames_.put(org.omg.CORBA.TCKind.tk_short, "short");
        typeNames_.put(org.omg.CORBA.TCKind.tk_ushort, "unsigned short");
        typeNames_.put(org.omg.CORBA.TCKind.tk_long, "long");
        typeNames_.put(org.omg.CORBA.TCKind.tk_ulong, "unsigned long");
        typeNames_.put(org.omg.CORBA.TCKind.tk_float, "float");
        typeNames_.put(org.omg.CORBA.TCKind.tk_double, "double");
        typeNames_.put(org.omg.CORBA.TCKind.tk_boolean, "boolean");
        typeNames_.put(org.omg.CORBA.TCKind.tk_char, "char");
        typeNames_.put(org.omg.CORBA.TCKind.tk_octet, "octet");
        typeNames_.put(org.omg.CORBA.TCKind.tk_any, "any");
        typeNames_.put(org.omg.CORBA.TCKind.tk_TypeCode, "TypeCode");
        typeNames_.put(org.omg.CORBA.TCKind.tk_Principal, "Principal");
        typeNames_.put(org.omg.CORBA.TCKind.tk_objref, "objref");
        typeNames_.put(org.omg.CORBA.TCKind.tk_struct, "struct");
        typeNames_.put(org.omg.CORBA.TCKind.tk_union, "union");
        typeNames_.put(org.omg.CORBA.TCKind.tk_enum, "enum");
        typeNames_.put(org.omg.CORBA.TCKind.tk_string, "string");
        typeNames_.put(org.omg.CORBA.TCKind.tk_sequence, "sequence");
        typeNames_.put(org.omg.CORBA.TCKind.tk_array, "array");
        typeNames_.put(org.omg.CORBA.TCKind.tk_alias, "alias");
        typeNames_.put(org.omg.CORBA.TCKind.tk_except, "exception");
        typeNames_.put(org.omg.CORBA.TCKind.tk_longlong, "long long");
        typeNames_.put(org.omg.CORBA.TCKind.tk_ulonglong,
                       "unsigned long long");
        typeNames_.put(org.omg.CORBA.TCKind.tk_longdouble, "long double");
        typeNames_.put(org.omg.CORBA.TCKind.tk_wchar, "wchar");
        typeNames_.put(org.omg.CORBA.TCKind.tk_wstring, "wstring");
        typeNames_.put(org.omg.CORBA.TCKind.tk_fixed, "fixed");
        typeNames_.put(org.omg.CORBA.TCKind.tk_value, "valuetype");
        typeNames_.put(org.omg.CORBA.TCKind.tk_value_box, "valuebox");
        typeNames_.put(org.omg.CORBA.TCKind.tk_native, "native");
        typeNames_.put(org.omg.CORBA.TCKind.tk_abstract_interface,
                       "abstract interface");
    }


    /**
     * Given a TypeCode, return the TypeCode without any aliasing
     */
    private static org.omg.CORBA.TypeCode getOriginalType(org.omg.CORBA.TypeCode tc)
    {
        org.omg.CORBA.TypeCode result = tc;

        try
        {
            while(result.kind() == org.omg.CORBA.TCKind.tk_alias)
                result = result.content_type();
        }
        catch(org.omg.CORBA.TypeCodePackage.BadKind ex)
        {
            // ignore
        }

        return result;
    }

    /**
     * Constructor.
     * To have factory, use :<br/>
     * <code>ORBInitInfo info;</code><br/>
     * ...<br/>
     * <code>org.omg.CORBA.Object obj = <br/>
     * info.resolve_initial_references("DynAnyFactory");<br/>
     * DynAnyFactory dynAnyFactory = DynAnyFactoryHelper.narrow(obj);</code>
     * @param factory The factory already init
     */

    public AnyConverter(DynAnyFactory factory) {
	factory_ = factory;
    }


    /**
     * Return the value of the Any
     * @return Value of the Any
     */
    public String getValue(Any any)
    {
        org.omg.DynamicAny.DynAny dynAny = null;
        try
        {
            dynAny = factory_.create_dyn_any(any);
        }
        catch(org.omg.DynamicAny.DynAnyFactoryPackage.InconsistentTypeCode ex)
        {
            return null;
        }
        return getValue(dynAny);
    }

    /**
     * Return the value of some Any objects
     * @return Value of the Any (append together)
     */
    public String getValue(Any[] anySeq)
    {
        StringBuffer str = new StringBuffer();
	for(int i = 0 ; i < anySeq.length ; i++)
        {
            str.append("  ");
            str.append(getValue(anySeq[i]));
        }
        return str.toString();
    }

    /**
     * Return the value of a DynAny
     * @return Value of the DynAny
     */
    public String getValue(org.omg.DynamicAny.DynAny dynAny)
    {
        StringBuffer str = new StringBuffer();
	dynAny.rewind();

        TypeCode type = dynAny.type();
        TypeCode tc = getOriginalType(type);
        TCKind kind = tc.kind();

        try
        {
            switch(kind.value())
            {
                case org.omg.CORBA.TCKind._tk_null:
                    str.append("<null>");
                    break;

                case org.omg.CORBA.TCKind._tk_void:
                    str.append("<void>");
                    break;

                case org.omg.CORBA.TCKind._tk_short:
                    str.append(String.valueOf(dynAny.get_short()));
                    break;

                case org.omg.CORBA.TCKind._tk_ushort:
                {
                    int i = dynAny.get_ushort();
                    if(i < 0)
                        i += ((int)Short.MAX_VALUE -
                              (int)Short.MIN_VALUE) + 1;
                    str.append(String.valueOf(i));
                    break;
                }

                case org.omg.CORBA.TCKind._tk_long:
                    str.append(String.valueOf(dynAny.get_long()));
                    break;

                case org.omg.CORBA.TCKind._tk_ulong:
                {
                    long l = dynAny.get_ulong();
                    if(l < 0)
                        l += ((long)Integer.MAX_VALUE -
                              (long)Integer.MIN_VALUE) + 1;
                    str.append(String.valueOf(l));
                    break;
                }

                case org.omg.CORBA.TCKind._tk_longlong:
                    str.append(String.valueOf(dynAny.get_longlong()));
                    break;

                case org.omg.CORBA.TCKind._tk_ulonglong:
                {
                    long l = dynAny.get_ulonglong();
                    if(l < 0)
                        l += (Long.MAX_VALUE - Long.MIN_VALUE) + 1;
                    str.append(String.valueOf(l));
                    break;
                }

                case org.omg.CORBA.TCKind._tk_float:
                    str.append(String.valueOf(dynAny.get_float()));
                    break;

                case org.omg.CORBA.TCKind._tk_double:
                    str.append(String.valueOf(dynAny.get_double()));
                    break;

                case org.omg.CORBA.TCKind._tk_boolean:
                    str.append(String.valueOf(dynAny.get_boolean()));
                    break;

                case org.omg.CORBA.TCKind._tk_char:
                    str.append(String.valueOf(dynAny.get_char()));
                    break;

                case org.omg.CORBA.TCKind._tk_wchar:
                    str.append(String.valueOf(dynAny.get_wchar()));
                    break;

                case org.omg.CORBA.TCKind._tk_octet:
                {
                    short s = dynAny.get_octet();
                    if(s < 0)
                        s += ((short)Byte.MAX_VALUE -
                              (short)Byte.MIN_VALUE) + 1;
                    str.append(String.valueOf(s));
                    break;
                }

                case org.omg.CORBA.TCKind._tk_string:
                    str.append(dynAny.get_string());
                    break;

                case org.omg.CORBA.TCKind._tk_wstring:
                    str.append(dynAny.get_wstring());
                    break;

                case org.omg.CORBA.TCKind._tk_objref:
                {
                    org.omg.CORBA.Object obj = dynAny.get_reference();
                    if(obj == null)
                        str.append("nil");
                    else
                        str.append("<object>");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_any:
                {
                    org.omg.CORBA.Any any = dynAny.get_any();
                    str.append(getValue(any));
                    break;
                }

                case org.omg.CORBA.TCKind._tk_TypeCode:
                {
                    org.omg.CORBA.TypeCode typeCode = dynAny.get_typecode();
                    str.append(getValue(typeCode));
                    break;
                }

                case org.omg.CORBA.TCKind._tk_fixed:
                {
                    org.omg.DynamicAny.DynFixed dynFixed =
                        org.omg.DynamicAny.DynFixedHelper.narrow(dynAny);
                    str.append(dynFixed.get_value());
                    break;
                }

                case org.omg.CORBA.TCKind._tk_except:
                case org.omg.CORBA.TCKind._tk_struct:
                {
                    org.omg.DynamicAny.DynStruct dynStruct =
                        org.omg.DynamicAny.DynStructHelper.narrow(dynAny);
                    		    
                    int count = tc.member_count();
                    for(int i = 0 ; i < count ; i++)
                    {
                        str.append(dynStruct.current_member_name());
                        str.append(" = ");
                        org.omg.DynamicAny.DynAny component =
                            dynStruct.current_component();
                        str.append(getValue(component));
			str.append("\n");
                        dynStruct.next();
                    }
                    break;
                }

                case org.omg.CORBA.TCKind._tk_value:
                {
                    org.omg.DynamicAny.DynValue dynValue =
                        org.omg.DynamicAny.DynValueHelper.narrow(dynAny);
		    
                    int count = dynValue.component_count();
                    for(int i = 0 ; i < count ; i++)
                    {
                        str.append(dynValue.current_member_name());
                        str.append(" = ");
                        org.omg.DynamicAny.DynAny component =
                            dynValue.current_component();
                        str.append(getValue(component));
                        str.append("\n");
                        dynValue.next();
                    }
                    break;
                }

                case org.omg.CORBA.TCKind._tk_value_box:
                {
                    org.omg.DynamicAny.DynValue dynValue =
                        org.omg.DynamicAny.DynValueHelper.narrow(dynAny);
                    
                    org.omg.DynamicAny.DynAny component =
                        dynValue.current_component();
                    str.append(getValue(component));

                    break;
                }

                case org.omg.CORBA.TCKind._tk_union:
                {
                    org.omg.DynamicAny.DynUnion dynUnion =
                        org.omg.DynamicAny.DynUnionHelper.narrow(dynAny);

		    
                    org.omg.DynamicAny.DynAny component;

                    component = dynUnion.current_component();
                    str.append("discriminator = ");
                    str.append(getValue(component));
		    str.append("\n");

                    dynUnion.next();

                    component = dynUnion.current_component();
                    str.append(dynUnion.member_name());
		    str.append(" = ");

                    if(component != null)
                        str.append(getValue(component));
                    else
                        str.append("not initialized");

                    str.append("\n");

                    break;
                }

                case org.omg.CORBA.TCKind._tk_enum:
                {
                    org.omg.DynamicAny.DynEnum dynEnum =
                        org.omg.DynamicAny.DynEnumHelper.narrow(dynAny);
                    str.append(dynEnum.get_as_string());
                    break;
                }

                case org.omg.CORBA.TCKind._tk_sequence:
                {
		    org.omg.DynamicAny.DynSequence dynSequence =
                        org.omg.DynamicAny.DynSequenceHelper.narrow(dynAny);
                    for(int i = 0 ; i < dynSequence.get_length() ; i++)
                    {
                        if(i != 0)
                            str.append(", ");
                        org.omg.DynamicAny.DynAny component =
                            dynSequence.current_component();
                        str.append(getValue(component));
                        dynSequence.next();
                    }
                    break;
                }

                case org.omg.CORBA.TCKind._tk_array:
                {
		    org.omg.DynamicAny.DynArray dynArray =
                        org.omg.DynamicAny.DynArrayHelper.narrow(dynAny);
                    for(int i = 0 ; i < tc.length() ; i++)
                    {
                        if(i != 0)
                            str.append(", ");
                        org.omg.DynamicAny.DynAny component =
                            dynArray.current_component();
                        str.append(getValue(component));
                        dynArray.next();
                    }
                    break;
                }

                default:
                    throw new RuntimeException("unsupported type kind");
            }
        }
        catch(org.omg.DynamicAny.DynAnyPackage.InvalidValue e)
        {
        }
        catch(org.omg.DynamicAny.DynAnyPackage.TypeMismatch e)
        {
        }
        catch(org.omg.CORBA.TypeCodePackage.BadKind e)
        {
        }

        dynAny.rewind();
	return str.toString();
    }


    /**
     * Return the value of a TypeCode
     * @return Value of a TypeCode
     */
    
    public String getValue(TypeCode tc) {
	TCKind kind = tc.kind();
	StringBuffer str = new StringBuffer();

	try
        {
            switch(kind.value())
            {
                case org.omg.CORBA.TCKind._tk_objref:
                    str.append("interface " + tc.name() + ";");
                    break;

                case org.omg.CORBA.TCKind._tk_struct:
                case org.omg.CORBA.TCKind._tk_except:
                {
                    str.append("" + typeNames_.get(kind) + " " +
			       tc.name() + " {\n");
                    
                    for(int i = 0 ; i < tc.member_count() ; i++)
                    {
			org.omg.CORBA.TypeCode memberType = tc.member_type(i);
                        str.append(getValue(memberType));
                        str.append(" " + tc.member_name(i) + ";\n");
                    }
                    str.append("\n};");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_union:
                {
                    str.append("union " + tc.name() + " switch(");
                    org.omg.CORBA.TypeCode discrType = tc.discriminator_type();
                    str.append(getValue(discrType));
                    str.append(") {\n");
                    
                    for(int i = 0 ; i < tc.member_count() ; i++)
                    {
                        org.omg.CORBA.Any label = tc.member_label(i);
                        org.omg.CORBA.TypeCode type = label.type();

                        if(type.kind() == org.omg.CORBA.TCKind.tk_octet)
                            str.append("default");
                        else
                        {
                            str.append("case ");
                            org.omg.DynamicAny.DynAny dynAny = null;
                            try
                            {
                                dynAny = factory_.create_dyn_any(label);
                            }
                            catch(org.omg.DynamicAny.DynAnyFactoryPackage.
                                  InconsistentTypeCode e)
                            {
                                throw new RuntimeException();
                            }
			    str.append(getValue(dynAny));
                        }

                        str.append(": ");
                        org.omg.CORBA.TypeCode memberType = tc.member_type(i);
                        str.append(getValue(memberType));
                        str.append(" " + tc.member_name(i) + ";\n");
                    }
                    str.append("};");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_enum:
                {
                    str.append("enum " + tc.name()+ " {");
                    for(int i = 0 ; i < tc.member_count() ; i++)
                    {
                        if(i != 0 )
                            str.append(", ");
                        str.append(tc.member_name(i));
                    }
                    str.append("};");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_string:
                {
                    str.append("string");
                    int length = tc.length();
                    if(length != 0)
                        str.append("<" + length + ">");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_wstring:
                {
                    str.append("wstring");
                    int length = tc.length();
                    if(length != 0)
                        str.append("<" + length + ">");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_fixed:
                {
                    str.append("fixed<" + tc.fixed_digits() + "," +
			       tc.fixed_scale() + ">");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_sequence:
                {
                    str.append("sequence<");
                    org.omg.CORBA.TypeCode contentType = tc.content_type();
                    str.append(getValue(contentType));
                    int length = tc.length();
                    if(length != 0)
                        str.append(", " + length);
                    str.append(">");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_array:
                {
		    org.omg.CORBA.TypeCode contentType = tc.content_type();
                    str.append(getValue(contentType));
                    int length = tc.length();
                    str.append("[" + length + "]");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_alias:
                {
                    str.append("typedef ");
                    org.omg.CORBA.TypeCode contentType = tc.content_type();
                    str.append(getValue(contentType));
                    str.append(" " + tc.name() + ";");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_value:
                {
                    str.append("valuetype " + tc.name() + " {\n");

                    java.util.Vector vec = new java.util.Vector();
                    vec.addElement(tc);
                    org.omg.CORBA.TypeCode base = tc.concrete_base_type();
                    while(base != null)
                    {
                        vec.insertElementAt(base, 0);
                        base = base.concrete_base_type();
                    }

                    java.util.Enumeration e = vec.elements();
                    while(e.hasMoreElements())
                    {
                        org.omg.CORBA.TypeCode p =
                            (org.omg.CORBA.TypeCode)e.nextElement();
                        for(int i = 0 ; i < p.member_count() ; i++)
                        {
			    org.omg.CORBA.TypeCode memberType =
                                p.member_type(i);
                            str.append(getValue(memberType));
                            str.append(" " + p.member_name(i) + ";\n");
                        }
                    }

                    str.append("};");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_value_box:
                {
                    str.append("valuetype " + tc.name() + " ");
                    org.omg.CORBA.TypeCode contentType = tc.content_type();
                    str.append(getValue(contentType));
                    str.append(";");
                    break;
                }

                case org.omg.CORBA.TCKind._tk_abstract_interface:
                    str.append("abstract interface " + tc.name() + ";");
                    break;

                case org.omg.CORBA.TCKind._tk_native:
                    str.append("native " + tc.name() + ";");
                    break;

                default:
                    str.append("" + typeNames_.get(kind));
                    break;
            }

        }
        catch(org.omg.CORBA.TypeCodePackage.BadKind e)
        {
        }
        catch(org.omg.CORBA.TypeCodePackage.Bounds e)
        {
        }
	return str.toString();
    }
    

}
