/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 */
package corbaTrace.utils;

import java.lang.StringBuffer;

/**
 * This class is use to simply done a XML string. <br/>
 * You can have a nice result, with good indents, without use DOM (to slow or need to memory). <br/>
 * exemple : to write this <code> <br/>
 * &lt;titi&gt; <br/>
 *        &lt;age/&gt; <br/>
 *        &lt;name first="Omer" last="Simpsons"/&gt; <br/>
 * &lt;/titi&gt;</code> <br/>
 * You need to write : <code> <br/>
 * IndentString out = new IndentString(); <br/>
 * out.insert("&lt;titi&gt;"); <br/>
 * out.inc(); <br/>
 * out.insert("&lt;age/&gt;"); <br/>
 * out.indent(); <br/>
 * out.append("&lt;name"); <br/>
 * out.append(" first="Omer" last="Simpsons"/&gt;"); <br/>
 * out.newLine(); <br/>
 * out.dec(); <br/>
 * out.insert("&lt;/titi&gt;");</code>
 */

public class IndentString {

	private StringBuffer text;
	private int indent;

	/**
	 * Constructor. Just created an empty string.
	 */
	public IndentString() {
		text = new StringBuffer();
		indent = 0;
	}

	/**
	 * Insert a new line. <br/>
	 * Indent + append + newLine
	 * @param text Text to insert
	 */
	public void insert(String text) {
		indent();
		append(text);
		newLine();
	}


	
	/**
	 * Append a text (without new line and without indent)
	 * @param text Text to insert
	 */
	public void append(String text) {
		this.text.append(text);
	}

	/**
	 * Insert a new line
 	 * @deprecated
	 */
	public void newLine() {
		this.text.append("\n");
	}

	/**
	 * Indent with the current increment
	 * @deprecated
	 */
	public void indent() {
		for (int i = 0; i < indent; i++)
			this.text.append("\t");
	}

	/**
	 * Return the string representation
	 * @return The string 
	 */

	public String toString() {
		return text.toString();
	}

	/**
	 * Increment indent level
 	 * @deprecated
	 */
	public void inc() {
		indent++;
	}

	/**
	 * Decrement indent level
	 * @deprecated
	 */
	public void dec() {
		if (indent > 0)
			indent--;
	}

	/**
	 * Insert a attribute. <br/>
	 * space + name=" + value + " + space
	 * @param name attribute name
 	 * @param value attribute value
	 */
	public void attribute(String name, String value) {
		append(" " + name + "=\"" + value + "\"");
	}
	
	/**
	 * Open a new xml Tag. <br/>
	 * Indent + &lt + tagName
	 * @param tagName tag name
	 */
	public void openTag(String tagName) {
		indent();
		append("<" + tagName);	
	}
	
	/**
	 * Close a xml Tag. <br/>
	 * &gt + newLine + increment indentation
	 */
	public void closeTag() {
		append(">");
		newLine();
		indent++;
	}

	/**
	 * Begin a new xml Tag with no attributes. <br/>
	 * Indent + &lt + tagName + &gt + newLine + decrement indentation 
	 * @param tagName tag name
	 */
	public void beginTag(String tagName) {
		indent();
		append("<" + tagName + ">");
		newLine();
		indent++;
	}
		
	/**
	 * Insert end of xml Tag. <br/>
	 * decrement indentation  + Indent + / + &lt + tagName + &gt + newLine
	 * @param tagName tag name
	 */
	public void endTag(String tagName) {
		indent--;
		indent();
		append("</" + tagName + ">");
		newLine();
	}
	
	/**
	 * Insert end of xml Tag. <br/>
	 * /&gt + newLine
	 */
	public void endTag() {
		append("/>");
		newLine();
	}

}
