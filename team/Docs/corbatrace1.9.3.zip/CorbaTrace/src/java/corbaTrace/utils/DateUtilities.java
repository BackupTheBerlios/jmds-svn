package corbaTrace.utils;

import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;

/** 
  * just a class with useful static methods for some convertion with Strings.
  */
public abstract class DateUtilities {

    protected static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

    public static final Date BAD_DATE = stringToDate("0000-01-01T00:00:00.000");

    /* A utility method (static) that convert a String to a Date object (and vice-versa).
     * String format of each date is defined as the static constant object DATE_FORMAT
     * @param date is a String in format "yyyy-MM-dd'T'HH:mm:ss.SSSZZ"  @see 
     * @returns null if String passed as parameter is not correctly formed.
     *
     */
    public static Date stringToDate(String date) {
         try {
            if (date != null)
               return DATE_FORMAT.parse(date);
            else
               return null;
         } catch (ParseException e) {
                return null;
         }
    }

    public static String dateToString(Date date) {
         if (date != null)
            return DATE_FORMAT.format(date);
         else
            return null;
    }
}

