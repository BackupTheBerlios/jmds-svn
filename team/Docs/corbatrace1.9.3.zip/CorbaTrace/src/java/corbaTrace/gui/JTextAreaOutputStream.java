package corbaTrace.gui;

/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Jean-Philippe Wilsch
 */

import java.io.*;
import javax.swing.JTextArea;

/**
 * A JTextArea output stream is an output stream for writing data to a Swing JTextArea.
 * @author Jean-Philippe Wilsch
 */

public class JTextAreaOutputStream extends OutputStream {
    
    //the JTextArea where to write
    JTextArea output;

    /**
     * Constructor
     * Initialize the output JTextArea
     */

    public JTextAreaOutputStream() {
	super();
	output = new JTextArea();
    }

    /**
     * Constructor
     * Initialize the output JTextArea with the JTextArea given as parameter
     * @param out the JTextArea where to write
     */

    public JTextAreaOutputStream(JTextArea out) {
	super();
	output = out;
    }
    
    /**
     * Writes the specified int to the output stream
     * @param b the int
     */

    public void write(int b) throws IOException{
	if (output==null)
	    throw new IOException("No JTextArea Output");
	else
	    output.append(String.valueOf(b));
    }

    /**
     * Writes len bytes from the specified byte array starting at offset off to this output stream.
     * @param b the data
     * @param off the start offset in the data
     * @param len the number of bytes to write
     */

    public void write(byte[] b,int offset, int length) throws IOException{
	if (output==null)
	    throw new IOException("No JTextArea Output");
	else
	    output.append(new String(b,offset,length));
    }
}
