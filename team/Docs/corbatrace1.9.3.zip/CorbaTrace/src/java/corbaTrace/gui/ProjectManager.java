package corbaTrace.gui;

import java.io.*;
import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;

public class ProjectManager {


    private String currentProjectName;
    private File currentProjectPath;
    private JTree currentProjectTree;

    public ProjectManager() {
	currentProjectName=null;
	currentProjectPath=null;
	currentProjectTree=null;
    }

    public boolean newProject(File projectParentPath, String projectName) {
	// create the project folder
	File projectFolder = new File(projectParentPath,projectName);
	if (projectFolder.exists()) {
	    return false;
	}else{
	    projectFolder.mkdir();
	    (new File(projectFolder,"logs")).mkdir();
	    (new File(projectFolder,"filters")).mkdir();
	    (new File(projectFolder,"xmi")).mkdir();
	    (new File(projectFolder,"svg")).mkdir();
	    (new File(projectFolder,"tex")).mkdir();
	    File projectFile = new File(projectFolder,projectName+".cb");
	    try {
		PrintWriter pw = new PrintWriter(new FileWriter(projectFile));
		pw.println("#This is a CorbaTrace project file#");
		pw.flush();
		pw.close();
	    }catch(IOException e) {
		System.out.println("IOException : "+e.getMessage());
	    }
	    currentProjectPath=projectFolder;
	    currentProjectName=projectName;
	    reloadProjectTree();
	    return true;
	}
	
    }

    public boolean openProject(File projectFile) {
	//create the project folder
	File projectFolder = projectFile.getParentFile();
	if (projectFolder.exists()) {
	    currentProjectPath= projectFolder;
	    currentProjectName=projectFolder.getName();
	    reloadProjectTree();
	    return true;
	}else{
	    return false;
	}
    }

    public boolean closeProject() {
	currentProjectName=null;
	currentProjectPath=null;
	currentProjectTree=null;
	return true;
    }

    public void reloadProjectTree() {
	//create the root
	DefaultMutableTreeNode root = new DefaultMutableTreeNode(currentProjectName);
	
	//create the project folders and their contents
	root = addContentToTreeNode(root,currentProjectPath);
	currentProjectTree = new JTree(root);
	currentProjectTree.setCellRenderer(new projectTreeRenderer(currentProjectPath));

    }

    private DefaultMutableTreeNode addContentToTreeNode(DefaultMutableTreeNode node, File dir) {
	if (dir.isDirectory()) {
	    File [] content = dir.listFiles();
	    for (int i=0;i<content.length;i++) {
		File f = content[i];
		if (f.isFile()){
			if (!f.getName().endsWith(".cb"))
		    node.add(new DefaultMutableTreeNode(f.getName()));
		}
		if (f.isDirectory()){
		    DefaultMutableTreeNode n = new DefaultMutableTreeNode(f.getName());
		    n = addContentToTreeNode(n,f);
		    node.add(n);
		}
	    }
	    
	}
	return node;
    }

    public JTree getCurrentProjectTree() {
	return currentProjectTree;
    }

    public String getCurrentProjectName() {
	return currentProjectName;
    }

    public File getCurrentProjectPath() {
	return currentProjectPath;
    }

    
    class projectTreeRenderer extends DefaultTreeCellRenderer {
	ImageIcon closed;
	ImageIcon open;
	ImageIcon node;

	File projectFolder;

	public projectTreeRenderer(File projectPath) {
	    closed = new ImageIcon(getClass().getResource("images/item_closed.gif"));
	    open = new ImageIcon(getClass().getResource("images/item_open.gif"));
	    node = new ImageIcon(getClass().getResource("images/item_node.gif"));
	    projectFolder = projectPath;
	    setClosedIcon(closed);
	    setOpenIcon(open);
	    setLeafIcon(node);
	}

	public Component getTreeCellRendererComponent(
						      JTree tree,
						      Object value,
						      boolean sel,
						      boolean expanded,
						      boolean leaf,
						      int row,
						      boolean hasFocus) {

	    super.getTreeCellRendererComponent(
					       tree, value, sel,
					       expanded, leaf, row,
					       hasFocus);
	    if (leaf) {
		File f = new File(projectFolder,((DefaultMutableTreeNode)value).toString());
		if (f.isDirectory()){
		    setIcon(closed);
		}
	    } 
	
	    return this;
	}

    }

}
	
