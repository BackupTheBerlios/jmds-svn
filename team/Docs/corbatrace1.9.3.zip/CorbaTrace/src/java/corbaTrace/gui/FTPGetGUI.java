package corbaTrace.gui;

/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Jean-Philippe Wilsch
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.util.*;
import java.io.*;
import com.enterprisedt.net.ftp.*;

/**
 * This class is the gui to get distant log files by FTP.
 * This class uses the com.entreprisedt.net.ftp package, under GNU LGPL Licence.
 * @author Jean-Philippe Wilsch
 */

public class FTPGetGUI extends JFrame {
    
    private static final int FRAME_WIDTH = 640;
    private static final int FRAME_HEIGHT = 460;
    
    private JPanel contentPane;
    
    private JFrame parent;
    private int parentWidth;
    private int parentHeight;
    private int parentX;
    private int parentY;
    
    private JLabel userLabel, passwdLabel, hostLabel, portLabel;
    private JTextField userTF, hostTF, portTF;
    private JPasswordField passwdTF;
    private JButton buttonConnect, buttonUnconnect;
    
    private JSeparator separator1;
    
    private JScrollPane localScroll;
    private JList local;
    private JLabel localLabel;
    private File localDir;
    private String runningDir;
    private JScrollPane distantScroll;
    private JList distant;
    private JLabel distantLabel;
    private File distantDir;
    private JButton getButton;
    
    private JSeparator separator2;
    
    private JTextArea info;
    private JScrollPane infoScroll;
    
    private FTPClient ftpclient = null;
        
    /**
     * Construct the frame
     * @param f the L2XGUI parent frame
     */
    public FTPGetGUI(JFrame f, File initLocalFile) {
	parent = f;
	parentWidth = f.getWidth();
	parentHeight = f.getHeight();
	parentX = f.getX();
	parentY = f.getY();
	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	try {
	    Init(initLocalFile);
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
	
    }
    
    /**
     * Initialize all the graphical objects of the frame
     */

    private void Init(File initLocalFile) throws Exception  {
	//the main frame
	contentPane = (JPanel) this.getContentPane();
	contentPane.setLayout(null);
	this.setResizable(false);
	this.setSize(new Dimension(FRAME_WIDTH, FRAME_HEIGHT));
	this.setBounds((parentX+((parentWidth-FRAME_WIDTH)/2)),(parentY+((parentHeight-FRAME_HEIGHT)/2)),FRAME_WIDTH, FRAME_HEIGHT);
	this.setTitle("CorbaTrace Log2SequenceDiagram - Get Distant Log File by FTP");
	
	//the host part
	hostLabel = new JLabel("Host name");
	hostLabel.setBounds(new Rectangle(10, 10, 90, 20));
	contentPane.add(hostLabel);
	hostTF = new JTextField();
	hostTF.setBounds(new Rectangle(105, 10, 150, 20));
	contentPane.add(hostTF);
	
	//the port part
	portLabel = new JLabel("Port number");
	portLabel.setBounds(new Rectangle(260, 10, 90, 20));
	contentPane.add(portLabel);
	portTF = new JTextField("21");
	portTF.setBounds(new Rectangle(355, 10, 35, 20));
	contentPane.add(portTF);
	
	//the user part
	userLabel = new JLabel("User name");
	userLabel.setBounds(new Rectangle(10, 35, 90, 20));
	contentPane.add(userLabel);
	userTF = new JTextField();
	userTF.setBounds(new Rectangle(105, 35, 95, 20));
	contentPane.add(userTF);
	
	//the password part
	passwdLabel = new JLabel("Password");
	passwdLabel.setBounds(new Rectangle(205, 35, 90, 20));
	contentPane.add(passwdLabel);
	passwdTF = new JPasswordField();
	passwdTF.setBounds(new Rectangle(300, 35, 90, 20));
	contentPane.add(passwdTF);
	
	//the connexion buttons part
	buttonConnect = new JButton("Connect");
	buttonConnect.setBounds(new Rectangle(395, 10, 110, 45));
	buttonConnect.addActionListener(new java.awt.event.ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
		    connect(hostTF.getText(),portTF.getText(),userTF.getText(),new String(passwdTF.getPassword()));
		}
	    });
	contentPane.add(buttonConnect);
	
	buttonUnconnect = new JButton("Disconnect");
	buttonUnconnect.setBounds(new Rectangle(510, 10, 110, 45));
	buttonUnconnect.addActionListener(new java.awt.event.ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
		    disconnect();
		}
	    });
	contentPane.add(buttonUnconnect);
	
	separator1 = new JSeparator();
	separator1.setBounds(new Rectangle(10, 65, 610, 1));
	contentPane.add(separator1);
	
	//the local directory part
	localScroll = new JScrollPane();
	localScroll.setBounds(new Rectangle(10, 100, 265, 185));
	local = new JList();
	local.addMouseListener(new java.awt.event.MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
		    clickOnLocal(e);
		}
	    });
	localScroll.getViewport().add(local);
	contentPane.add(localScroll);
	if (initLocalFile!=null) {
	    localDir = initLocalFile;
	}else{
	    localDir = new File(".");
	}
	runningDir = localDir.getCanonicalPath();
	localLabel = new JLabel("");
	localLabel.setBounds(new Rectangle(10, 75, 265, 20));
	contentPane.add(localLabel);

	//the get button
	getButton = new JButton("<<");
	getButton.setBounds(new Rectangle(290, 180, 60, 20));
	getButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    get((String)distant.getSelectedValue());
		}
	    });
	contentPane.add(getButton);

	//the distant directory part
	distantLabel = new JLabel("");
	distantLabel.setBounds(new Rectangle(350, 75, 265, 20));
	contentPane.add(distantLabel);
	distantScroll = new JScrollPane();
	distantScroll.setBounds(new Rectangle(355, 100, 265, 185));
	distant = new JList();
	distant.addMouseListener(new java.awt.event.MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
		    clickOnDistant(e);
		}
	    });
	distantScroll.getViewport().add(distant);
	contentPane.add(distantScroll);
	
	separator2 = new JSeparator();
	separator2.setBounds(new Rectangle(10, 295, 610, 1));
	contentPane.add(separator2);
	
	//the info textarea part
	infoScroll = new JScrollPane();
	infoScroll.setBounds(new Rectangle(10, 305, 610, 115));
	info = new JTextArea();
	info.setEditable(false);
	info.setBackground(Color.lightGray);
	infoScroll.getViewport().add(info);
	infoScroll.setBorder(new SoftBevelBorder(SoftBevelBorder.LOWERED));
	contentPane.add(infoScroll);
	
	buttonUnconnect.setEnabled(false);
	getButton.setEnabled(false);
	listLocalDir();
	
    }
    
    /**
     * This method deals with the windows events, especially the closing window event
     * @param e a window event
     */
    
    protected void processWindowEvent(WindowEvent e) {
	super.processWindowEvent(e);
	if (e.getID() == WindowEvent.WINDOW_CLOSING) {
	    if (this.ftpclient != null)
	    	disconnect();
	    parent.setEnabled(true);
	    parent.transferFocus();
	}
    }
    
     /**
     * This method initializes the FTC Client object ant list the distant directory.
     * @param host the ftp host
     * @param port the ftp port
     * @param user the user name
     * @param passwd the user's password
     * @param 
     */
    
    public void connect(String host,String port, String user, String passwd) {
	if ((!host.equals(""))&&(!port.equals(""))) {

	    info.append("Connexion to "+host+" on port "+port+"\n");
	    try{
		this.ftpclient = new FTPClient(host,Integer.parseInt(port));
		this.ftpclient.login(user,passwd);
		buttonConnect.setEnabled(false);
		buttonUnconnect.setEnabled(true);
		getButton.setEnabled(true);
		info.append("Connexion OK\n");
		listDistantDir();
	    }catch(NumberFormatException e1) {
		info.append("The port number is invalid\n");
	    }catch(IOException e2) {
		info.append("Failure of the connexion : "+e2.getMessage()+"\n");
	    }catch(FTPException e3) {
		info.append("Failure of the connexion : "+e3.getMessage()+"\n");
	    }
	}else{
	   info.append("You must specify an host and a port\n"); 
	}
    }
    /**
     * This method closes the FTP connection and destroy the FTP client object.
     */
    
    public void disconnect() {
  	info.append("Disconnexion\n");
  	try{
	    this.ftpclient.quit();
	    this.ftpclient=null;
	    buttonConnect.setEnabled(true);
	    buttonUnconnect.setEnabled(false);
	    getButton.setEnabled(false);
	    clearDistant();
	}catch(IOException e2) {
	    info.append("Failure of the disconnexion : "+e2.getMessage()+"\n");
	}catch(FTPException e3) {
	    info.append("Failure of the disconnexion : "+e3.getMessage()+"\n");
	}
    }
    
    /**
     * This methods transferts a file into the current local directory.
     * @param filename the name of the wanted file 
     */
    
    public void get(String filename) {
	if (filename!=null) {
	    info.append("Get "+filename+"\n");
	    buttonUnconnect.setEnabled(false);
	    getButton.setEnabled(false);
	    try {
		ftpclient.get(runningDir+"/"+filename,filename);
		info.append("transfert OK\n");
	    }catch(IOException e2) {
		info.append("Failure of the transfert : "+e2.getMessage()+"\n");
	    }catch(FTPException e3) {
		info.append("Failure of the transfert : "+e3.getMessage()+"\n");
	    }
	    buttonUnconnect.setEnabled(true);
	    getButton.setEnabled(true);
	    listLocalDir();
	}
    }

    /**
     * This method display the listing of the selected local directory into the corresponding JList.
     */
    
    private void listLocalDir() {
	localLabel.setText(runningDir);
	Vector list = new Vector();
	list.add("[..]");
	String[] dirList = localDir.list();
	Arrays.sort(dirList);
	for (int i=0;i<dirList.length;i++) {
	    String name = dirList[i];
	    if ((new File(runningDir+"/"+name)).isDirectory()) {
		list.add("["+name/*.toUpperCase()*/+"]");
	    }
	}
	for (int i=0;i<dirList.length;i++) {
	    String name = dirList[i];
	    if ((new File(runningDir+"/"+name)).isFile()) {
		list.add(name);
	    }
	}
	local.setListData(list);
    }

     /**
     * This method display the listing of the selected distant directory into the corresponding JList.
     */
    
    private void listDistantDir() {
	try {
	    distantLabel.setText(ftpclient.pwd());
	    Vector list = new Vector();
	    list.add("[..]");
	    String[] dirList;
	    String[] dirListComplete;
	
	    dirListComplete = ftpclient.dir("",true);
	    dirList = ftpclient.dir("");

	    for (int i=0;i<dirList.length;i++) {
		String name = dirList[i];
		String description = dirListComplete[i];
		if ((description.indexOf("<DIR>")!=-1)/*Windows FTP Server*/||(description.charAt(0)=='d'))/*Unix FTP Server*/ {
		    list.add("["+name/*.toUpperCase()*/+"]");
		}
	    }
	    for (int i=0;i<dirList.length;i++) {
		String name = dirList[i];
		String description = dirListComplete[i];
		if ((description.indexOf("<DIR>")==-1)/*Windows FTP Server*/&&(description.charAt(0)!='d'))/*Unix FTP Server*/ {
		    list.add(name);
		}
	    }
	    distant.setListData(list);
	}catch(FTPException e) {
	    info.append("Error : "+e.getMessage()+"\n");
	}catch(IOException e1) {
	    info.append("Error : "+e1.getMessage()+"\n");
	}
    }

    /**
     * This method is called when an item in the local directory listing is clicked.
     * If this item is a directory, this directory becomes the selected local directory and its listing 
     * is displayed.
     * @param e a mouse event
     */
    
    private void clickOnLocal(MouseEvent e) {
	try {
	    if (e.getClickCount() == 2) {
		String selection = (String)local.getSelectedValue();
		
		//if it's a directory
		if ((selection.startsWith("["))&&(selection.endsWith("]"))) {
		    String dirName = selection.substring(1, (selection.length()-1));
		    localDir = new File(runningDir+"/"+dirName);
		    runningDir = localDir.getCanonicalPath();
		    listLocalDir();
		    
		}
	    
	    }
	}catch(IOException e1) {
	    info.append("Error : "+e1.getMessage()+"\n");
	}
    }

    /**
     * This method is called when an item in the distant directory listingis clicked.
     * If this item is a directory, this directory becomes the selected distant directory and its listing 
     * is displayed.
     * @param e a mouse event
     */
    
    private void clickOnDistant(MouseEvent e) {
	try {
	    if (e.getClickCount() == 2) {
		String selection = (String)distant.getSelectedValue();
		
		//if it's a directory
		if ((selection.startsWith("["))&&(selection.endsWith("]"))) {
		    String dirName = selection.substring(1, (selection.length()-1));
		    ftpclient.chdir(dirName);
		    listDistantDir();
		}
	    }
	}catch(FTPException e1) {
	    info.append("Error : "+e1.getMessage()+"\n");
	}catch(IOException e2) {
	    info.append("Error : "+e2.getMessage()+"\n");
	}
    }

    /**
     * This method clears the display of the distant directory listing.
     */
    
    public void clearDistant() {
	distantLabel.setText("");
	Vector temp = new Vector();
	distant.setListData(temp);
    }
}

