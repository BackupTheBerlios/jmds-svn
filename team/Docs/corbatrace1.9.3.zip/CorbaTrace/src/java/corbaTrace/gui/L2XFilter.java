package corbaTrace.gui;

/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Jean-Philippe Wilsch
 */

import java.util.*;
import java.io.*;

/**
 * This class defines a filter for the Log2Xmi application, and all the doable actions on it.
 * @author Jean-Philippe Wilsch
 */

public class L2XFilter {

    String filter;
    /**
     * The value of the indentation used in the indent fonction, corresponding to a 4 spaces string.
     */
    public static final String INDENTATION = "    ";

    /**
     * Construct a minimal filter.
     */

    public L2XFilter () {

	filter = new String("");
	filter += "<?xml version=\"1.0\" standalone=\"no\"?>\n";
	filter += "<!DOCTYPE filter SYSTEM \"logger.dtd\">\n\n";
	filter += "<filter>\n";
	filter += indent(1)+"<message_types>\n";
	filter += indent(1)+"</message_types>\n";
	filter += indent(1)+"<dates>\n";
	filter += indent(1)+"</dates>\n";
	filter += indent(1)+"<methods>\n";
	filter += indent(1)+"</methods>\n";
	filter += indent(1)+"<objects>\n";
	filter += indent(1)+"</objects>\n";
	filter += "</filter>\n";

    }
    
    /**
     * This method returns a string with <i>nb</i> identations.
     * @param nb The number of indentations wanted
     * @return A string containing the identation(s)
     */

    public String indent(int nb) {
	String s="";
	for (int i=1;i<=nb;i++)
	    s+=INDENTATION;
	return s;
    }
    
    /**
     * This methods returns the filter as a String.
     * @return A string containing the filter
     */

    public String getString() {
	
	return filter;

    }

    /**
     * This methods adds a object in the filter, without checking if this object already exists.
     * @param objectId the ID of the object to add
     */

    private void addObject(String objectId) {
	String before = filter.substring(0,filter.indexOf(indent(1)+"</objects>"));
	String after = filter.substring(filter.indexOf(indent(1)+"</objects>"),filter.length());

	filter = before;
	filter += indent(2)+"<object id=\""+objectId+"\">\n";
	filter += indent(3)+"<message_types>\n";
	filter += indent(3)+"</message_types>\n";
	filter += indent(3)+"<dates>\n";
	filter += indent(3)+"</dates>\n";
	filter += indent(3)+"<methods>\n";
	filter += indent(3)+"</methods>\n";
	filter += indent(2)+"</object>\n";
	filter += after;
	
    }

    /**
     * This methods adds a message type related to the specified <i>object</i> in the filter.
     * @param object the object to which the message type is related
     * @param value the value of the message type
     */

    public void addMessageType(String object,String value) {
	int i,j;
	if (object==null) {
	    i = filter.indexOf(indent(1)+"</message_types>");
	    j=2;
	}else{
	    int itemp = filter.indexOf(indent(2)+"<object id=\""+object+"\">");
	    if (itemp==-1) {
		this.addObject(object);
		itemp = filter.indexOf(indent(2)+"<object id=\""+object+"\">");
	    }
	    i = filter.indexOf(indent(3)+"</message_types>",itemp);
	    j=4;
	}
	String before = filter.substring(0,i);
	String after = filter.substring(i,filter.length());

	filter = before;
	filter += indent(j)+"<type value=\""+value+"\"/>\n";
	filter += after;
    }

    /**
     * This methods adds a date related to the specified <i>object</i> in the filter.
     * @param object the object to which the date is related
     * @param dateType the type of the date : <b>After</b>,<b>Before</b> or <b>Between</b>
     * @param date1 a string array containing the first date in this order : day,month,year,hour,minute,second
     * @param date2 a string array containing the second date. It is only used in case of a <b>Between</b> date type
     */

    public void addDate(String object,String dateType,String[] date1,String[] date2) {
	int i,j;
	if (object==null) {
	    i = filter.indexOf(indent(1)+"</dates>");
	    j=2;
	}else{
	    int itemp = filter.indexOf(indent(2)+"<object id=\""+object+"\">");
	    if (itemp==-1) {
		this.addObject(object);
		itemp = filter.indexOf(indent(2)+"<object id=\""+object+"\">");
	    }
	    i = filter.indexOf(indent(3)+"</dates>",itemp);
	    j=4;
	}

	String before = filter.substring(0,i);
	String after = filter.substring(i,filter.length());

	filter = before;

	if (dateType.equals("After") || dateType.equals("Before")) {
	    
	    filter += indent(j)+"<"+dateType.toLowerCase()+" date=\""+date1[2]+"-"+date1[1]+"-"+date1[0]+"T"+date1[3]+":"+date1[4]+":"+date1[5]+".000\"/>\n";

	}else{
	    
	    filter += indent(j)+"<"+dateType.toLowerCase()+" from=\""+date1[2]+"-"+date1[1]+"-"+date1[0]+"T"+date1[3]+":"+date1[4]+":"+date1[5]+".000\" to=\""+date2[2]+"-"+date2[1]+"-"+date2[0]+"T"+date2[3]+":"+date2[4]+":"+date2[5]+".000\"/>\n";

	}
	
	filter += after;
    }

    /**
     * This methods adds a method related to the specified <i>object</i> in the filter, 
     * without checking if this method already exists.
     * @param object the object to which the method is related
     * @param dateType the name of the method
     */

    private void addMethod(String object, String methodName) {
	int i,j;
	if (object==null) {
	    i = filter.indexOf(indent(1)+"</methods>");
	    j=2;
	}else{
	    int itemp = filter.indexOf(indent(2)+"<object id=\""+object+"\">");
	    if (itemp==-1) {
		this.addObject(object);
		itemp = filter.indexOf(indent(2)+"<object id=\""+object+"\">");
	    }
	    i = filter.indexOf(indent(3)+"</methods>",itemp);
	    j=4;
	}

	String before = filter.substring(0,i);
	String after = filter.substring(i,filter.length());

	filter = before;
	filter += indent(j)+"<method name=\""+methodName+"\">\n"+indent(j)+"</method>\n";
	filter += after;

    }
    
    /**
     * This methods adds a method related to the specified <i>object</i> in the filter, with no argument information.
     * @param object the object to which the method is related
     * @param methodName the name of the method
     */

    public void addMethodWithNoArg(String object, String methodName) {
	int i1,i2,j,itemp,itemp2;
	String tempObject="";
	if (object==null) {
	    System.out.println("f:Global");
	    i1 = filter.indexOf("\n"+indent(2)+"<method name=\""+methodName+"\">");
	    if (i1==-1) {
		this.addMethod(object,methodName);
	    }
	}else{ //a specific object
	    System.out.println("f:"+object);
	    itemp = filter.indexOf(indent(2)+"<object id=\""+object+"\">");
	    if (itemp==-1) {
		this.addObject(object);
		itemp = filter.indexOf(indent(2)+"<object id=\""+object+"\">");
	    }
	   
	    //a string with the object
	    itemp2 = filter.indexOf(indent(2)+"</object>",itemp);
	    tempObject = filter.substring(itemp,itemp2+indent(2).length()+9);
	    i1 = tempObject.indexOf(indent(4)+"<method name=\""+methodName+"\">");
	    
	    if (i1==-1) {
		this.addMethod(object,methodName);
		itemp2 = filter.indexOf(indent(2)+"</object>",itemp);
		tempObject = filter.substring(itemp,itemp2+indent(2).length()+9);
	    }
	    String filterTemp = filter;
	    filter = filterTemp.substring(0,itemp);
	    filter += tempObject;
	    filter += filterTemp.substring(itemp2+indent(2).length()+9,filterTemp.length());
	    
	}
    }

    /**
     * This methods adds a method related to the specified <i>object</i> in the filter, 
     * with an argument position information.
     * @param object the object to which the method is related
     * @param methodName the name of the method
     * @param pos the argument position
     * @param value the argument value
     */

    public void addMethodWithArgPos(String object, String methodName, String pos, String value) {
	this.addMethodWithArg(object,methodName,"<argumentAt position=",pos,value);
    }
    
    /**
     * This methods adds a method related to the specified <i>object</i> in the filter, 
     * with an argument type information.
     * @param object the object to which the method is related
     * @param methodName the name of the method
     * @param type the argument type
     * @param value the argument value
     */

    public void addMethodWithArgType(String object, String methodName, String type, String value) {
	this.addMethodWithArg(object,methodName,"<typedArgument type=",type,value);
    }

    /**
     * This methods adds a method related to the specified <i>object</i> in the filter, 
     * with an argument information.
     * @param object the object to which the method is related
     * @param methodName the name of the method
     * @param tag the XML tag corresponding to the argument information
     * @param type the argument position or type
     * @param value the argument value
     */

    private void addMethodWithArg(String object, String methodName, String tag, String posOrType, String value) {
	int i1,i2,j,itemp,itemp2;
	String tempObject="";
	if (object==null) {
	    i1 = filter.indexOf("\n"+indent(2)+"<method name=\""+methodName+"\">");
	    if (i1==-1) {
		this.addMethod(object,methodName);
		i1 = filter.indexOf(indent(2)+"<method name=\""+methodName+"\">");
	    }
	    i2 = filter.indexOf(indent(2)+"</method>");
	    j=3;

	    String filterTemp=filter;
	    filter = filterTemp.substring(0,i2);
	    filter += indent(j)+tag+"\""+posOrType+"\" value=\""+value+"\"/>\n";
	    filter += filterTemp.substring(i2,filterTemp.length());
	    
	}else{
	    itemp = filter.indexOf(indent(2)+"<object id=\""+object+"\">");
	    if (itemp==-1) {
		this.addObject(object);
		itemp = filter.indexOf(indent(2)+"<object id=\""+object+"\">");
	    }
	   
	    
	    itemp2 = filter.indexOf(indent(2)+"</object>",itemp);
	    //a string with the object
	    tempObject = filter.substring(itemp,itemp2+indent(2).length()+9);
	    i1 = tempObject.indexOf(indent(4)+"<method name=\""+methodName+"\">");
	    
	    if (i1==-1) {
		this.addMethod(object,methodName);
		itemp2 = filter.indexOf(indent(2)+"</object>",itemp);
		tempObject = filter.substring(itemp,itemp2+indent(2).length()+9);
		i1 = tempObject.indexOf(indent(4)+"<method name=\""+methodName+"\">");
	    }
	    i2 = tempObject.indexOf(indent(4)+"</method>",i1);
	    j=5;

	    String tempObjectTemp=tempObject;
	    tempObject = tempObjectTemp.substring(0,i2);
	    tempObject += indent(j)+tag+"\""+posOrType+"\" value=\""+value+"\"/>\n";
	    tempObject += tempObjectTemp.substring(i2,tempObjectTemp.length());
	      
	    String filterTemp = filter;
	    filter = filterTemp.substring(0,itemp);
	    filter += tempObject;
	    filter += filterTemp.substring(itemp2+indent(2).length()+9,filterTemp.length());
	}
    }

    /**
     * This methods writes the filter in a file.
     * @param file the file in which to write the file
     */

    public int writeFilterFile(File file) {
	try {
	    FileWriter fw = new FileWriter(file);
	    fw.write(filter);
	    fw.flush();
	    fw.close();
	    return 0;
	}catch(IOException e1) {
	    return 1;
	}
    }
    
    
}

