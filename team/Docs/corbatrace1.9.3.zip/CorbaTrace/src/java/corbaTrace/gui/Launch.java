package corbaTrace.gui;

/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Jean-Philippe Wilsch
 */

/**
 * This class runs the log2xmi GUI
 */

public class Launch {
    
    public static void main(String args[]) {
	
	boolean packFrame = false;
	
	L2XGUI gui = new L2XGUI();
	
	if (packFrame) {
	    gui.pack();
	}
	else {
	    gui.validate();
   	}
   	gui.setVisible(true);
   	
    }
    
}
