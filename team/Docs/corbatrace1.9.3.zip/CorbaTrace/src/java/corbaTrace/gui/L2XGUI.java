package corbaTrace.gui;

/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Jean-Philippe Wilsch
 */

import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.filechooser.*;
import java.util.*;
import java.io.*;
import corbaTrace.log2sequenceDiagram.*;
import svgSequenceDiagramObjects.*;

/**
 * This class is the main GUI of Log2Xmi
 * @author Jean-Philippe Wilsch
 */

public class L2XGUI extends JFrame {
    
    private static final int FRAME_WIDTH = 780;
    private static final int FRAME_HEIGHT = 510;
    
    private JPanel contentPane;
    
    private JMenuBar menuBar;
    private JMenu menuProject;
    private JMenuItem newProject;
    private JMenuItem openProject;
    private JMenuItem closeProject;
    private JMenuItem quit;
    private ProjectManager projectManager;
    private JMenu menuTools;
    private JMenuItem getDistantLogFile;
    private JMenuItem createFilterFile;
    private JMenuItem viewSVGGraph;
    private JMenu menuHelp;
    private JMenuItem help;
    private JMenuItem about;
    
    private JToolBar toolBar;
    private JToolBarButton newProjectButton,openProjectButton,getButton,createButton,viewButton,helpButton,quitButton;
    private JLabel separatorLabel1,separatorLabel2,separatorLabel3;
        
    private JSeparator separator1;
    
    private JLabel projectBrowserLabel;
    private JTree projectTree;
    private JScrollPane projectScroll;
    private JButton reloadTreeButton,addLogButton,addFilterButton;
    private JLabel logLabel;
    private JScrollPane logFilesListScroll;
    private JList logFilesList;
    private JButton removeLogFilesButton;
    private Vector parsedLogs;
    private Hashtable parsedLogsObjects;
    private Hashtable parsedLogsMethods;
    private Vector logFiles;
    private JLabel filterLabel;
    private JTextField filterTF;
    private JButton createFilterButton,removeFilterButton;
    
    private JSeparator separator3;
    
    private JTabbedPane optionsTabbedPane;

    private JLabel optionsLabel,scaleLabel;
    private JPanel fileOptions;
    private JPanel generalOptions;
    private JCheckBox oCheckBox,xrCheckBox,xmCheckBox,vCheckBox,sCheckBox,dCheckBox,xmiCheckBox,texCheckBox,svgCheckBox;
    private JLabel XMIFilenameLabel,vCBLabel;
    private JTextField XMIFilenameTF,svgScale;
    private JSeparator separator4,separator6;
    
    private JSeparator separator5;
    
    private JButton launchButton;
    
    /**Construct the frame*/
    public L2XGUI() {
	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	try {
	    Init();
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
    }
    
    /**
     * Initialize all the graphical objects of the frame
     */

    private void Init() throws Exception  {
	ImageIcon img;
	JToolBar.Separator s;

	//the main frame
	contentPane = (JPanel) this.getContentPane();
	contentPane.setLayout(null);
	this.setResizable(false);
	this.setSize(new Dimension(FRAME_WIDTH,FRAME_HEIGHT));
	this.setBounds(0,0,FRAME_WIDTH,FRAME_HEIGHT);
	this.setTitle("CorbaTrace Log2SequenceDiagram");
	
	
	//the menubar
	menuBar = new JMenuBar();
	menuBar.setBounds(new Rectangle(0, 0, FRAME_WIDTH, 20));

	menuProject = new JMenu();
	menuProject.setText("Project");
	menuProject.setMnemonic(KeyEvent.VK_P);
	img = new ImageIcon(getClass().getResource("images/newProjectSmall.gif"));
	newProject = new JMenuItem("New project",img);
	newProject.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,InputEvent.CTRL_MASK));
	newProject.setMnemonic(KeyEvent.VK_N);
	newProject.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    newProject();

		}
	    });
	img = new ImageIcon(getClass().getResource("images/openProjectSmall.gif"));
	openProject = new JMenuItem("Open existing project",img);
	openProject.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,InputEvent.CTRL_MASK));
	openProject.setMnemonic(KeyEvent.VK_O);
	openProject.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    openProject();

		}
	    });
	closeProject = new JMenuItem("Close current project");
	closeProject.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    closeProject();

		}
	    });
	projectManager = new ProjectManager();
	img = new ImageIcon(getClass().getResource("images/quitSmall.gif"));   
	quit = new JMenuItem("Quit",img);
	quit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,InputEvent.CTRL_MASK));
	quit.setMnemonic(KeyEvent.VK_Q);
	quit.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    quit();
		}
	    });
	menuProject.add(newProject);
	menuProject.add(openProject);
	menuProject.add(closeProject);
	menuProject.addSeparator();
	menuProject.add(quit);
	menuBar.add(menuProject);
	

	menuTools = new JMenu();
	menuTools.setText("Tools");
	menuTools.setMnemonic(KeyEvent.VK_M);
	img = new ImageIcon(getClass().getResource("images/getSmall.gif"));
	getDistantLogFile = new JMenuItem("Get distant log files by FTP",img);
	getDistantLogFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G,InputEvent.CTRL_MASK));
	getDistantLogFile.setMnemonic(KeyEvent.VK_G);
	getDistantLogFile.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    runFTPGetGUI();
		}
	    });
	img = new ImageIcon(getClass().getResource("images/createSmall.gif"));   
	createFilterFile = new JMenuItem("Create a filter file",img);
	createFilterFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F,InputEvent.CTRL_MASK));
	createFilterFile.setMnemonic(KeyEvent.VK_F);
	createFilterFile.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    runL2XCreateFilterGUI();
		}
	    });
	img = new ImageIcon(getClass().getResource("images/viewSmall.gif"));   
	viewSVGGraph = new JMenuItem("View a SVG graph",img);
	viewSVGGraph.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,InputEvent.CTRL_MASK));
	viewSVGGraph.setMnemonic(KeyEvent.VK_S);
	viewSVGGraph.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    runSVGViewer();
		}
	    });
	img = new ImageIcon(getClass().getResource("images/quitSmall.gif"));   
	quit = new JMenuItem("Quit",img);
	quit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,InputEvent.CTRL_MASK));
	quit.setMnemonic(KeyEvent.VK_Q);
	quit.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    quit();
		}
	    });
	menuTools.add(getDistantLogFile);
	menuTools.add(createFilterFile);
	menuTools.add(viewSVGGraph);
	menuBar.add(menuTools);
	
	menuHelp = new JMenu();
	menuHelp.setText("Help");
	menuHelp.setMnemonic(KeyEvent.VK_H);
	img = new ImageIcon(getClass().getResource("images/helpSmall.gif"));   
	help = new JMenuItem("Help",img);
	help.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H,InputEvent.CTRL_MASK));
	help.setMnemonic(KeyEvent.VK_H);
	help.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    runHelp();
		}
	    });
	about = new JMenuItem("About");
	about.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,InputEvent.CTRL_MASK));
	about.setMnemonic(KeyEvent.VK_A);
	about.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    about();
		}
	    });
	menuHelp.add(help);
	menuHelp.addSeparator();
	menuHelp.add(about);
	menuBar.add(menuHelp);


	contentPane.add(menuBar);
	
	//the toolbar
	toolBar = new JToolBar();
	toolBar.setBounds(new Rectangle(0, 20, FRAME_WIDTH, 40));
	toolBar.setFloatable(false);
	
	    

	img = new ImageIcon(getClass().getResource("images/newProjectSmall.gif"));
	newProjectButton = new JToolBarButton(img);
	newProjectButton.setBounds(new Rectangle(0, 0, 40, 50));
	newProjectButton.setFocusPainted(false);
	newProjectButton.setToolTipText("New project");
	newProjectButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    newProject();
		}
	    });
	toolBar.add(newProjectButton);
	img = new ImageIcon(getClass().getResource("images/openProjectSmall.gif"));
	openProjectButton = new JToolBarButton(img);
	openProjectButton.setBounds(new Rectangle(0, 0, 40, 50));
	openProjectButton.setFocusPainted(false);
	openProjectButton.setToolTipText("Open an existing project");
	openProjectButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    openProject();
		}
	    });
	toolBar.add(openProjectButton);

	s = new JToolBar.Separator();
	toolBar.add(s);
	s = new JToolBar.Separator(new Dimension(2,25));
	s.setBorder(new EtchedBorder());
	toolBar.add(s);
	s = new JToolBar.Separator();
	toolBar.add(s);
	
	img = new ImageIcon(getClass().getResource("images/getSmall.gif"));
	getButton = new JToolBarButton(img);
	getButton.setBounds(new Rectangle(0, 0, 40, 50));
	getButton.setFocusPainted(false);
	getButton.setToolTipText("Get distant log files by FTP");
	getButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    runFTPGetGUI();
		}
	    });
	toolBar.add(getButton);
	img = new ImageIcon(getClass().getResource("images/createSmall.gif"));
	createButton = new JToolBarButton(img);
	createButton.setBounds(new Rectangle(0, 0, 44, 50));
	createButton.setFocusPainted(false);
	createButton.setToolTipText("Create a filter file");
	createButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    runL2XCreateFilterGUI();
		}
	    });
	toolBar.add(createButton);
	img = new ImageIcon(getClass().getResource("images/viewSmall.gif"));
	viewButton = new JToolBarButton(img);
	viewButton.setBounds(new Rectangle(0, 0, 44, 50));
	viewButton.setFocusPainted(false);
	viewButton.setToolTipText("View a SVG graph");
	viewButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    runSVGViewer();
		}
	    });
	toolBar.add(viewButton);

	s = new JToolBar.Separator();
	toolBar.add(s);
	s = new JToolBar.Separator(new Dimension(2,25));
	s.setBorder(new EtchedBorder());
	toolBar.add(s);
	s = new JToolBar.Separator();
	toolBar.add(s);
	
	img = new ImageIcon(getClass().getResource("images/helpSmall.gif"));
	helpButton = new JToolBarButton(img);
	helpButton.setBounds(new Rectangle(0, 0, 44, 50));
	helpButton.setFocusPainted(false);
	helpButton.setToolTipText("Help");
	helpButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    runHelp();
		}
	    });
	toolBar.add(helpButton);

	s = new JToolBar.Separator();
	toolBar.add(s);
	s = new JToolBar.Separator(new Dimension(2,25));
	s.setBorder(new EtchedBorder());
	toolBar.add(s);
	s = new JToolBar.Separator();
	toolBar.add(s);
	
	img = new ImageIcon(getClass().getResource("images/quitSmall.gif"));
	quitButton = new JToolBarButton(img);
	quitButton.setBounds(new Rectangle(0, 0, 44, 50));
	quitButton.setFocusPainted(false);
	quitButton.setToolTipText("Quit");
	quitButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    quit();
		}
	    });
	toolBar.add(quitButton);
	contentPane.add(toolBar);
	
	separator1 = new JSeparator();
	separator1.setBounds(new Rectangle(0, 60, FRAME_WIDTH, 1));
	contentPane.add(separator1);
	
	//the project browser part
	projectBrowserLabel = new JLabel("Project Browser");
	projectBrowserLabel.setBounds(new Rectangle(10, 65, 100, 20));
	contentPane.add(projectBrowserLabel);
	projectScroll = new JScrollPane();
	projectScroll.setBounds(new Rectangle(10,90,370,150));
	contentPane.add(projectScroll);
	
	reloadTreeButton = new JButton("Reload");
	reloadTreeButton.setBounds(new Rectangle(10, 245, 100, 25)); 
	reloadTreeButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    reloadTree();
		}
	    });
	contentPane.add(reloadTreeButton);
	addLogButton = new JButton("Add Log");
	addLogButton.setBounds(new Rectangle(120, 245, 100, 25));
	addLogButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    addLogFiles();
		}
	    });
	contentPane.add(addLogButton);
	addFilterButton = new JButton("Add Filter");
	addFilterButton.setBounds(new Rectangle(230, 245, 100, 25));
	addFilterButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    addFilter();
		}
	    });
	contentPane.add(addFilterButton);
	reloadTreeButton.setEnabled(false);
	addLogButton.setEnabled(false);
	addFilterButton.setEnabled(false);

	
	
	//the log and filter files part
	logFiles = new Vector();
	logLabel = new JLabel("Log Files");
	logLabel.setBounds(new Rectangle(700, 65, 70, 20));
	contentPane.add(logLabel);
	logFilesListScroll = new JScrollPane();
	logFilesListScroll.setBounds(new Rectangle(400, 90, 370, 70));
	logFilesList = new JList();
	logFilesListScroll.getViewport().add(logFilesList);
	contentPane.add(logFilesListScroll);
	removeLogFilesButton = new JButton("Remove");
	removeLogFilesButton.setBounds(new Rectangle(670, 165, 100, 25)); 
	removeLogFilesButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    removeLogFiles();
		}
	    });
	contentPane.add(removeLogFilesButton);
	filterLabel = new JLabel("Filter Files");
	filterLabel.setBounds(new Rectangle(700, 195, 70, 20));
	contentPane.add(filterLabel);
	filterTF = new JTextField("No filter selected");
	filterTF.setEditable(false);
	filterTF.setBounds(new Rectangle(400, 220, 370, 20));
	contentPane.add(filterTF);
	createFilterButton = new JButton("Create");
	createFilterButton.setBounds(new Rectangle(550, 245, 100, 25)); 
	createFilterButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    runL2XCreateFilterGUI();
		}
	    });
	contentPane.add(createFilterButton);
	removeFilterButton = new JButton("Remove");
	removeFilterButton.setBounds(new Rectangle(670, 245, 100, 25)); 
	removeFilterButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    removeFilter();
		}
	    });
	contentPane.add(removeFilterButton);

	parsedLogs = new Vector();
	parsedLogsObjects = new Hashtable();
	parsedLogsMethods = new Hashtable();


	separator3 = new JSeparator();
	separator3.setBounds(new Rectangle(5, 275, FRAME_WIDTH-15, 1));
	contentPane.add(separator3);
       
	//the options part
	optionsTabbedPane = new JTabbedPane();
	optionsTabbedPane.setBounds(new Rectangle(5, 280, FRAME_WIDTH-15, 150));
	fileOptions = new JPanel();
	fileOptions.setLayout(null);
	generalOptions = new JPanel();
	generalOptions.setLayout(null);
	
	oCheckBox = new JCheckBox("Specify output filename");
	oCheckBox.setBounds(new Rectangle(10, 10, 170, 20));
	oCheckBox.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    oCheckBoxPressed();
		}
	    });
	fileOptions.add(oCheckBox);
	XMIFilenameLabel = new JLabel("Output filename");
	XMIFilenameLabel.setBounds(new Rectangle(35, 40, 150, 20));
	fileOptions.add(XMIFilenameLabel);
	XMIFilenameTF = new JTextField();
	XMIFilenameTF.setBounds(new Rectangle(35, 70, 150, 20));
	fileOptions.add(XMIFilenameTF);
	XMIFilenameLabel.setEnabled(false);
	XMIFilenameTF.setEnabled(false);
	separator4 = new JSeparator(SwingConstants.VERTICAL);
	separator4.setBounds(new Rectangle(200,5,1,120));
	fileOptions.add(separator4);
	xmiCheckBox = new JCheckBox("Generate XMI file(*.xmi)");
	xmiCheckBox.setBounds(new Rectangle(210, 10, 220, 20));
	fileOptions.add(xmiCheckBox);
	xmiCheckBox.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    xmiCheckBoxPressed();
		}
	    });
	xrCheckBox = new JCheckBox("Add Rational Rose extensions to the XMI output file");
	xrCheckBox.setBounds(new Rectangle(220, 40, 325, 20));
	fileOptions.add(xrCheckBox);
	xmCheckBox = new JCheckBox("Add Magic Draw extensions to the XMI output file");
	xmCheckBox.setBounds(new Rectangle(220, 70, 325, 20));
	fileOptions.add(xmCheckBox);
	xrCheckBox.setEnabled(false);
	xmCheckBox.setEnabled(false);
	separator6 = new JSeparator(SwingConstants.VERTICAL);
	separator6.setBounds(new Rectangle(550,5,1,120));
	fileOptions.add(separator6);
	texCheckBox = new JCheckBox("Generate TeX file(*.tex)");
	texCheckBox.setBounds(new Rectangle(560, 10, 220, 20));
	fileOptions.add(texCheckBox);
	svgCheckBox = new JCheckBox("Generate SVG file(*.svg)",true);
	svgCheckBox.setBounds(new Rectangle(560, 50, 220, 20));
	fileOptions.add(svgCheckBox);
	svgCheckBox.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    svgCheckBoxPressed();
		}
	    });
	scaleLabel = new JLabel("Scale");
	scaleLabel.setBounds(new Rectangle(580,80,60,20));
	fileOptions.add(scaleLabel);
	svgScale = new JTextField("1");
	svgScale.setBounds(new Rectangle(645,80,50,20));
	fileOptions.add(svgScale);


	vCheckBox = new JCheckBox("Do not validate XML logs with DTD");
	vCheckBox.setBounds(new Rectangle(10, 10, 350, 20));
	generalOptions.add(vCheckBox);
	vCBLabel = new JLabel("(use only well formed logs)");
	vCBLabel.setBounds(new Rectangle(10, 35, 350, 20));
	generalOptions.add(vCBLabel);
	sCheckBox = new JCheckBox("Do not synchronize objects' clock");
	sCheckBox.setBounds(new Rectangle(10, 70, 350, 20));
	generalOptions.add(sCheckBox);
	dCheckBox = new JCheckBox("Show more infos on screen (debug mode)");
	dCheckBox.setBounds(new Rectangle(10, 100, 350, 20));
	generalOptions.add(dCheckBox);
	
	optionsTabbedPane.add(fileOptions,"File options");
	optionsTabbedPane.add(generalOptions,"General options");
	contentPane.add(optionsTabbedPane);
	
	separator5 = new JSeparator();
	separator5.setBounds(new Rectangle(5, 435, FRAME_WIDTH-15, 1));
	contentPane.add(separator5);
	
	launchButton = new JButton("Launch Log2SequenceDiagram...");
	launchButton.setBounds(new Rectangle((FRAME_WIDTH-300)/2, 445, 300, 30));
	launchButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    launch();
		}
	    });
	contentPane.add(launchButton);
	launchButton.setEnabled(false);
    }
    
    /**
     * This method deals with the windows events, especially the closing window event
     * @param e a window event
     */

    protected void processWindowEvent(WindowEvent e) {
	super.processWindowEvent(e);
	if (e.getID() == WindowEvent.WINDOW_CLOSING) {
	    System.exit(0);
	}
    }
    
    /**
     * TODO : comment
     */

    public void newProject() {
    	JFileChooser chooser = new JFileChooser(".");
    	chooser.setMultiSelectionEnabled(false);
	chooser.setDialogTitle("New project");
	int returnVal = chooser.showOpenDialog(this);
    	if(returnVal == JFileChooser.APPROVE_OPTION) {
	    File directory = chooser.getCurrentDirectory();
	    String name = chooser.getName(chooser.getSelectedFile());
	    if (!projectManager.newProject(directory,name)) 
		JOptionPane.showMessageDialog(null, "Creation of the project failed", "Error", JOptionPane.ERROR_MESSAGE);
	    else{
		projectScroll.getViewport().removeAll();
		projectTree = projectManager.getCurrentProjectTree();
		projectScroll.getViewport().add(projectTree);
		this.setTitle("CorbaTrace Log2SequenceDiagram - "+projectManager.getCurrentProjectName());
		reloadTreeButton.setEnabled(true);
		addLogButton.setEnabled(true);
		addFilterButton.setEnabled(true);
		launchButton.setEnabled(true);
	    }
	}
	
	
    }

    /**
     * TODO : comment
     */

    public void openProject() {
	JFileChooser chooser = new JFileChooser(".");
    	chooser.setMultiSelectionEnabled(false);
	chooser.setDialogTitle("Open project");
	QuickFileFilter filter = new QuickFileFilter();
	filter.setExtension("cb");
	filter.setDescription("CorbaTrace Project File");
	chooser.setFileFilter(filter);
	int returnVal = chooser.showOpenDialog(this);
    	if(returnVal == JFileChooser.APPROVE_OPTION) {
	    File projectFile = chooser.getSelectedFile();
	    if (!projectManager.openProject(projectFile))
		JOptionPane.showMessageDialog(null, "Opening of the project failed", "Error", JOptionPane.ERROR_MESSAGE);
	    else{
		projectScroll.getViewport().removeAll();
		projectTree = projectManager.getCurrentProjectTree();
		
		
		//Test double clic sur Tree
		projectTree.addMouseListener(new MouseAdapter() {
    	public void mouseClicked(MouseEvent e) {
        if (e.getClickCount()>1) {
        	DefaultMutableTreeNode node = (DefaultMutableTreeNode)projectTree.getLastSelectedPathComponent();
        	TreePath treepath = projectTree.getSelectionPath();
        	String path = projectManager.getCurrentProjectPath().getPath();
        	for (int i=1;i<treepath.getPathCount();i++)
        		path = path+"\\"+treepath.getPathComponent(i);
        	if (path.endsWith(".svg"))
        		runSVGViewer(new File(path));
        	
        }
      }
    });
    


		
		projectScroll.getViewport().add(projectTree);
		this.setTitle("CorbaTrace Log2SequenceDiagram - "+projectManager.getCurrentProjectName());
		reloadTreeButton.setEnabled(true);
		addLogButton.setEnabled(true);
		addFilterButton.setEnabled(true);
		launchButton.setEnabled(true);
	    }
	}
	
    }

    /**
     * TODO : comment
     */

    public void closeProject() {
	projectManager.closeProject();
	projectScroll.getViewport().removeAll();
	projectScroll.repaint();
	projectTree = null;
	this.setTitle("CorbaTrace Log2SequenceDiagram");
	reloadTreeButton.setEnabled(false);
	addLogButton.setEnabled(false);
	addFilterButton.setEnabled(false);
	launchButton.setEnabled(false);
	removeFilter();
	removeAllLogFiles();
	
    }

    /**
     * TODO : comment
     */

    public void reloadTree() {
	if (projectManager.getCurrentProjectName()!=null) {
	    projectManager.reloadProjectTree();
	    projectScroll.getViewport().removeAll();
	    projectTree = projectManager.getCurrentProjectTree();
	    projectScroll.getViewport().add(projectTree);
	}
    }

    /**
     * This method runs the get distant files interface.
     */

    public void runFTPGetGUI() {
  	boolean packFrame = false;
	
	FTPGetGUI gui = new FTPGetGUI(this,projectManager.getCurrentProjectPath());
	
	if (packFrame) {
	    gui.pack();
	}
	else {
	    gui.validate();
   	}
   	gui.setVisible(true);
	//this.setEnabled(false);
    }
    /**
     * This method runs the create filter file interface.
     */

    public void runL2XCreateFilterGUI() {
  	parseLogFiles();

	Vector allObjects = new Vector();
	allObjects.addElement("Global");
	Vector allMethods = new Vector();

	Enumeration allObjectsTemp = parsedLogsObjects.elements();
	while (allObjectsTemp.hasMoreElements()) {
	    Vector o = (Vector)allObjectsTemp.nextElement();
	    for (int i=0;i<o.size();i++) {
		if (!(allObjects.contains(o.elementAt(i))))
		    allObjects.addElement(o.elementAt(i));
	    }
	}       
	
	Enumeration allMethodsTemp = parsedLogsMethods.elements();
	while (allMethodsTemp.hasMoreElements()) {
	    Vector m = (Vector)allMethodsTemp.nextElement();
	    for (int i=0;i<m.size();i++) {
		if (!(allMethods.contains(m.elementAt(i))))
		    allMethods.addElement(m.elementAt(i));
	    }
	}
	
	boolean packFrame = false;
	L2XCreateFilterGUI gui = new L2XCreateFilterGUI(this,allObjects,allMethods,projectManager.getCurrentProjectPath());
	
	if (packFrame) {
	    gui.pack();
	}
	else {
	    gui.validate();
   	}
   	gui.setVisible(true);
	//this.setEnabled(false);
    }
    
    /**
     * This method runs the SVG Viewer
     */

    public void runSVGViewer() {
	boolean packFrame = false;
	
	SVGViewer gui = new SVGViewer(this,projectManager.getCurrentProjectPath());
	
	if (packFrame) {
	    gui.pack();
	}
	else {
	    gui.validate();
   	}
   	gui.setVisible(true);
	//this.setEnabled(false);
  }
  
  /**
     * This method runs the SVG Viewer
     */

    public void runSVGViewer(File file) {
	boolean packFrame = false;
	
	SVGViewer gui = new SVGViewer(this,projectManager.getCurrentProjectPath(),file);
	
	if (packFrame) {
	    gui.pack();
	}
	else {
	    gui.validate();
   	}
   	gui.setVisible(true);
	//this.setEnabled(false);
    }

    /**
     * This method closes the application.
     */

    public void quit() {
  	System.exit(0);
    }
    
    public void runHelp() {
	boolean packFrame = false;
	
	HTMLViewer gui = new HTMLViewer(this);
	
	if (packFrame) {
	    gui.pack();
	}
	else {
	    gui.validate();
   	}
   	gui.setVisible(true);
	//this.setEnabled(false);
    }
    
    public void about() {
	boolean packFrame = false;
	
	L2XAbout gui = new L2XAbout(this);
	
	if (packFrame) {
	    gui.pack();
	}
	else {
	    gui.validate();
   	}
   	gui.setVisible(true);
	this.setEnabled(false);
    }
    

    /**
     * This method runs an open file dialog window where the user can select the files he wants to add to the log files list.
     */
   
    public void addLogFiles() {
    	TreePath[] tp = projectTree.getSelectionPaths();
	for (int i=0;i<tp.length;i++) {
	    String path = "";
	    for (int j=1;j<tp[i].getPathCount();j++) {
		path += "/"+tp[i].getPathComponent(j).toString();
		
	    }
	    File f = new File(projectManager.getCurrentProjectPath(),path);
	    if (f.isFile())
		logFiles.add(f.getAbsolutePath());
	}
	logFilesList.setListData(logFiles);
    }
    
    /**
     * This method removes the selected files from the log files list.
     */
    
    public void removeLogFiles() {
    	Object[] selectedFilenames = logFilesList.getSelectedValues();
    	for (int i=0;i<selectedFilenames.length;i++) {
	    String filename = (String)selectedFilenames[i];
	    //remove the log file from the list
	    logFiles.remove(filename);
	    //remove the log filename from the parsedLogs vector
	    parsedLogs.remove(filename);
	    //remove the informations related to this log file in the objects and methods hashtables
	    parsedLogsObjects.remove(filename);
	    parsedLogsMethods.remove(filename);
	}
	logFilesList.setListData(logFiles);
	
	
    }

    /**
     * TODO : comment
     */
    
    public void removeAllLogFiles() {
	logFiles.removeAllElements();
	parsedLogs.removeAllElements();
	parsedLogsObjects.clear();
	parsedLogsMethods.clear();
	logFilesList.setListData(logFiles);
    }
    
    /**
     * This method runs an open file dialog window where the user can select the file he wants to use as a filter.
     */
   
    public void addFilter() {
    	TreePath tp = projectTree.getSelectionPath();
	String path = "";
	for (int j=1;j<tp.getPathCount();j++) {
	    path += "/"+tp.getPathComponent(j).toString();
	}
	File f = new File(projectManager.getCurrentProjectPath(),path);
	if (f.isFile())
	    addFilter(f.getAbsolutePath());
    }
    
    /**
     * This method select the filter which path is given as parameter to use as a filter.
     * @param filterPath the path of the filter file
     */

    public void addFilter(String filterPath) {
	if ((filterTF.getText()).equals("No filter selected")) {
	    filterTF.setText(filterPath);
	}else{
	    JOptionPane.showMessageDialog(null, "You have already selected a filter.", "Error", JOptionPane.ERROR_MESSAGE); 
    	}
    }
    /**
     * This method removes the filter file selected.
     */

    public void removeFilter() {
    	filterTF.setText("No filter selected");	
    }
    
    /**
     * This method is called when the "Specify output filename" checkbox is clicked.
     * It sets the "XMI Ouput filename" textfield to enable or disable.
     */

    private void oCheckBoxPressed() {
    	if (oCheckBox.isSelected()) {
    		XMIFilenameLabel.setEnabled(true);
		XMIFilenameTF.setEnabled(true);
	}else {
    		XMIFilenameLabel.setEnabled(false);
		XMIFilenameTF.setEnabled(false);
	}
    }

    /**
     * This method is called when the "Generate XMI file" checkbox is clicked.
     * It sets the extensions checkboxes to enable or disable.
     */

    private void xmiCheckBoxPressed() {
    	if (xmiCheckBox.isSelected()) {
    		xrCheckBox.setEnabled(true);
		xmCheckBox.setEnabled(true);
	}else {
    		xrCheckBox.setEnabled(false);
		xmCheckBox.setEnabled(false);
	}
    }
    
     /**
     * This method is called when the "Generate SVG file" checkbox is clicked.
     * It sets the scale checkboxe to enable or disable.
     */

    private void svgCheckBoxPressed() {
    	if (svgCheckBox.isSelected()) {
	    scaleLabel.setEnabled(true);
	    svgScale.setEnabled(true);
	}else {
	    scaleLabel.setEnabled(false);
	    svgScale.setEnabled(false);
	}
    }

    /**
     * This method runs the Log2Xmi programs with the logs, filter and options selected with the gui.
     */
    
    public void launch() {
	if (logFilesList.getModel().getSize()==0) {
	    JOptionPane.showMessageDialog(null, "You haven't selected any log file", "Error", JOptionPane.ERROR_MESSAGE); 
	}else{
	    
	    Log2SequenceDiagram l2sd = new Log2SequenceDiagram();
	    String outputFile = "out";    	
	    boolean makeXmiFile = false;
	    boolean makeTexFile = false;
	    boolean makeSvgFile = false;
	    float scale = (float)1;

	    if (oCheckBox.isSelected())
		outputFile = XMIFilenameTF.getText();
	    
	    if (!(filterTF.getText().equals("No filter selected"))) 
		l2sd.setFilterFile(filterTF.getText());
	    
	    if (xmiCheckBox.isSelected()){
		makeXmiFile = true;
		if (xrCheckBox.isSelected())
		    l2sd.addRationalRoseExtension(true);
		if (xmCheckBox.isSelected())
		    l2sd.addMagicDrawExtension(true);
	    }

	    if (texCheckBox.isSelected())
		makeTexFile = true;
		
	    if (svgCheckBox.isSelected()) {
		makeSvgFile = true;
		String s = svgScale.getText();
		try {
		    scale = (Float.valueOf(s)).floatValue();
		}catch(NumberFormatException e) {
		    scale = (float)1;
		}
	    }

	    if (vCheckBox.isSelected())
		l2sd.valideXMLFiles(false);
	    
	    if (sCheckBox.isSelected())
		l2sd.synchronize(false);
	    
	    if (dCheckBox.isSelected())
		l2sd.debug(true);

	    for(int i = 0; i < logFilesList.getModel().getSize(); i++) {
		l2sd.addInputFile((String)logFilesList.getModel().getElementAt(i));
	    }
	    
	    boolean packFrame = false;
	    L2XInfoDisplayer gui = new L2XInfoDisplayer(this,l2sd,outputFile,makeXmiFile,makeTexFile,makeSvgFile,scale,projectManager.getCurrentProjectPath());
	    if (packFrame) {
		gui.pack();
	    }
	    else {
		gui.validate();
	    }
	    gui.setVisible(true);
	    this.setEnabled(false);
	}
    }

    /**
     * This method parses the XML log files in the log files list to get all the objects and all the methods in these files.
     * These objects and methods are stored in Vectors, and are used in the filter creation gui.
     */
    
    public void parseLogFiles() {
	//get logs filename from the logs list
	for(int i = 0; i < logFilesList.getModel().getSize(); i++) {
	    String filename = (String)logFilesList.getModel().getElementAt(i);
	    if (!(parsedLogs.contains(filename))) {
		try {
		    QuickXMLParser p = new QuickXMLParser(new QuickLogHandler(),new File(filename));
		
		    Vector objects = p.getObjects();
		    Vector methods = p.getMethods();
		    
		    //add the filename to the parsedLogs vector
		    parsedLogs.addElement(filename);
		    
		    parsedLogsObjects.put(filename,objects);
		    parsedLogsMethods.put(filename,methods); 
		    

		}catch (Exception e1) {
		    JOptionPane.showMessageDialog(null, "Error during parsing the log files.", "Error", JOptionPane.ERROR_MESSAGE);
		}
	    }
	}
    }
}

class JToolBarButton extends JButton {

    public JToolBarButton() {
	super();
	L2Xinit();
    }
    
    public JToolBarButton(Action a) {
	super(a);
	L2Xinit();
    }

    public JToolBarButton(Icon icon) {
	super(icon);
	L2Xinit();
    }

    public JToolBarButton(String text) {
	super(text);
	L2Xinit();
    }

    public JToolBarButton(String text, Icon icon) {
	super(text,icon);
	L2Xinit();
    }

    private void L2Xinit() {
	this.setBorderPainted(false);
	
	this.addMouseListener(new java.awt.event.MouseAdapter() {
		public void mouseEntered(MouseEvent e) {
		    setBorderPainted(true);   
		}
		public void mouseExited(MouseEvent e) {
		    setBorderPainted(false);
		}
	    });

    }
    
}

/**
 * This class defines a very simple XML Handler to select the methods and objects in a XML log file.
 * @author Jean-Philippe Wilsch
 */

class QuickLogHandler extends DefaultHandler {
    Vector objects;
    Vector methods;

    public QuickLogHandler() {
	super();
	objects = new Vector();
	methods = new Vector();
    }

    public void startElement(String namespaceURL, String localname, String qname, Attributes attributes) {
	if (qname.equals("local_object") || qname.equals("distant_object")) {
	    String object = attributes.getValue("id");
	    if (!(objects.contains(object)))
		objects.add(object);
	}

	if (qname.equals("operation")) {
	    String method = attributes.getValue("name");
	    if (!(methods.contains(method)))
		methods.add(method);
	}

    }

    public Vector getObjects() {
	return objects;
    }
    
    public Vector getMethods() {
	return methods;
    }
}

/**
 * This class defines a very simple XML Parser to select the methods and objects in a XML log file.
 * @author Jean-Philippe Wilsch
 */

class QuickXMLParser {
    QuickLogHandler handler;
    SAXParser sp;
    Vector objects;
    Vector methods;
    
    public QuickXMLParser(QuickLogHandler h, File file) throws IOException, SAXException, ParserConfigurationException {
	handler = h;

	SAXParserFactory spf = SAXParserFactory.newInstance();
	spf.setValidating(false);
	sp = spf.newSAXParser();
	
	sp.parse(file,handler);
	objects = handler.getObjects();
	methods = handler.getMethods();
    }

    public Vector getObjects() {
	return objects;
    }

    public Vector getMethods() {
	return methods;
    }

}

/**
 * This class is a small window which is used to display the result of the execution of log2xmi
 * @author Jean-Philippe Wilsch
 */

class L2XInfoDisplayer extends JFrame {
    
    private static final int FRAME_WIDTH = 500;
    private static final int FRAME_HEIGHT = 300;

    private JPanel contentPane;
    
    private JFrame parent;
    private int parentWidth;
    private int parentHeight;
    private int parentX;
    private int parentY;

    private JTextArea infoTA;
    private JScrollPane infoTAScroll;
    private JTextAreaOutputStream infoTAOS;
    private JButton okButton;

    private File projectPath;

    /**Construct the frame*/

    public L2XInfoDisplayer(JFrame f, Log2SequenceDiagram l2sd, String outputFile, boolean makeXmiFile, boolean makeTexFile, boolean makeSvgFile, float scale, File project) {
	parent = f;
	parentWidth = f.getWidth();
	parentHeight = f.getHeight();
	parentX = f.getX();
	parentY = f.getY();
	
	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	try {
	    projectPath = project;
	    Init();
	    runLog2Xmi(l2sd,outputFile,makeXmiFile,makeTexFile,makeSvgFile,scale);
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
    }

     /**
     * Initialize all the graphical objects of the frame
     */

    private void Init() throws Exception  {
	//the main frame
	contentPane = (JPanel) this.getContentPane();
	contentPane.setLayout(null);
	this.setResizable(false);
	this.setSize(new Dimension(FRAME_WIDTH,FRAME_HEIGHT));
	this.setBounds((parentX+((parentWidth-FRAME_WIDTH)/2)),(parentY+((parentHeight-FRAME_HEIGHT)/2)),FRAME_WIDTH, FRAME_HEIGHT);
	this.setTitle("Info");

	infoTAScroll = new JScrollPane();
	infoTAScroll.setBounds(new Rectangle(0,0,FRAME_WIDTH-5,FRAME_HEIGHT-70));
	infoTA = new JTextArea();
	infoTA.setEditable(false);
	infoTA.setBackground(Color.lightGray);
	infoTAOS = new JTextAreaOutputStream(infoTA);
	infoTAScroll.getViewport().add(infoTA);
	infoTAScroll.setBorder(new SoftBevelBorder(SoftBevelBorder.LOWERED));
	contentPane.add(infoTAScroll);

	okButton = new JButton("OK");
	okButton.setBounds(new Rectangle(200,240,70,30));
	okButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    close();
		}
	    });
	contentPane.add(okButton);
	
    }

    /**
     * This method runs the log2xmi main class, with the parameters of which are given as parameter of the method
     * @param params the parameters for log2xmi
     */

    private void runLog2Xmi(Log2SequenceDiagram l2sd, String outputFile, boolean makeXmiFile, boolean makeTexFile, boolean makeSvgFile,float scale) {
	okButton.setEnabled(false);

	//re-assign the System.out and System.err
	System.setOut(new PrintStream(infoTAOS,true));
	System.setErr(new PrintStream(infoTAOS,true));
	this.setTitle("Running...");
	System.out.println("Running...");

	l2sd.processAll();
		
	if(makeXmiFile) {
	    l2sd.generateXmiFile(projectPath.getAbsolutePath()+"/xmi/"+outputFile + ".xmi");
	}
	if(makeTexFile) {
	    l2sd.generateTexFile(projectPath.getAbsolutePath()+"/tex/"+outputFile + ".tex");
	}
	if(makeSvgFile) {
	    l2sd.generateSvgFile(projectPath.getAbsolutePath()+"/svg/"+outputFile + ".svg",scale);
	}

	System.setOut(new PrintStream(new BufferedOutputStream(new FileOutputStream(FileDescriptor.out), 128), true));
	System.setOut(new PrintStream(new BufferedOutputStream(new FileOutputStream(FileDescriptor.err), 128), true));

	System.out.println("Done");
	this.setTitle("Done");
	okButton.setEnabled(true);
    }
    
    private void close() {
	this.setVisible(false);
	parent.setEnabled(true);
	parent.transferFocus();
    }
}

/**
 * This class is a small window which is used to display the about informations
 * @author Jean-Philippe Wilsch
 */

class L2XAbout extends JFrame {
    
    private static final int FRAME_WIDTH = 400;
    private static final int FRAME_HEIGHT = 255;

    private JPanel contentPane;
    
    private JFrame parent;
    private int parentWidth;
    private int parentHeight;
    private int parentX;
    private int parentY;

    ImageIcon img;
    JLabel logo;
    JLabel LGPLLabel;
    JLabel corbaTraceTeamLabel;
    JLabel team1Label;
    JLabel team2Label;
    JLabel team3Label;
    JLabel team4Label;
    JLabel team5Label;
    JLabel team6Label;
    JLabel team7Label;
    JLabel team8Label;
    JLabel team9Label;
    JLabel team10Label;
    JButton closeButton;
    

    /**Construct the frame*/

    public L2XAbout(JFrame f) {
	parent = f;
	parentWidth = f.getWidth();
	parentHeight = f.getHeight();
	parentX = f.getX();
	parentY = f.getY();
	
	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	try {
	    Init();
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
    }

     /**
     * Initialize all the graphical objects of the frame
     */

    private void Init() throws Exception  {
	//the main frame
	contentPane = (JPanel) this.getContentPane();
	contentPane.setLayout(null);
	//this.setUndecorated(true);
	this.setResizable(false);
	this.setSize(new Dimension(FRAME_WIDTH,FRAME_HEIGHT));
	this.setBounds((parentX+((parentWidth-FRAME_WIDTH)/2)),(parentY+((parentHeight-FRAME_HEIGHT)/2)),FRAME_WIDTH, FRAME_HEIGHT);
	this.setTitle("About");
	//this.setBorder(new EtchedBorder());

	img = new ImageIcon(getClass().getResource("images/corbatrace_logo.png"));
	logo = new JLabel(img);
	logo.setBounds(new Rectangle((FRAME_WIDTH-251)/2,5,251,43));
	contentPane.add(logo);

	LGPLLabel = new JLabel("CorbaTrace is distributed under LGPL Licence");
	LGPLLabel.setBounds(new Rectangle((FRAME_WIDTH-270)/2,50,270,20));
	contentPane.add(LGPLLabel);
	
	corbaTraceTeamLabel = new JLabel("The CorbaTrace team is:");
	corbaTraceTeamLabel.setBounds(new Rectangle(5,75,200,20));
	contentPane.add(corbaTraceTeamLabel);

	team1Label = new JLabel("Florian Champalle");
	team1Label.setBounds(new Rectangle(35,95,140,17));
	contentPane.add(team1Label);

	team2Label = new JLabel("Audrey Jaccard");
	team2Label.setBounds(new Rectangle(35,112,140,17));
	contentPane.add(team2Label);

	team3Label = new JLabel("Etienne Juliot");
	team3Label.setBounds(new Rectangle(35,129,140,17));
	contentPane.add(team3Label);

	team4Label = new JLabel("Nicolas Lemoullec");
	team4Label.setBounds(new Rectangle(35,146,140,17));
	contentPane.add(team4Label);

	team5Label = new JLabel("Antoine Para Del Pozo");
	team5Label.setBounds(new Rectangle(35,163,140,17));
	contentPane.add(team5Label);
	
	team6Label = new JLabel("Aurelien Francheteau");
	team6Label.setBounds(new Rectangle(230,95,140,17));
	contentPane.add(team6Label);

	team7Label = new JLabel("Brice Francois");
	team7Label.setBounds(new Rectangle(230,112,140,17));
	contentPane.add(team7Label);

	team8Label = new JLabel("Sebastien Helbert");
	team8Label.setBounds(new Rectangle(230,129,140,17));
	contentPane.add(team8Label);

	team9Label = new JLabel("Jerome Limousin");
	team9Label.setBounds(new Rectangle(230,146,140,17));
	contentPane.add(team9Label);

	team10Label = new JLabel("Jean-Philippe Wilsch");
	team10Label.setBounds(new Rectangle(230,163,140,17));
	contentPane.add(team10Label);
	
	closeButton = new JButton("Close");
	closeButton.setBounds(new Rectangle((FRAME_WIDTH-100)/2,185,100,35));
	closeButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    close();
		}
	    });
	contentPane.add(closeButton);
    }

     /**
     * This method deals with the windows events, especially the closing window event
     * @param e a window event
     */
    
    protected void processWindowEvent(WindowEvent e) {
	super.processWindowEvent(e);
	if (e.getID() == WindowEvent.WINDOW_CLOSING) {
	    parent.setEnabled(true);
	    parent.transferFocus();
	}
    }

    private void close() {
	this.setVisible(false);
	parent.setEnabled(true);
	parent.transferFocus();
    }
}
