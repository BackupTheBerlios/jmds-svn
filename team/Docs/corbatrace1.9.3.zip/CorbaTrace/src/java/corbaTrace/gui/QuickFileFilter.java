package corbaTrace.gui;

import java.io.*;

/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Jean-Philippe Wilsch
 */

/**
 * This class is a very simle file filter for the file choosers
 */

class QuickFileFilter extends javax.swing.filechooser.FileFilter {

    //the filtered extension
    private String extension;
    //the description of the filtered file type
    private String description;

    /**
     * This method sets the filtered extension.
     * @param ext The filtered extension
     */

    public void setExtension(String ext) {
	extension = ext.toLowerCase();
    }

    /**
     * This method sets the description of the filtered file type
     * @param desc The description
     */

    public void setDescription(String desc) {
	description = desc;
    }

    /**
     * This method returns whether the given file is accepted by this filter.
     * @param f the file to test
     * @return true if the file is accepted
     */
	
    public boolean accept(File f) {
	if (f.isDirectory()) 
	    return true;
	else{
	    String filename = f.getName();
	    int i = filename.lastIndexOf('.');
	    String ext="";
	    if(i>0 && i<filename.length()-1) {
		ext = filename.substring(i+1).toLowerCase();
	    }
	
	    return (this.extension.equals(ext));
	}
    }

    /**
     * This method returns the description of the filtered file type.
     * @return the description
     */

    public String getDescription() {
	return description;
    }
}
