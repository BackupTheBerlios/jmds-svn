package corbaTrace.gui;

/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Jean-Philippe Wilsch
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.util.*;
import java.io.*;

/**
 * This class is a GUI to create a filter to use with the Log2Xmi application
 * @author Jean-Philippe Wilsch
 */

public class L2XCreateFilterGUI extends JFrame {

    private static final int FRAME_WIDTH = 780;
    private static final int FRAME_HEIGHT = 530;
    
    private JPanel contentPane;
    
    private L2XGUI parent;
    private int parentWidth;
    private int parentHeight;
    private int parentX;
    private int parentY;

    private JLabel levelLabel;
    private JComboBox levelCombo;
    private ArrayList levels;
    
    private JSeparator separator2;

    private JTabbedPane optionsTP;
    
    private JPanel messageTypePanel;
    private JComboBox messageTypeCombo;
    private String[] messageTypes = {"REQUEST","REPLY","EXCEPTION","BROKEN_REQUEST","BROKEN_REPLY","BROKEN_EXCEPTION"};
    private JButton addMessTypeButton;

    private JPanel datePanel;
    private JComboBox dateTypeCombo;
    private String[] dateTypes = {"After","Before","Between"};
    private JLabel dayLabel;
    private JLabel monthLabel;
    private JLabel yearLabel;
    private JLabel hourLabel;
    private JLabel minuteLabel;
    private JLabel secondLabel;
    private JTextField day1TF;
    private JTextField month1TF;
    private JTextField year1TF;
    private JTextField hour1TF;
    private JTextField minute1TF;
    private JTextField second1TF;
    private JLabel andLabel;
    private JTextField day2TF;
    private JTextField month2TF;
    private JTextField year2TF;
    private JTextField hour2TF;
    private JTextField minute2TF;
    private JTextField second2TF;
    private JButton addDateButton;

    private JPanel methodPanel;
    private JLabel nameLabel;
    private JComboBox nameCombo;
    private JRadioButton noArgRB;
    private JRadioButton argTypeRB;
    private JRadioButton argPosRB;
    private ButtonGroup rbGroup;
    private JLabel noArgLabel;
    private JLabel argTypeLabel;
    private JLabel argPosLabel;
    private JTextField argPosTF;
    private JTextField argTypeTF;
    private JLabel argValueLabel;
    private JTextField argValueTF;
    private JButton addMethodButton;

    private JSeparator separator3;

    private JScrollPane filterScroll;
    private JTextArea filterTA;
    
    private JSeparator separator4;

    private JButton saveButton;
    private JButton saveAndAddButton;

    private File localDir;
    private L2XFilter filter;

    /**
     * Construct the frame
     * @param f the L2XGUI parent frame
     * @param objects the objects which can be added in the filter
     * @param methods the methods which can be added in the filter
     */
    
    public L2XCreateFilterGUI(L2XGUI f, Vector objects, Vector methods, File initLocalDir) {
	parent = f;
	parentWidth = f.getWidth();
	parentHeight = f.getHeight();
	parentX = f.getX();
	parentY = f.getY();
	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	try {
	    Init(objects,methods);
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
	if (initLocalDir!=null) 
	    localDir = initLocalDir;
	else
	    localDir = new File(".");
    }

    /**
     * Initialize all the graphical objects of the frame
     */

    private void Init(Vector objects, Vector methods) throws Exception  {
	//the main frame
	contentPane = (JPanel) this.getContentPane();
	contentPane.setLayout(null);
	this.setResizable(false);
	this.setSize(new Dimension(FRAME_WIDTH, FRAME_HEIGHT));
	this.setBounds((parentX+((parentWidth-FRAME_WIDTH)/2)),(parentY+((parentHeight-FRAME_HEIGHT)/2)),FRAME_WIDTH, FRAME_HEIGHT);
	this.setTitle("CorbaTrace Log2SequenceDiagram - Create Filter File");
	
	//the object part
	levelLabel = new JLabel("Object");
	levelLabel.setBounds(new Rectangle(10, 5, 70, 20));
	contentPane.add(levelLabel);
	levelCombo = new JComboBox(objects);
	levelCombo.setBounds(new Rectangle(10, 30, 200, 20));
	contentPane.add(levelCombo);
	levels = new ArrayList();
	
	separator2 = new JSeparator(SwingConstants.VERTICAL);
	separator2.setBounds(new Rectangle(320,5,1,160));
	contentPane.add(separator2);

	optionsTP = new JTabbedPane();
	optionsTP.setBounds(new Rectangle(330,5,430,155));
	contentPane.add(optionsTP);

	//the message type part
	messageTypePanel = new JPanel();
	messageTypePanel.setLayout(null);
	messageTypeCombo = new JComboBox(messageTypes);
	messageTypeCombo.setBounds(new Rectangle(5, 5, 300, 20));
	messageTypePanel.add(messageTypeCombo);
	addMessTypeButton = new JButton("Add");
	addMessTypeButton.setBounds(new Rectangle(340, 5, 80, 20));
	addMessTypeButton.addActionListener(new java.awt.event.ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
		    addMessageType();
		}
	    });
	messageTypePanel.add(addMessTypeButton);
	optionsTP.add("Message Type",messageTypePanel);
	
	//the date part
	datePanel = new JPanel();
	datePanel.setLayout(null);
	dateTypeCombo = new JComboBox(dateTypes);
	dateTypeCombo.setBounds(new Rectangle(5, 5, 300, 20));
	dateTypeCombo.addActionListener(new java.awt.event.ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
		    dateTypeComboChanged();
		}
	    });
	datePanel.add(dateTypeCombo);
	addDateButton = new JButton("Add");
	addDateButton.addActionListener(new java.awt.event.ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
		    addDate();
		}
	    });
	addDateButton.setBounds(new Rectangle(340, 5, 80, 20));
	datePanel.add(addDateButton);
	dayLabel = new JLabel("Day");
	dayLabel.setBounds(new Rectangle(5, 30, 50, 20));
	datePanel.add(dayLabel);
	day1TF = new JTextField();
	day1TF.setBounds(new Rectangle(5, 55, 50, 20));
	datePanel.add(day1TF);
	monthLabel = new JLabel("Month");
	monthLabel.setBounds(new Rectangle(60, 30, 50, 20));
	datePanel.add(monthLabel);
	month1TF = new JTextField();
	month1TF.setBounds(new Rectangle(60, 55, 50, 20));
	datePanel.add(month1TF);
	yearLabel = new JLabel("Year");
	yearLabel.setBounds(new Rectangle(115, 30, 50, 20));
	datePanel.add(yearLabel);
	year1TF = new JTextField();
	year1TF.setBounds(new Rectangle(115, 55, 50, 20));
	datePanel.add(year1TF);
	hourLabel = new JLabel("Hour");
	hourLabel.setBounds(new Rectangle(170, 30, 50, 20));
	datePanel.add(hourLabel);
	hour1TF = new JTextField();
	hour1TF.setBounds(new Rectangle(170, 55, 50, 20));
	datePanel.add(hour1TF);
	minuteLabel = new JLabel("Minute");
	minuteLabel.setBounds(new Rectangle(225, 30, 50, 20));
	datePanel.add(minuteLabel);
	minute1TF = new JTextField();
	minute1TF.setBounds(new Rectangle(225, 55, 50, 20));
	datePanel.add(minute1TF);
	secondLabel = new JLabel("Second");
	secondLabel.setBounds(new Rectangle(280, 30, 50, 20));
	datePanel.add(secondLabel);
	second1TF = new JTextField();
	second1TF.setBounds(new Rectangle(280, 55, 50, 20));
	datePanel.add(second1TF);
	andLabel = new JLabel("and");
	andLabel.setBounds(new Rectangle(155, 80, 50, 20));
	datePanel.add(andLabel);
	day2TF = new JTextField();
	day2TF.setBounds(new Rectangle(5, 105, 50, 20));
	datePanel.add(day2TF);
	month2TF = new JTextField();
	month2TF.setBounds(new Rectangle(60, 105, 50, 20));
	datePanel.add(month2TF);
	year2TF = new JTextField();
	year2TF.setBounds(new Rectangle(115, 105, 50, 20));
	datePanel.add(year2TF);
	hour2TF = new JTextField();
	hour2TF.setBounds(new Rectangle(170, 105, 50, 20));
	datePanel.add(hour2TF);
	minute2TF = new JTextField();
	minute2TF.setBounds(new Rectangle(225, 105, 50, 20));
	datePanel.add(minute2TF);
	second2TF = new JTextField();
	second2TF.setBounds(new Rectangle(280, 105, 50, 20));
	datePanel.add(second2TF);
	setEnabledDate2(false);
	optionsTP.add("Date",datePanel);

	//the method part
	methodPanel = new JPanel();
	methodPanel.setLayout(null);
	nameLabel = new JLabel("Name");
	nameLabel.setBounds(new Rectangle(5, 5, 50, 20));
	methodPanel.add(nameLabel);
	nameCombo = new JComboBox(methods);
	nameCombo.setBounds(new Rectangle(60, 5, 240, 20));
	methodPanel.add(nameCombo);
	addMethodButton = new JButton("Add");
	addMethodButton.setBounds(new Rectangle(340, 5, 80, 20));
	addMethodButton.addActionListener(new java.awt.event.ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
		    addMethodArg();
		}
	    });
	methodPanel.add(addMethodButton);
	noArgRB = new JRadioButton();
	noArgRB.setBounds(new Rectangle(45, 30, 20, 20));
	noArgRB.addActionListener(new java.awt.event.ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
		    noArgSelected();
		}
	    });
	methodPanel.add(noArgRB);
	argPosRB = new JRadioButton();
	argPosRB.setBounds(new Rectangle(155, 30, 20, 20));
	argPosRB.addActionListener(new java.awt.event.ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
		    argPosSelected();
		}
	    });
	methodPanel.add(argPosRB);
	argTypeRB = new JRadioButton();
	argTypeRB.setBounds(new Rectangle(295, 30, 20, 20));
	argTypeRB.addActionListener(new java.awt.event.ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
		    argTypeSelected();
		}
	    });
	methodPanel.add(argTypeRB);
	rbGroup = new ButtonGroup();
	rbGroup.add(noArgRB);
	rbGroup.add(argPosRB);
	rbGroup.add(argTypeRB);
	noArgLabel = new JLabel("No argument");
	noArgLabel.setBounds(new Rectangle(5, 55, 100, 20));
	methodPanel.add(noArgLabel);
	argPosLabel = new JLabel("Position");
	argPosLabel.setBounds(new Rectangle(120, 55, 70, 20));
	methodPanel.add(argPosLabel);
	argPosTF = new JTextField();
	argPosTF.setBounds(new Rectangle(195, 55, 40, 20));
	methodPanel.add(argPosTF);
	argTypeLabel = new JLabel("Type");
	argTypeLabel.setBounds(new Rectangle(250, 55, 70, 20));
	methodPanel.add(argTypeLabel);
	argTypeTF = new JTextField();
	argTypeTF.setBounds(new Rectangle(325, 55, 40, 20));
	methodPanel.add(argTypeTF);
	argValueLabel = new JLabel("Value");
	argValueLabel.setBounds(new Rectangle(120,80,70,20));
	methodPanel.add(argValueLabel);
	argValueTF = new JTextField();
	argValueTF.setBounds(new Rectangle(195,80,200,20));
	methodPanel.add(argValueTF);
	noArgRB.setSelected(true);
	setEnabledNoArg(true);
	setEnabledArgPos(false);
	setEnabledArgType(false);
	setEnabledArgValue(false);
	optionsTP.add("Method",methodPanel);

	separator3 = new JSeparator();
	separator3.setBounds(new Rectangle(5,170,FRAME_WIDTH-15,1));
	contentPane.add(separator3);

	//the filter display
	filterScroll = new JScrollPane();
	filterScroll.setBounds(new Rectangle(5,180,FRAME_WIDTH-15,250));
	filterTA = new JTextArea();
	filterTA.setFont(new Font("Arial",Font.PLAIN,14));
	filterTA.setEditable(false);
	filter = new L2XFilter();
	displayFilter();
	filterScroll.getViewport().add(filterTA);
	contentPane.add(filterScroll);
	
	separator4 = new JSeparator();
	separator4.setBounds(new Rectangle(5,440,FRAME_WIDTH-15,1));
	contentPane.add(separator4);
	
	//the save buttons
	saveButton = new JButton("Save");
	saveButton.setBounds(new Rectangle(((FRAME_WIDTH-300)/3),450,150,40));
	saveButton.addActionListener(new java.awt.event.ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
		    save();
		}
	    });
	contentPane.add(saveButton);
	saveAndAddButton = new JButton("Save and add");
	saveAndAddButton.setBounds(new Rectangle((((FRAME_WIDTH-300)/3)*2)+150,450,150,40));
	saveAndAddButton.addActionListener(new java.awt.event.ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
		    saveAndAdd();
		}
	    });
	contentPane.add(saveAndAddButton);
	
    }

    /**
     * This method deals with the windows events, especially the closing window event
     * @param e a window event
     */
    
    protected void processWindowEvent(WindowEvent e) {
	super.processWindowEvent(e);
	if (e.getID() == WindowEvent.WINDOW_CLOSING) {
	    parent.setEnabled(true);
	    parent.transferFocus();
	}
    }
   
     /**
     * This method adds a message type to the filter
     */

    public void addMessageType() {
	String level = (String)levelCombo.getSelectedItem();
	String messType = (String)messageTypeCombo.getSelectedItem();

	if (level.equals("Global"))
	    level=null;

	filter.addMessageType(level,messType);
	displayFilter();
    }

    /**
     * This method enables or disables the date2 graphical elements
     * @param enabled a boolean value, where true enables the elements and false disables them
     */

    private void setEnabledDate2(boolean enabled) {
	andLabel.setEnabled(enabled);
	day2TF.setEnabled(enabled);
	month2TF.setEnabled(enabled);
	year2TF.setEnabled(enabled);
	hour2TF.setEnabled(enabled);
	minute2TF.setEnabled(enabled);
	second2TF.setEnabled(enabled);
    }
    
    /**
     * This method adds a date to the filter
     */
    
    public void addDate() {
	String level = (String)levelCombo.getSelectedItem();
	String dateType = (String)dateTypeCombo.getSelectedItem();
	
	if (level.equals("Global"))
	    level=null;

	String[] date1 = {day1TF.getText(),month1TF.getText(),year1TF.getText(),hour1TF.getText(),minute1TF.getText(),second1TF.getText()};

	if (dateType.equals("Between")) {
	    String[] date2 = {day2TF.getText(),month2TF.getText(),year2TF.getText(),hour2TF.getText(),minute2TF.getText(),second2TF.getText()};
	   filter.addDate(level,dateType,date1,date2);
	 
	}else{
	    String[] date2 = null; 
	    filter.addDate(level,dateType,date1,date2);
	}
	
	displayFilter();
    }
    
    /**
     * This method adds a method to the filter with the selected argument
     */
    
    public void addMethodArg() {
	String level = (String)levelCombo.getSelectedItem();
	String methodName = (String)nameCombo.getSelectedItem();
	System.out.println(level);
	if (methodName!=null) {
	    int argType=0;
	    String posOrType="";
	    if (argPosRB.isSelected()){
		argType=1;
		posOrType=argPosTF.getText();
	    }
	    if (argTypeRB.isSelected()){
		argType=2; 
		posOrType=argTypeTF.getText();
	    }
	    String value = argValueTF.getText();
	    
	    if (level.equals("Global"))
		level=null;

	    switch(argType) {
		case 1:
		    filter.addMethodWithArgPos(level,methodName,posOrType,value);
		    break;
	        case 2:
		    filter.addMethodWithArgType(level,methodName,posOrType,value);
		    break;
	        case 0:
		    filter.addMethodWithNoArg(level,methodName);
		    break;
	    }
	    
	    displayFilter();
	}
    }
    
    /**
     * This method is called when the dateTypeCombo value changes.
     */

    private void dateTypeComboChanged() {
	String selectedValue = (String)dateTypeCombo.getSelectedItem();
	if (selectedValue.equals("Between"))
	    setEnabledDate2(true);
	else
	    setEnabledDate2(false);
    }
    
    /**
     * This methods enables or disables the method "no argument" graphical elements.
     * @param enabled a boolean value, where true enables the elements and false disables them
     */

    private void setEnabledNoArg(boolean enabled) {
	noArgLabel.setEnabled(enabled);
    }
    
    /**
     * This methods enables or disables the method "argument position" graphical elements.
     * @param enabled a boolean value, where true enables the elements and false disables them
     */

    private void setEnabledArgPos(boolean enabled) {
	argPosLabel.setEnabled(enabled);
	argPosTF.setEnabled(enabled);
    }

     /**
     * This methods enables or disables the method "argument type" graphical elements.
     * @param enabled a boolean value, where true enables the elements and false disables them
     */

    private void setEnabledArgType(boolean enabled) {
	argTypeLabel.setEnabled(enabled);
	argTypeTF.setEnabled(enabled);
    }
    
    /**
     * This methods enables or disables the method "argument value" graphical elements.
     * @param enabled a boolean value, where true enables the elements and false disables them
     */

    private void setEnabledArgValue(boolean enabled) {
	argValueLabel.setEnabled(enabled);
	argValueTF.setEnabled(enabled);
    }
    
    /**
     * This method is called no argument radio button is selected.
     */

    private void noArgSelected() {
	setEnabledNoArg(true);
	setEnabledArgPos(false);
	setEnabledArgType(false);
	setEnabledArgValue(false);
    }

     /**
     * This method is called argument position radio button is selected.
     */

    private void argPosSelected() {
	setEnabledNoArg(false);
	setEnabledArgPos(true);
	setEnabledArgType(false);
	setEnabledArgValue(true);
    }

     /**
     * This method is called argument type radio button is selected.
     */

    private void argTypeSelected() {
	setEnabledNoArg(false);
	setEnabledArgPos(false);
	setEnabledArgType(true);
	setEnabledArgValue(true);
    }

    /**
     * This method runs an save file dialog window where the user can select the file where he wants to save the filter,
     * and then write the filter in this file.
     */

    private void save() {
	JFileChooser chooser = new JFileChooser(localDir);
	int returnVal = chooser.showSaveDialog(this);
	if(returnVal == JFileChooser.APPROVE_OPTION) {
	    File filterFile = chooser.getSelectedFile();
	    if (filterFile.exists()) {
		int choice = JOptionPane.showConfirmDialog(null,"This file already exists. Do you want to overwrite it?", "Warning", JOptionPane.YES_NO_OPTION);
		if (choice== JOptionPane.YES_OPTION) {
		    filter.writeFilterFile(filterFile);
		}
	    }else{
		filter.writeFilterFile(filterFile);
	    }

	}
    }

    /**
     * This method runs an save file dialog window where the user can select the file where he wants to save the filter,
     * and write the filter in this file. Then it adds this file as a filter in the L2XGUI parent frame.
     */

    private void saveAndAdd() {
	JFileChooser chooser = new JFileChooser(localDir);
	chooser.setDialogType(JFileChooser.SAVE_DIALOG);
	int returnVal = chooser.showSaveDialog(this);
	if(returnVal == JFileChooser.APPROVE_OPTION) {
	    File filterFile = chooser.getSelectedFile();
	    if (filterFile.exists()) {
		int choice = JOptionPane.showConfirmDialog(null,"This file already exists. Do you want to overwrite it?", "Warning", JOptionPane.YES_NO_OPTION);
		if (choice== JOptionPane.YES_OPTION) {
		    filter.writeFilterFile(filterFile);
		}
	    }else{
		filter.writeFilterFile(filterFile);
	    }
	    parent.addFilter(filterFile.getAbsolutePath());
	}
	
    }

    /**
     * This method displays the filter in the filterTA textarea.
     */

    private void displayFilter() {
	filterTA.setText(filter.getString());
    }
}

