package corbaTrace.gui;

/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Jean-Philippe Wilsch
 */

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*; 
import javax.swing.text.html.*; 
import java.io.*;

/**
 * This class is a very simle HTML Viewer.
 */

public class HTMLViewer extends JFrame {

    private static final int FRAME_WIDTH = 640;
    private static final int FRAME_HEIGHT = 460;

    private JPanel contentPane;
    
    private JFrame parent;
    private int parentWidth;
    private int parentHeight;
    private int parentX;
    private int parentY;

    private JEditorPane html;
    private JScrollPane htmlScroll;

    /**Construct the frame*/

    public HTMLViewer(JFrame f) {
	parent = f;
	parentWidth = f.getWidth();
	parentHeight = f.getHeight();
	parentX = f.getX();
	parentY = f.getY();
	
	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	try {
	    Init();
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
    }

    /**
     * Initialize all the graphical objects of the frame
     */

    private void Init() throws Exception  {
	//the main frame
	contentPane = (JPanel) this.getContentPane();
	contentPane.setLayout(new BorderLayout());
	this.setResizable(true);
	this.setSize(new Dimension(FRAME_WIDTH,FRAME_HEIGHT));
	this.setBounds((parentX+((parentWidth-FRAME_WIDTH)/2)),(parentY+((parentHeight-FRAME_HEIGHT)/2)),FRAME_WIDTH, FRAME_HEIGHT);
	this.setTitle("Help");

	html = new JEditorPane();
	//File help = new File(getClass().getResource("help/index.html"));
	//html.setPage(help.toURL());
	html.setPage(getClass().getResource("help/index.html"));
	html.setEditable(false);
	html.addHyperlinkListener(new HyperlinkListener() {
		public void hyperlinkUpdate(HyperlinkEvent e) { 
		    if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) { 
			if (e instanceof HTMLFrameHyperlinkEvent) { 
			    ((HTMLDocument)html.getDocument()).processHTMLFrameHyperlinkEvent( 
											      (HTMLFrameHyperlinkEvent)e); 
			} else { 
			    try { 
				html.setPage(e.getURL()); 
			    } catch (IOException e1) { 
				System.out.println("Error: " + e1); 
			    } 
			} 
		    } 
		} 
	    });
	htmlScroll = new JScrollPane(html);
	
	contentPane.add(htmlScroll);
    }

     /**
     * This method deals with the windows events, especially the closing window event
     * @param e a window event
     */
    
    protected void processWindowEvent(WindowEvent e) {
	super.processWindowEvent(e);
	if (e.getID() == WindowEvent.WINDOW_CLOSING) {
	    parent.setEnabled(true);
	    parent.transferFocus();
	}
    }
    
}
