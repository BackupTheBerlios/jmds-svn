package corbaTrace.gui;

/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Jean-Philippe Wilsch
 */

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import org.apache.batik.swing.JSVGCanvas;
import org.apache.batik.swing.gvt.GVTTreeRendererAdapter;
import org.apache.batik.swing.gvt.GVTTreeRendererEvent;
import org.apache.batik.swing.svg.SVGDocumentLoaderAdapter;
import org.apache.batik.swing.svg.SVGDocumentLoaderEvent;
import org.apache.batik.swing.svg.GVTTreeBuilderAdapter;
import org.apache.batik.swing.svg.GVTTreeBuilderEvent;
import org.apache.batik.swing.gvt.JGVTComponent;
import java.io.*;

/**
 * This class is a very simle SVG Viewer, where you can load files which are displayed in a scroll pane.
 */

public class SVGViewer extends JFrame {
    private static final int FRAME_WIDTH = 780;
    private static final int FRAME_HEIGHT = 530;

    private JPanel contentPane;
    
    private JFrame parent;
    private int parentWidth;
    private int parentHeight;
    private int parentX;
    private int parentY;

    private JButton openSVGButton;
    private JButton zoomInButton;
    private JButton zoomOutButton;
    private JLabel SVGStatus;
    private JScrollPane SVGDisplayerScroll;
    private JSVGCanvas SVGDisplayer;

    private File projectPath;
    
    /**Construct the frame*/

    public SVGViewer(JFrame f, File project) {
	parent = f;
	parentWidth = f.getWidth();
	parentHeight = f.getHeight();
	parentX = f.getX();
	parentY = f.getY();
	if (project!=null) 
	    projectPath = project;
	else
	    projectPath = new File(".");

	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	try {
	    Init();
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
	
  }
  
  public SVGViewer(JFrame f, File project, File file) {
	parent = f;
	parentWidth = f.getWidth();
	parentHeight = f.getHeight();
	parentX = f.getX();
	parentY = f.getY();
	if (project!=null) 
	    projectPath = project;
	else
	    projectPath = new File(".");

	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	try {
	    Init();
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
	
	loadSVG(file);
	
    }

    /**
     * Initialize all the graphical objects of the frame
     */

    private void Init() throws Exception  {
	ImageIcon img;

	//the main frame
	contentPane = (JPanel) this.getContentPane();
	BorderLayout bl = new BorderLayout();
	bl.setVgap(10);
	contentPane.setLayout(bl);
	this.setSize(new Dimension(FRAME_WIDTH,FRAME_HEIGHT));
	this.setBounds((parentX+((parentWidth-FRAME_WIDTH)/2)),(parentY+((parentHeight-FRAME_HEIGHT)/2)),FRAME_WIDTH, FRAME_HEIGHT);
	this.setTitle("SVG Viewer");
	JPanel p1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
	contentPane.add(p1,BorderLayout.NORTH);
	img = new ImageIcon(getClass().getResource("images/open.gif"));
	openSVGButton = new JButton(img);
	openSVGButton.setFocusPainted(false);
	openSVGButton.setToolTipText("Open SVG Document");
	openSVGButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    loadSVG();
		}
	    });
	p1.add(openSVGButton);

	img = new ImageIcon(getClass().getResource("images/zoomIn2.gif"));
	zoomInButton = new JButton(img);
	zoomInButton.setFocusPainted(false);
	zoomInButton.setToolTipText("Zoom In");
	zoomInButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    zoomIn();
		}
	    });
	p1.add(zoomInButton);

	img = new ImageIcon(getClass().getResource("images/zoomOut2.gif"));
	zoomOutButton = new JButton(img);
	zoomOutButton.setFocusPainted(false);
	zoomOutButton.setToolTipText("Zoom Out");
	zoomOutButton.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    zoomOut();
		}
	    });
	p1.add(zoomOutButton);

	SVGStatus = new JLabel();
	SVGStatus.setBounds(new Rectangle(590,5,170,30));
	p1.add(SVGStatus);
	
	JPanel p2 = new JPanel(new BorderLayout());
	p2.setBorder(BorderFactory.createEtchedBorder());
	SVGDisplayer= new JSVGCanvas();
	SVGDisplayer.addSVGDocumentLoaderListener(new SVGDocumentLoaderAdapter() {
            public void documentLoadingStarted(SVGDocumentLoaderEvent e) {
                SVGStatus.setText("Document Loading...");
            }
            public void documentLoadingCompleted(SVGDocumentLoaderEvent e) {
                SVGStatus.setText("Document Loaded.");
            }
	    });

        SVGDisplayer.addGVTTreeBuilderListener(new GVTTreeBuilderAdapter() {
            public void gvtBuildStarted(GVTTreeBuilderEvent e) {
                SVGStatus.setText("Build Started...");
            }
            public void gvtBuildCompleted(GVTTreeBuilderEvent e) {
                SVGStatus.setText("Build Done.");
            }
        });

        SVGDisplayer.addGVTTreeRendererListener(new GVTTreeRendererAdapter() {
            public void gvtRenderingPrepare(GVTTreeRendererEvent e) {
                SVGStatus.setText("Rendering Started...");
            }
            public void gvtRenderingCompleted(GVTTreeRendererEvent e) {
                SVGStatus.setText("");
            }
	    });
	
	SVGDisplayerScroll = new JScrollPane(SVGDisplayer);
	SVGDisplayerScroll.setBounds(new Rectangle(5,50,FRAME_WIDTH-15,FRAME_HEIGHT-100));
	p2.add(SVGDisplayerScroll, BorderLayout.CENTER);
	contentPane.add(p2, BorderLayout.CENTER);
	
	
}
    /**
     * This method deals with the windows events, especially the closing window event
     * @param e a window event
     */
    
    protected void processWindowEvent(WindowEvent e) {
	super.processWindowEvent(e);
	if (e.getID() == WindowEvent.WINDOW_CLOSING) {
	    parent.setEnabled(true);
	    parent.transferFocus();
	}
    }
    
     /**
     * This method runs an open file dialog window where the user can select the file he wants to display.
     */

    private void loadSVG() {
	JFileChooser chooser = new JFileChooser(projectPath.getAbsolutePath());
    	QuickFileFilter filter = new QuickFileFilter();
	filter.setExtension("svg");
	filter.setDescription("SVG Files");
	chooser.setFileFilter(filter);
	int returnVal = chooser.showOpenDialog(this);
    	if(returnVal == JFileChooser.APPROVE_OPTION) {
	    try {
		SVGDisplayer.setURI(chooser.getSelectedFile().toURL().toString());
	    }catch(java.net.MalformedURLException e) {
		System.out.println("URL Error");
	    }
	}
  }
  
  private void loadSVG(File file) {
  	try {
		SVGDisplayer.setURI(file.toURL().toString());
	    }catch(java.net.MalformedURLException e) {
		System.out.println("URL Error");
	  }
	}

    private void zoomIn() {
	AffineTransform affinetransform = SVGDisplayer.getRenderingTransform();
        if(affinetransform != null) {
	    Dimension dimension = getSize();
	    int i = dimension.width / 2;
	    int j = dimension.height / 2;
	    AffineTransform affinetransform1 = AffineTransform.getTranslateInstance(i, j);
	    affinetransform1.scale(1.5D, 1.5D);
	    affinetransform1.translate(-i, -j);
	    affinetransform1.concatenate(affinetransform);
	    SVGDisplayer.setRenderingTransform(affinetransform1);
	}
	
    }

    private void zoomOut() {
	AffineTransform affinetransform = SVGDisplayer.getRenderingTransform();
        if(affinetransform != null)
        {
            Dimension dimension = getSize();
            int i = dimension.width / 2;
            int j = dimension.height / 2;
            AffineTransform affinetransform1 = AffineTransform.getTranslateInstance(i, j);
            affinetransform1.scale(0.66D, 0.66D);
            affinetransform1.translate(-i, -j);
            affinetransform1.concatenate(affinetransform);
            SVGDisplayer.setRenderingTransform(affinetransform1);
        }

    }
    
}
