/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace;

import org.omg.PortableServer.POA;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Policy;
import org.omg.CORBA.Any;
import java.util.Properties;

import corbaTrace.interceptorCore.*;

/**
 * This class is a superclass for the Client and the Server
 * @author Etienne Juliot
 * @author Audrey Jaccard
 * @version 0.1
 */
public class Interceptor {

	/**
	 * Initialise JVM properties for Interceptor<br/>
	 * RIORBInitializer_impl is call at this point
	 */
	public static void init() {
		Properties props = System.getProperties();
		props.put("org.omg.PortableInterceptor.ORBInitializerClass.corbaTrace.interceptorCore.RIORBInitializer_impl", "");
	}
}
