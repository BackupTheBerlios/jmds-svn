/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace.interceptorCore;

import org.omg.PortableInterceptor.*;
import org.omg.PortableInterceptor.ORBInitInfoPackage.*;
import org.omg.CORBA.LocalObject;
import org.omg.CORBA.Any;
import org.omg.Dynamic.*;
import org.omg.DynamicAny.*;
import org.omg.DynamicAny.DynAnyPackage.*;
import org.omg.DynamicAny.DynAnyFactoryPackage.*;

/**
 * ORB Initializer for the server and client request interceptors <br/>
 * This class is automaticly call by the ORB
 * @author Etienne Juliot
 * @version 0.1
 */
final public class RIORBInitializer_impl extends LocalObject implements ORBInitializer {
    // IDL to Java Mapping
    public void pre_init(ORBInitInfo info) {
    }

    public void post_init(ORBInitInfo info) {
        // Register the policy factory
        PolicyFactory pf = new LoggerPolicyFactory_impl();
        info.register_policy_factory(LOGGER_POLICY_ID.value, pf);

        // Allocate state slot for dataflow between Client and Server
        int slotId = info.allocate_slot_id();

        // Create the interceptors
        ClientRequestInterceptor clientInterceptor = new ClientRequestInterceptorLogger(info, slotId);
        ServerRequestInterceptor serverInterceptor = new ServerRequestInterceptorLogger(info, slotId);

        // Register the interceptors
        try {
            info.add_client_request_interceptor(clientInterceptor);
            info.add_server_request_interceptor(serverInterceptor);
        } catch (DuplicateName ex) {
            throw new RuntimeException();
        }
    }
}
