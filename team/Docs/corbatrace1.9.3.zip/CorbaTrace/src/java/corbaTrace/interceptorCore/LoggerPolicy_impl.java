/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace.interceptorCore;

import org.omg.CORBA.LocalObject;
import org.omg.CORBA.Policy;

/**
 * Request interceptor logger policy
 */
final class LoggerPolicy_impl extends LocalObject implements LoggerPolicy {
    // The log level
    private short level_;

    // constructor
    public LoggerPolicy_impl(short level) {
        level_ = level;
    }

    // IDL to Java Mapping
    public short level() {
        return level_;
    }

    public int policy_type() {
        return LOGGER_POLICY_ID.value;
    }

    public Policy copy() {
        return this;
    }

    public void destroy() {
    }
}
