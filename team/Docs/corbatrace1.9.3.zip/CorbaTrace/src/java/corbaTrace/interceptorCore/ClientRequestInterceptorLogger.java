/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace.interceptorCore;

import java.util.Date;
import org.omg.CORBA.*;
import org.omg.PortableInterceptor.*;
import org.omg.PortableInterceptor.ORBInitInfoPackage.*;

import corbaTrace.logger.*;
import corbaTrace.utils.IndentString;

/** interceptor logging for Client 
 * @author Etienne Juliot
 * @version 0.1
 */
public class ClientRequestInterceptorLogger
	extends RequestInterceptorLogger
	implements ClientRequestInterceptor {

	// constructor

	public ClientRequestInterceptorLogger(ORBInitInfo info, int slotId) {
		super(info, slotId);
	}

	// ==================================================================
	// ==================================================================
	//
	// methods implemented from ClientRequestInterceptor
	// they are :   name(), destroy()
	//              receive_exception(), receive_other(), receive_reply(), send_poll(), send_request()

	public String name() {
		return ("ClientRequestInterceptorLogger");
	}

	// -----------------------------------------------------------------

	public void destroy() {
	}

	// -----------------------------------------------------------------

	//
	// D�finition des diff�rents points d'interception
	//
	//
	// This interception point allows an Interceptor to query request
	// information and modify the service context before the request
	// is sent.
	//
	public void send_request(ClientRequestInfo ri) throws ForwardRequest {

		if (isLogActivate(ri)) {

			Date date = new Date();

			//
			// Try to get the Dataflow from slot
			//
			try {
				Any any;
				try {
					any = createAny();

					Dataflow flow = getDataflow(ri);
					flow.date_send = date.getTime();
					flow.request_id = ri.request_id();
					DataflowHelper.insert(any, flow);
				} catch (
					org
						.omg
						.DynamicAny
						.DynAnyFactoryPackage
						.InconsistentTypeCode ex) {
					any = ri.get_slot(mySlotId_);
				}
				TypeCode tc = any.type();

				if (tc.kind() != TCKind.tk_null) {
					//
					// Encode Dataflow
					//

					byte[] data = cdrCodec_.encode_value(any);

					//
					// Add encoded Dataflow to service context
					//
					org.omg.IOP.ServiceContext sc =
						new org.omg.IOP.ServiceContext();
					sc.context_id = REQUEST_CONTEXT_ID;
					sc.context_data = data;
					ri.add_request_service_context(sc, false);
				}
			} catch (InvalidSlot ex) {
				// Ignore failure
			} catch (org.omg.IOP.CodecPackage.InvalidTypeForEncoding ex) {
				// Ignore failure
			}
			displayRequestInfo(new CbtLogRecord(date), ri, "send_request");
		}
	}

	// -----------------------------------------------------------------

	//
	// This interception point allows an Interceptor to query
	// information during a TimeIndependent Infocation (TII)
	// polling get reply sequence.
	//
	public void send_poll(ClientRequestInfo ri) {
		// Sur ce point d'interception, on affiche rien
	}

	// -----------------------------------------------------------------

	//
	// This interception point allows an Interceptor to query
	// the information on a reply after it is returned from the
	// server and before control is returned to the client.
	// 
	public void receive_reply(ClientRequestInfo ri) {
		displayRequestInfo(ri, "receive_reply");
	}

	// -----------------------------------------------------------------

	//
	// This interception point allows an Interceptor to query
	// the exception information before the exception is raised
	// to the client.
	//
	public synchronized void receive_exception(ClientRequestInfo ri)
		throws ForwardRequest {
		displayRequestInfo(ri, "receive_exception");
	}

	// -----------------------------------------------------------------

	//
	// This interception point allows an Interceptor to query
	// the information available when a request results in
	// something other than a normal reply or an exception.
	//
	public void receive_other(ClientRequestInfo ri) throws ForwardRequest {
		// Sur ce point d'interception, On affiche rien
	}

	// ==================================================================
	// ==================================================================

	// -----------------------------------------------------------------

	//
	// Get the Client logging level (an interception level)
	//
	protected short getLogLevel(RequestInfo info) {
		ClientRequestInfo ri = (ClientRequestInfo) info;
		short level_aux = 0;

		try {
			//
			// Get the logger policy of the server
			//
			Policy policy = ri.get_request_policy(LOGGER_POLICY_ID.value);
			LoggerPolicy loggerPolicy = LoggerPolicyHelper.narrow(policy);
			level_aux = loggerPolicy.level();
		} catch (INV_POLICY ex) {
			System.err.println(
				"failed to get the server Policy, while getting logging level.");
			// Failed to get policy
		} catch (BAD_PARAM ex) {
			System.err.println(
				"failed to narrow Server Policy, while getting logging level.");
			// Failed to narrow policy
		}

		return level_aux;
	}

	//
	// Convert CORBA::Octet to string
	//
	public String getOctet(byte octet) {
		String prefix;
		if (octet < 0x10)
			prefix = "<0";
		else
			prefix = "<";

		return prefix + Integer.toHexString(octet) + ">";
	}

	// ==================================================================
	// ==================================================================

	protected void insertLogDetail(CbtLogRecord log, RequestInfo riInfo) {

		IndentString out = new IndentString();

		if (riInfo instanceof ClientRequestInfo) {
			//
			// Display effective profile
			//
			ClientRequestInfo info = (ClientRequestInfo) riInfo;
			// --------------------------------------------------------
			// On doit pouvoir se d�merder avec le profile du  dessous
			// --------------------------------------------------------

			//
			org.omg.IOP.TaggedProfile profile = info.effective_profile();

			out.indent();
			out.append("<effective_profile type=\"");

			if (profile.tag == org.omg.IOP.TAG_INTERNET_IOP.value)
				out.append("TAG_INTERNET_IOP");
			else if (profile.tag == org.omg.IOP.TAG_MULTIPLE_COMPONENTS.value)
				out.append("TAG_MULTIPLE_COMPONENTS");
			else
				out.append("UNKNOWN_TAG");

			out.append("\">");
			out.newLine();

			if (profile.profile_data.length > 0) {

				byte[] prof = new byte[profile.profile_data.length];
				for (int j = 0; j < profile.profile_data.length; j++) {
					prof[j] = profile.profile_data[j];
				}
				String profChaine = new String(prof);
			}

			for (int i = 0; i < profile.profile_data.length; i++) {
				out.insert(getOctet(profile.profile_data[i]));
			}
			out.insert("</effective_profile>");

			// 
			// On affiche les objets target et effective target pr�sents
			// dans les clientRequestInfo
			//

			org.omg.CORBA.Object cible = info.target();
			org.omg.CORBA.Object cible2 = info.effective_target();
			String cibleString = cible.toString();
			out.indent();
			out.insert("<target name=\"" + cibleString + "\">");

			out.insert("<effective_target name=\"" + cible2.toString() + "\"");

		}
		log.setLogDetail(out.toString());

	}

	// ==================================================================
	// ==================================================================

	protected void insertDistantObject(CbtLogRecord log, RequestInfo info) {}

	protected String getNameLogFile(RequestInfo info) {
		return getClientId(info);
	}

	/**
	 *    methods redefined from RequestInterceptorLogger, used specifically by the Server
	 */

	protected String getServerId(RequestInfo info) {
		//return(((ClientRequestInfo)info).target().getClass().toString());
		return "ServerId";
	}

	protected String getLocalObjectId(RequestInfo info) {
		return getClientId(info);
	}

	protected String getDistantObjectId(RequestInfo info) {
		return getServerId(info);
	}

} // end class ClientRequestInterceptorPolicy
