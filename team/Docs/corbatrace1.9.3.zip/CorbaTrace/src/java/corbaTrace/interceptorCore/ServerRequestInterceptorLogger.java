/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace.interceptorCore;

import org.omg.CORBA.*;
import org.omg.PortableInterceptor.*;
import org.omg.PortableInterceptor.ORBInitInfoPackage.*;

import corbaTrace.logger.*;
import corbaTrace.utils.IndentString;

/** interceptor logging for Server 
 * @author Etienne Juliot
 * @version 0.1
 */
public class ServerRequestInterceptorLogger
	extends RequestInterceptorLogger
	implements ServerRequestInterceptor {

	// constructor
	public ServerRequestInterceptorLogger(ORBInitInfo info, int slotId) {
		super(info, slotId);
	}

	// ==================================================================
	// ==================================================================
	//
	// methods implemented from ServerRequestInterceptor
	// they are :   name(), destroy()
	//              receive_request_service_contexts(), receive_request(), send_exception(), send_other(), send_reply()
	//
	public String name() {
		return ("ServerRequestInterceptorLogger");
	}

	public void destroy() {
	}

	/**
	 * Interception point : <br/>
	 * <br/>
	 * At this interception point, Interceptors must get their service
	 * context information from the incoming request and transfer it
	 * to a slot of PortableInterceptor::Current.
	 */
	public void receive_request_service_contexts(ServerRequestInfo ri)
		throws ForwardRequest {
		System.out.println("receive_request_service_contexts");
		// il s'agit d'un point d'interception qui ne nous int�resse pas. 
		// On ne g�re donc pas l'affichage dans ce point d'interception.
		if (isLogActivate(ri)) {
			//
			// Get the Dataflow from the service context
			//
			Dataflow flow = null;
			org.omg.CORBA.Any any = null;
			try {
				// Get encoded Dataflow from service context
				org.omg.IOP.ServiceContext sc =
					ri.get_request_service_context(REQUEST_CONTEXT_ID);

				// Decode Dataflow
				try {
					any =
						cdrCodec_.decode_value(
							sc.context_data,
							DataflowHelper.type());
				} catch (org.omg.IOP.CodecPackage.TypeMismatch ex) {
					// Ignore failure in this demo
					return;
				} catch (org.omg.IOP.CodecPackage.FormatMismatch ex) {
					// Ignore failure
					return;
				}

				try {
					flow = DataflowHelper.extract(any);
				} catch (org.omg.CORBA.BAD_OPERATION ex) {
					// Ignore failure
					return;
				}
				if (flow == null)
					throw new RuntimeException();
			} catch (org.omg.CORBA.BAD_PARAM ex) {
				// Service context was not previously set 
			}

			DataflowHelper.insert(any, flow);
			try {
				ri.set_slot(mySlotId_, any);
			} catch (InvalidSlot ex) {
				// Ignore failure
				return;
			}

		}
	}

	// -----------------------------------------------------------------

	/**
	 * This interception point allows an Interceptor to query request
	 * information after all the information, including operation
	 * parameters, are available.
	 */
	public void receive_request(ServerRequestInfo ri) throws ForwardRequest {
		System.out.println("receive_request");
		displayRequestInfo(ri, "receive_request");
	}

	// -----------------------------------------------------------------

	/**
	 * This interception point allows an Interceptor to query reply
	 * information and modify the reply service context after the
	 * target operation has been invoked and before the reply is
	 * returned to the client.
	 */
	public void send_reply(ServerRequestInfo ri) {
		System.out.println("send_reply");
		displayRequestInfo(ri, "send_reply");
	}

	// -----------------------------------------------------------------

	/**
	 * This interception point allows an Interceptor to query the
	 * exception information and modify the reply service context
	 * before the exception is raised to the client.
	 */
	public void send_exception(ServerRequestInfo ri) throws ForwardRequest {
		System.out.println("send_exception");
		displayRequestInfo(ri, "send_exception");
	}

	// -----------------------------------------------------------------

	/**
	 * This interception point allows an Interceptor to query
	 * the information available when a request results in
	 * something other thatn a normal reply or an exception.
	 */
	public void send_other(ServerRequestInfo ri) throws ForwardRequest {
		System.out.println("send_other");
		displayRequestInfo(ri, "send_other");
	}

	// ==================================================================
	// ==================================================================

	/**
	 * Get the Server logging level (an interception level)
	 */
	protected short getLogLevel(RequestInfo info) {
		ServerRequestInfo ri = (ServerRequestInfo) info;
		short level_aux = 0;

		try {
			// Get the logger policy of the server
			Policy policy = ri.get_server_policy(LOGGER_POLICY_ID.value);
			LoggerPolicy loggerPolicy = LoggerPolicyHelper.narrow(policy);
			level_aux = loggerPolicy.level();
		} catch (INV_POLICY ex) {
			System.err.println("failed to get the server Policy, while getting logging level.");
			// Failed to get policy
		} catch (BAD_PARAM ex) {
			//System.err.println ("failed to narrow Server Policy, while getting logging level."); // Failed to narrow policy
		}

		return level_aux;
	}

	// ==================================================================
	// ==================================================================

	/**
	 * Methods redefined from RequestInterceptorLogger, used specifically by the Server
	 */

	//
	// Display sending exception
	//
	protected void insertSendingException(CbtLogRecord log, RequestInfo info) {
		try {
			Any exception = ((ServerRequestInfo) info).sending_exception();
			//log.setSendingException(AnyConverter.getValue(exception));
		} catch (BAD_INV_ORDER ex) {
			System.err.println("\nOperation not supported in this context : " + ex + "\n");
		}

	}

	// ------------------------------------------------------------------------------

	protected void insertLogDetail(CbtLogRecord log, RequestInfo riInfo) {

		IndentString out = new IndentString();

		if (riInfo instanceof ServerRequestInfo) {
			// Display object id
			ServerRequestInfo info = (ServerRequestInfo) riInfo;
			try {

				byte[] octets = info.object_id();
				out.indent();
				out.append("object id = ");

				out.newLine();
			} catch (BAD_INV_ORDER ex) {
				System.err.println("\nOperation not supported in this context : " + ex + "\n");
			}

			// Display adapter id
			try {
				byte[] octets = info.adapter_id();
				out.indent();
				out.append("adapter id = ");
				out.newLine();
			} catch (BAD_INV_ORDER ex) {
				System.err.println("\nOperation not supported in this context : " + ex + "\n");
			}

			// Display target most derived interface
			try {
				String tmdi = info.target_most_derived_interface();
				out.insert("<targetMostDerivedInterface name=\"" + tmdi + "\"/>");
			} catch (org.omg.CORBA.BAD_INV_ORDER ex) {
				System.err.println("\nOperation not supported in this context : " + ex + "\n");
			}
		}
		log.setLogDetail(out.toString());
	}

	protected String getNameLogFile(RequestInfo info) {
		return getServerId(info);
	}

	// -----------------------------------------------------------------

	protected void insertDistantObject(CbtLogRecord log, RequestInfo info) {
		log.setDistantObjectId(getDistantObjectId(info));
		log.setDistantDate(getDistantDate(info));
		log.setDistantRequestId(getDataflow(info).request_id);
	}

	protected String getServerId(RequestInfo info) {
		return new String((((ServerRequestInfo) info).object_id()));
	}

	protected String getLocalObjectId(RequestInfo info) {
		return getServerId(info);
	}

	protected String getDistantObjectId(RequestInfo info) {
		return getClientId(info);
	}

	protected void setDataflow(Dataflow flow, ServerRequestInfo info) {
		Any any;
		try {
			any = createAny();

			DataflowHelper.insert(any, flow);
			info.set_slot(mySlotId_, any);
		} catch (org.omg.PortableInterceptor.InvalidSlot e) {
		} catch (
			org.omg.DynamicAny.DynAnyFactoryPackage.InconsistentTypeCode ex) {
		}
	}
} // end class ServerRequestInterceptorLogger