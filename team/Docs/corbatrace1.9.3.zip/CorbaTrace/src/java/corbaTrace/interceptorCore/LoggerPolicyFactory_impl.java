/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace.interceptorCore;

import org.omg.PortableInterceptor.*;
import org.omg.CORBA.*;

/**
 * Request interceptor logger policy factory
 */
final class LoggerPolicyFactory_impl extends LocalObject implements PolicyFactory {
    // IDL to Java Mapping
    public Policy create_policy(int type, Any any) throws PolicyError {
        if (type == LOGGER_POLICY_ID.value) {
            try {
                short val = any.extract_short();

                return new LoggerPolicy_impl(val);
            } catch (BAD_OPERATION ex) {
            }

            throw new PolicyError(BAD_POLICY_TYPE.value);
        }
        throw new PolicyError(BAD_POLICY.value);
    }
}
