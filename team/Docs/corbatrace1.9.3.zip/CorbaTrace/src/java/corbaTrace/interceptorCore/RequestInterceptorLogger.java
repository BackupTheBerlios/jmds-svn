/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace.interceptorCore;

import java.io.*;
import java.util.*;
import java.text.*;
import org.omg.CORBA.*;
import org.omg.Dynamic.*;
import org.omg.DynamicAny.*;
import org.omg.DynamicAny.DynAnyPackage.*;
import org.omg.DynamicAny.DynAnyFactoryPackage.*;
import org.omg.PortableInterceptor.*;
import org.omg.PortableInterceptor.ORBInitInfoPackage.*;
import org.omg.IOP.Codec;

import corbaTrace.logger.*;
import corbaTrace.utils.*;

/** abstract class for interceptor logging facilities 
 * @author Etienne Juliot
 * @version 0.1
 */
public abstract class RequestInterceptorLogger extends LocalObject {

    /** ==================================================================<br/>
    *<br/>
    *  Attributes & Constructors<br/>
    *<br/>
    *<br/>
    * note : we shoudn't define attributes & constructors here<br/>
    *        because it's an abstract class.<br/>
    *        But, as our Server & Client Interceptor Loggers<br/>
    *        are based on the same constructeur model, and as<br/>
    *        Java allows to define attributes/constructors even in<br/>
    *        abstract classes, we do it this way to make the code more clear.<br/>
    * ==================================================================
    */

    //
    // Attributes
    //

    //
    // D�finition d'un tableau de flux de sortie
    //

    // Used to encode/decode the call stack information so that
    // it can be used as the service context
    protected Codec cdrCodec_;

    // slot id
    protected int mySlotId_;
    public static int slotId;

    // for identifying client or server.
    protected DynAnyFactory dynAnyFactoryS_;

    // for converting any in a specific type
    protected AnyConverter anyConverter;

    // ------------------------------------------------------------------------------

    //
    // Constants
    //

    // Service context identifiers
    protected final int REQUEST_CONTEXT_ID = 100;
    protected final int REPLY_CONTEXT_ID = 101;

    // ------------------------------------------------------------------------------

    /**
     * constructor
     */
    public RequestInterceptorLogger(ORBInitInfo info, int slotId) {
        mySlotId_ = slotId;
        this.slotId = slotId;

        // Get the codec factory
        org.omg.IOP.CodecFactory factory = info.codec_factory();
        if (factory == null)
            throw new RuntimeException();

        // Create codec
        org.omg.IOP.Encoding how = new org.omg.IOP.Encoding();
        how.major_version = 1;
        how.minor_version = 0;
        how.format = org.omg.IOP.ENCODING_CDR_ENCAPS.value;

        try {
            cdrCodec_ = factory.create_codec(how);
        } catch (org.omg.IOP.CodecFactoryPackage.UnknownEncoding ex) {
            throw new RuntimeException();
        }

        if (cdrCodec_ == null) {
            throw new RuntimeException();
        }

        // Get the dynamic any factory
        DynAnyFactory dynAnyFactory = null;
        try {
            org.omg.CORBA.Object obj = info.resolve_initial_references("DynAnyFactory");
            dynAnyFactory = DynAnyFactoryHelper.narrow(obj);
        } catch (InvalidName ex) {
            throw new RuntimeException();
        } catch (org.omg.CORBA.BAD_PARAM ex) {
            throw new RuntimeException();
        }

        dynAnyFactoryS_ = dynAnyFactory;
        anyConverter = new AnyConverter(dynAnyFactoryS_);

    } // end constructor

    // ==================================================================
    // ==================================================================

    /** 
     *    RequestInterceptorLogger offers various methods for generating a log file.
     */

    private void insertHeader(CbtLogRecord log, RequestInfo info, String type) {
        // get current date and converts it as String using a defined date format (df).
        Date dt = new Date();
        String laDate = DateUtilities.dateToString(dt);

        // insert the message type, the date and time.
        log.setRequestId(info.request_id());
        log.setMesgType(type);

        log.setLocalObjectId(getLocalObjectId(info));

        insertDistantObject(log, info);
    }

    // ------------------------------------------------------------------------------

    private void insertArguments(CbtLogRecord log, RequestInfo info) {
        // Display arguments
        try {
            Parameter[] args = info.arguments();

            if (args.length != 0) {
                // for each argument
                for (int i = 0; i < args.length; i++) {
                    String inout;
                    String value;
                    String type;

                    // 1) add argument's I/O status : in, out, inout
                    if (args[i].mode == org.omg.CORBA.ParameterMode.PARAM_IN) {
                        inout = "in";
                    } else if (args[i].mode == org.omg.CORBA.ParameterMode.PARAM_OUT) {
                        inout = "out";
                    } else { // case PARAM_INOUT
                        inout = "inout";
                    }

                    // 2) add argument's value
                    Any clientName = args[i].argument;
                    value = anyConverter.getValue(clientName);

                    // 3) add argument's type
                    type = anyConverter.getValue(clientName.type());
                    log.addArgument(inout, value, type);
                }
            }
        } catch (BAD_INV_ORDER ex) {
            System.err.println("\nOperation not supported in this context : " + ex + "\n");
        } catch (NO_RESOURCES ex) {
            System.err.println("\nOperation not supported in this environnement : " + ex + "\n");
        }

    }

    // ------------------------------------------------------------------------------

    //
    // Display sending exception
    //  => must be redefined by the server logging class.
    protected void insertSendingException(CbtLogRecord log, RequestInfo info) {
    }

    // Display exceptions
    private void insertException(CbtLogRecord log, RequestInfo info) {

        try {
            org.omg.CORBA.TypeCode[] exceptions = info.exceptions();

            if (exceptions.length != 0) {
                for (int i = 0; i < exceptions.length; i++) {
                    log.addException(anyConverter.getValue(exceptions[i]));
                }
            }
        } catch (org.omg.CORBA.BAD_INV_ORDER ex) {
			System.err.println("\nOperation not supported in this context : " + ex + "\n");
        } catch (org.omg.CORBA.NO_RESOURCES ex) {
            // Operation not supported in this environment
        }

    }

    // Display result
    private void insertResult(CbtLogRecord log, RequestInfo info) {
        try {
            org.omg.CORBA.Any result = info.result();

            log.setResult(anyConverter.getValue(result));
        } catch (org.omg.CORBA.BAD_INV_ORDER ex) {
        	System.err.println("\nOperation not supported in this context : " + ex + "\n");
        } catch (org.omg.CORBA.NO_RESOURCES ex) {
            // Operation not supported in this environment
        }
    }

    //
    // Display response expected
    //
    private void insertResponseExpected(CbtLogRecord log, RequestInfo info) {
        log.setResponseExpected(info.response_expected());
    }

    //
    // Display reply status
    //
    private void insertReplyStatus(CbtLogRecord log, RequestInfo info) {
        try {
            short status = info.reply_status();

            String statusStr;

            if (status == org.omg.PortableInterceptor.SUCCESSFUL.value)
                statusStr = "successful";
            else if (status == org.omg.PortableInterceptor.SYSTEM_EXCEPTION.value)
                statusStr = "system_exception";
            else if (status == org.omg.PortableInterceptor.USER_EXCEPTION.value)
                statusStr = "user_exception";
            else if (status == org.omg.PortableInterceptor.LOCATION_FORWARD.value)
                statusStr = "location_forward";
            //else if (status == org.omg.PortableInterceptor.LOCATION_FORWARD_PERMANENT.value)
            //statusStr = "location_forward_permanent";
            else if (status == org.omg.PortableInterceptor.TRANSPORT_RETRY.value)
                statusStr = "transport_retry";
            else
                statusStr = "unknown_reply_status";

            log.setReplyStatus(statusStr);
        } catch (org.omg.CORBA.BAD_INV_ORDER ex) {
			System.err.println("\nOperation not supported in this context : " + ex + "\n");
        }
    }

    // ------------------------------------------------------------------------------

    private void insertOptions(CbtLogRecord log, RequestInfo info, short logLevel) {
        insertException(log, info);

        insertResponseExpected(log, info);

        insertReplyStatus(log, info);

        // inserts sending informations (for Servers only)
        insertSendingException(log, info);

        if (logLevel > 2)
            // inserts object ID, Display Adapter Id, etc.
            insertLogDetail(log, info);

    }

    //
    // Display PortableInterceptor::RequestInfo
    // This method gets and write intercepted messages in a log file.
    //
    protected void displayRequestInfo(RequestInfo info, String type) {
        displayRequestInfo(new CbtLogRecord(), info, type);
    }

    // ------------------------------------------------------------------------------

    //
    // Display PortableInterceptor::RequestInfo
    // This method gets and write intercepted messages in a log file.
    //
    protected void displayRequestInfo(CbtLogRecord log, RequestInfo info, String type) {

        if (isLogActivate(info)) {
            short logLevel = getLogLevel(info);

            // inserts Header with date, time, and IDs informations.
            insertHeader(log, info, type);
            // inserts current operation and its arguments.
            log.setOperationName(info.operation());
            insertArguments(log, info);
            insertResult(log, info);
            insertOptions(log, info, logLevel);

            //get logger and log
            CbtLogger.getLogger(getNameLogFile(info)).log(log);
        }

    } // End DisplayRequestInfo()

    protected abstract void insertDistantObject(CbtLogRecord log, RequestInfo info);

    protected abstract String getNameLogFile(RequestInfo info);

    protected abstract String getServerId(RequestInfo info);

    protected abstract String getLocalObjectId(RequestInfo info);

    protected abstract String getDistantObjectId(RequestInfo info);

    protected abstract short getLogLevel(RequestInfo info);

    protected boolean isLogActivate(RequestInfo info) {
        short l = getLogLevel(info);
        if (l > 0)
            return true;
        else
            return false;
    }

    protected String getClientId(RequestInfo info) {
        String id;
        try {
            id = getDataflow(info).client_id;
        } catch (org.omg.CORBA.BAD_OPERATION e) {
            id = "Unknown";
        }
        return (id);
    }

    protected abstract void insertLogDetail(CbtLogRecord log, RequestInfo info);

    protected Dataflow getDataflow(RequestInfo info) throws org.omg.CORBA.BAD_OPERATION {

        try {
            Any any = info.get_slot(mySlotId_);
            if (any == null)
                throw new org.omg.CORBA.BAD_OPERATION();
            Dataflow flow = DataflowHelper.extract(any);
            return flow;
        } catch (org.omg.PortableInterceptor.InvalidSlot e) {
            throw new org.omg.CORBA.BAD_OPERATION(e.getMessage());
        }
    }

    protected String getDistantDate(RequestInfo info) {
        try {
            long date = getDataflow(info).date_send;
            return DateUtilities.dateToString(new Date(date));
        } catch (org.omg.CORBA.BAD_OPERATION e) {
            return null;
        }
    }

    protected Any createAny() throws org.omg.DynamicAny.DynAnyFactoryPackage.InconsistentTypeCode {
        org.omg.DynamicAny.DynAny dynAny = dynAnyFactoryS_.create_dyn_any_from_type_code(DataflowHelper.type());
        return dynAny.to_any();

    }
}
