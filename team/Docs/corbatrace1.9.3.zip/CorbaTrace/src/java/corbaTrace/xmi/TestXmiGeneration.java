package corbaTrace.xmi;


/**
   this is a test class to test this part of the project, that's to say the generation of an XMI file with this framework
@author Florian Champalle
**/
public class TestXmiGeneration {

/**
the contructor is empty while not used.
 **/
  public TestXmiGeneration(){

  }

/**
the main function constructs an XMI test document with 1 class with 2 operations, 3 roles, 3 messages...
Both Rational Rose extensions and Magicdraw UML extensions are added.
The DOM tree is written to a file called testXmi.xml in the current directory. It is replaced at every execution.
@param args no arguments needed here
 **/
  public static void main(String args[]){
    //creation of the classes and roles
    XmiDocument doc=new XmiDocument();
    XmiModel model=new XmiModel(doc, "FirstTest");
    doc.addModel(model);
    XmiClass _class=new XmiClass(doc,"FirstClass");
    model.addClass(_class);
    XmiDatatype dt1=new XmiDatatype(doc,"string");
    model.addDatatype(dt1);
    XmiDatatype dt2=new XmiDatatype(doc,"boolean");
    model.addDatatype(dt2);
    XmiOperation op=new XmiOperation(doc, "say_hello");
    _class.addOperation(op);
    XmiParameter arg1=new XmiParameter(doc,"argument1","in",dt1);
    op.addArgument(arg1);
    XmiParameter arg2=new XmiParameter(doc,"argument2","inout",dt2);
    op.addArgument(arg2);
    XmiOperation op2=new XmiOperation(doc,"say_goodbye");
    _class.addOperation(op2);
    XmiSequenceDiagram seqDiag=new XmiSequenceDiagram(doc, "FirstDiagram");
    model.addSequenceDiagram(seqDiag);
    XmiClassifierRole role1=new XmiClassifierRole(doc,"InstanceTest1",_class);
    seqDiag.addClassifierRole(role1);
    XmiClassifierRole role2=new XmiClassifierRole(doc,"InstanceTest2",_class);
    seqDiag.addClassifierRole(role2);
    XmiClassifierRole role3=new XmiClassifierRole(doc,"InstanceTest3",_class);
    seqDiag.addClassifierRole(role3);

    //creation of the actions
    XmiCallAction action=new XmiCallAction(doc,"action1",op);
    model.addCallAction(action);
    XmiCallAction action2=new XmiCallAction(doc,"action2",op2);
    model.addCallAction(action2);

    //creation of the messages
    XmiMessage msg=new XmiMessage(doc,"message1",role1,role2,action,null);
    XmiMessage msg2=new XmiMessage(doc,"message2",role3,role1,action,null);
    XmiMessage msg3=new XmiMessage(doc,"message3",role2,role1,action2,null);
    seqDiag.addMessage(msg);
    seqDiag.addMessage(msg2);
    seqDiag.addMessage(msg3);

    //add extensions
    doc.createMagicDrawExtensions();
    //doc.createRoseExtensions();

    //doc.writeToFile(args[0]);
    doc.writeToFile("./testXmi.xml");
  }

}
