package corbaTrace.xmi;

import org.w3c.dom.*;
import java.util.Vector;

/**
   This class represents an Xmi class. It can have operations.
   @author Florian Champalle
 **/

public class XmiClass extends XmiElement{
    /**the DOM element where the operation elements must be added **/
  private Element operationParent;
    /** collection of the XmiOperations of the class**/
  private Vector operations;
    /** DOM element where the reference of the nameSpace must be added**/
  private Element namespaceElement;

    /**
       the constructor of the class. It calls the initClass method
       @param doc the document we are creating
       @param name the name of the class
     **/
  public XmiClass(XmiDocument doc, String name){
    this.name=name;
    this.doc=doc;
    this.operations=new Vector();

    initClass();
  }

    /** get accessor for the operation collection**/
  public Vector getOperations(){
    return this.operations;
  }

    /** 
	set accessor for the nameSpaceReference
	@param ref the id of the namespace-
    **/
  public void setNamespaceRef(String ref){
    this.namespaceElement.setAttribute("xmi.idref",ref);
  }

    /**
       This method create the DOM element representing the class.
     **/
  private void initClass(){
    /**
    <Foundation.Core.Class xmi.id = 'S.10001'>
      <Foundation.Core.ModelElement.name>Objet2</Foundation.Core.ModelElement.name>
      <Foundation.Core.ModelElement.visibility xmi.value = 'public'/>
      <Foundation.Core.GeneralizableElement.isRoot xmi.value = 'true'/>
      <Foundation.Core.GeneralizableElement.isLeaf xmi.value = 'true'/>
      <Foundation.Core.GeneralizableElement.isAbstract xmi.value = 'false'/>
      <Foundation.Core.Class.isActive xmi.value = 'false'/>
      <Foundation.Core.ModelElement.namespace>
        <Model_Management.Model xmi.idref = 'G.1'/> <!-- ExempleRose2 -->
      </Foundation.Core.ModelElement.namespace>
      <Foundation.Core.ModelElement.taggedValue>
        <Foundation.Extension_Mechanisms.TaggedValue>
          <Foundation.Extension_Mechanisms.TaggedValue.tag>
            persistence
          </Foundation.Extension_Mechanisms.TaggedValue.tag>
          <Foundation.Extension_Mechanisms.TaggedValue.value>
            transient
          </Foundation.Extension_Mechanisms.TaggedValue.value>
        </Foundation.Extension_Mechanisms.TaggedValue>
      </Foundation.Core.ModelElement.taggedValue>
      <Foundation.Core.Classifier.feature>

        //addOperation ici

      </Foundation.Core.Classifier.feature>
    </Foundation.Core.Class>
    **/

    this.me=doc.getDocument().createElement("Foundation.Core.Class");
    this.id=this.doc.getUniqueId();
    this.me.setAttribute("xmi.id",this.id);
    Element elem2=doc.getDocument().createElement("Foundation.Core.ModelElement.name");
    elem2.appendChild(doc.getDocument().createTextNode(name));
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.ModelElement.visibility");
    elem2.setAttribute("xmi.value","public");
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isRoot");
    elem2.setAttribute("xmi.value","true");
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isLeaf");
    elem2.setAttribute("xmi.value","true");
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isAbstract");
    elem2.setAttribute("xmi.value","false");
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.Class.isActive");
    elem2.setAttribute("xmi.value","false");
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.ModelElement.namespace");
    this.me.appendChild(elem2);
    this.namespaceElement=doc.getDocument().createElement("Model_Management.Model");
    this.namespaceElement.setAttribute("xmi.idref",""); //left empty until the class is added to a model
    elem2.appendChild(this.namespaceElement);

    elem2=doc.getDocument().createElement("Foundation.Core.ModelElement.taggedValue");
    this.me.appendChild(elem2);
    Element elem3=doc.getDocument().createElement("Foundation.Extension_Mechanisms.TaggedValue");
    elem2.appendChild(elem3);
    Element elem4=doc.getDocument().createElement("Foundation.Extension_Mechanisms.TaggedValue.tag");
    elem4.appendChild(doc.getDocument().createTextNode("persistence"));
    elem3.appendChild(elem4);
    elem4=doc.getDocument().createElement("Foundation.Extension_Mechanisms.TaggedValue.value");
    elem4.appendChild(doc.getDocument().createTextNode("transient"));
    elem3.appendChild(elem4);

    this.operationParent=doc.getDocument().createElement("Foundation.Core.Classifier.feature");
    this.me.appendChild(this.operationParent);

  }

    /** this method adds the XmiOperation to this class.
	@param operation the XmiOperation to add to this class
    **/
  public void addOperation(XmiOperation operation){
    this.operationParent.appendChild(operation.getElement());
    this.operations.addElement(operation);
  }

}
