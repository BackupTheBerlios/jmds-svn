package corbaTrace.xmi;

import org.w3c.dom.*;
import java.util.*;

/**
This class represents an Xmi sequence diagram. It has roles and messages.
@author Florian Champalle
 **/

public class XmiSequenceDiagram extends XmiElement{

    /** the DOM node where the roles must be added**/
  private Element roleParent;
    /** the DOM node where the messages must be added**/
  private Element messageParent;
    /** collection of all the roles of the diagram**/
  private Vector roles;
    /**the last message added to the diagram **/
  private XmiMessage predecessor;
    /**collection of all the messages of the diagram**/
  private Vector messages;

    /**
       constructor of the class. Calls the init method.
       @param doc the document we are creating
       @param name the name of the diagram
     **/
  public XmiSequenceDiagram(XmiDocument doc, String name){
    this.doc=doc;
    this.roles=new Vector();
    this.name=name;
    this.predecessor=null;
    this.messages=new Vector();
    initDiagram();
  }

    /**
       get accessor of the roles collection
     **/
  public Vector getRoles(){
    return this.roles;
  }

    /**
       get accessor of the messages collection.
     **/
  public Vector getMessages(){
    return this.messages;
  }

    /**
       This method creates the DOM element representing the sequence diagram.
     **/
  private void initDiagram(){
    //TAKE CARE: the DTD umd.dtd specifies there must be at least 1 message in the diagram
    //(even if no role???)

    /**
      <Behavioral_Elements.Collaborations.Collaboration xmi.id = 'G.2'>
        <Foundation.Core.ModelElement.name>DiagSeq1</Foundation.Core.ModelElement.name>
        <Foundation.Core.ModelElement.visibility xmi.value = 'private'/>
        <Foundation.Core.ModelElement.taggedValue>
          <Foundation.Extension_Mechanisms.TaggedValue>
            <Foundation.Extension_Mechanisms.TaggedValue.tag>DiagramType</Foundation.Extension_Mechanisms.TaggedValue.tag>
            <Foundation.Extension_Mechanisms.TaggedValue.value>SequenceDiagram</Foundation.Extension_Mechanisms.TaggedValue.value>
          </Foundation.Extension_Mechanisms.TaggedValue>
        </Foundation.Core.ModelElement.taggedValue>
        <Foundation.Core.Namespace.ownedElement>

          //addClassifierRole ici

        </Foundation.Core.Namespace.ownedElement>

        <Behavioral_Elements.Collaborations.Collaboration.interaction>
          <Behavioral_Elements.Collaborations.Interaction xmi.id = 'G.14'>
            <Foundation.Core.ModelElement.name></Foundation.Core.ModelElement.name>
            <Foundation.Core.ModelElement.visibility xmi.value = 'private'/>
            <Behavioral_Elements.Collaborations.Interaction.message>

              //addMessage ici

            </Behavioral_Elements.Collaborations.Interaction.message>
          </Behavioral_Elements.Collaborations.Interaction>
        </Behavioral_Elements.Collaborations.Collaboration.interaction>
      </Behavioral_Elements.Collaborations.Collaboration>
    **/

    this.id=this.doc.getUniqueId();
    this.me=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Collaboration");
    this.me.setAttribute("xmi.id",this.id);
    Element elem=doc.getDocument().createElement("Foundation.Core.ModelElement.name");
    elem.appendChild(doc.getDocument().createTextNode(name));
    this.me.appendChild(elem);
    elem=doc.getDocument().createElement("Foundation.Core.ModelElement.visibility");
    elem.setAttribute("xmi.value","private");
    this.me.appendChild(elem);
    elem=doc.getDocument().createElement("Foundation.Core.ModelElement.taggedValue");
    this.me.appendChild(elem);
    Element elem2=doc.getDocument().createElement("Foundation.Extension_Mechanisms.TaggedValue");
    elem.appendChild(elem2);
    Element elem3=doc.getDocument().createElement("Foundation.Extension_Mechanisms.TaggedValue.tag");
    elem3.appendChild(doc.getDocument().createTextNode("DiagramType"));
    elem2.appendChild(elem3);
    elem3=doc.getDocument().createElement("Foundation.Extension_Mechanisms.TaggedValue.value");
    elem3.appendChild(doc.getDocument().createTextNode("SequenceDiagram"));
    elem2.appendChild(elem3);

    this.roleParent=doc.getDocument().createElement("Foundation.Core.Namespace.ownedElement");
    this.me.appendChild(this.roleParent);
    elem=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Collaboration.interaction");
    this.me.appendChild(elem);
    elem2=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Interaction");
    elem2.setAttribute("xmi.id",doc.getUniqueId());
    elem.appendChild(elem2);
    elem3=doc.getDocument().createElement("Foundation.Core.ModelElement.name");
    elem2.appendChild(elem3);
    elem3=doc.getDocument().createElement("Foundation.Core.ModelElement.visibility");
    elem3.setAttribute("xmi.value","private");
    elem2.appendChild(elem3);
    this.messageParent=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Interaction.message");
    elem2.appendChild(this.messageParent);

  }

    /**
       This method adds a role to the diagram
       @param role the role to add
     **/
  public void addClassifierRole(XmiClassifierRole role){
      //add the role to the diagram
    this.roleParent.appendChild(role.getElement());
    this.roles.addElement(role);
  }

    /**
       This method adds a message to the diagram.
       @param message the message to add
     **/
  public void addMessage(XmiMessage message){
    //add the message to the diagram
    this.messageParent.appendChild(message.getElement());

    //add the message to the hashset
    this.messages.addElement(message);

    //add the message as sent or received to the roles
    message.getSender().addSentMessage(message);
    message.getReceiver().addReceivedMessage(message);

    //add the successor to the message
    if (this.predecessor!=null)
	this.predecessor.setSuccessor(message);

    //add the predecessor to the message
    if (this.predecessor!=null)
	//there is a predecessor
	message.setPredecessor(this.predecessor);

    this.predecessor=message;
  }

    /**
       This method adds the xmi reference to the MagicDraw xmi extensions.
       @param id the identifier of the extensions
     **/
  public void addMagicDrawExtensionReference(String id){
    /**
      <XMI.extension xmi.extender = 'MagicDraw UML 3.6' xmi.extenderID = 'MagicDraw UML 3.6' >
        <mainDiagram xmi.idref = 'ID00000000000e' />
      </XMI.extension>
    **/
    Element elem=doc.getDocument().createElement("XMI.extension");
    elem.setAttribute("xmi.extender","MagicDraw UML 3.6");
    elem.setAttribute("xmi.extenderID","MagicDraw UML 3.6");
    Element elem2=doc.getDocument().createElement("mainDiagram");
    elem2.setAttribute("xmi.idref",id);
    elem.appendChild(elem2);
    this.me.insertBefore(elem,this.roleParent);
  }

}
