package corbaTrace.xmi;

import java.io.*;
import java.util.*;

import javax.xml.parsers.*;


import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;


import org.xml.sax.*;

import org.w3c.dom.*;

/**
This class reprensents the Xmi (xml) document we want to create. It creates the base structure of the DOM tree.
@author Florian Champalle
 **/

public class XmiDocument{
    /** the DOM document!**/
  private Document document;
    /** DOM element where the models must be added**/
  private Element modelParent;
    /**the next unique XMI identifier to create. This is a sequence.**/
  private  int id;
    /** the model contained in this document (we only manage one model in this version**/
  private XmiModel model;
    /** the root element of the DOM tree **/
  private Element xmiRoot;
    /** the docType string**/
  private String docType;
    /** dtd elements not specified in the uml.dtd. Concerns the rational rose extensions**/
  private String dtdExtension;

    /** the constructor of the document. It creates a DOM Document and calls the init method **/
  public XmiDocument(){
    this.id=1;

    //creation of the DOM document
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder;
    try{
      builder= factory.newDocumentBuilder();

      this.document = builder.newDocument();

      //call the initDocument function to build the squeleton of the xmi file
      initDocument();
    }
    catch(ParserConfigurationException pce){
      // Parser with specified options can't be built
      pce.printStackTrace();
    }
  }

    /**get accessor for the id of the document **/
  public String getUniqueId(){
    String id="ID" + this.id++;
    return id;
  }

    /** get the DOM document**/
    public Document getDocument(){
	return this.document;
    }

    /**
       this method writes the DOM structure to the specified file.
       @param filename the name of the file
     **/
  public void writeToFile(String filename){

      try{
	  TransformerFactory tFactory =  TransformerFactory.newInstance();
	  Transformer transformer = tFactory.newTransformer();

	  transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, this.docType);
	  transformer.setOutputProperty(OutputKeys.INDENT, "yes");

	  DOMSource source = new DOMSource(document);
	  StreamResult result = new StreamResult(filename);
	  transformer.transform(source, result);

	  //Work around to add the dtdExtension string to the docType declaration
	  RandomAccessFile raf=new RandomAccessFile(filename,"rw");
	  raf.seek(71);
	  byte[] tab=new byte[new Long(raf.length()).intValue()-71];
	  raf.read(tab);
	  raf.seek(71);
	  raf.writeBytes(this.dtdExtension);
	  raf.write(tab);
      }
      catch(TransformerException te){
	  te.printStackTrace();
      }
      catch(IOException ioe){
	  ioe.printStackTrace();
      }

  }

    /**
       this method creates the DOM element representing the document.
     **/
  private void initDocument(){

    /**construction du squelette XMI
    <?xml version = '1.0' encoding = 'UTF-8' ?>
    <!DOCTYPE XMI SYSTEM 'uml13.dtd' [
    //this is for the extensions for Rational Rose
    <!ELEMENT uisToolName (#PCDATA)>
    <!ELEMENT uisDiagramName (#PCDATA)>
    <!ELEMENT uisDiagramStyle (#PCDATA)>
    <!ELEMENT uisDiagramPresentation (Foundation.Auxiliary_Elements.Presentation*)>
    <!ELEMENT UISDiagram (uisDiagramName, uisToolName, uisDiagramStyle, uisDiagramPresentation*)>
    <!ATTLIST UISDiagram xmi.id ID #REQUIRED>
    <!ELEMENT uisOwnedDiagram (UISDiagram*)>
    <!ELEMENT UISModelElement (uisOwnedDiagram*)>
    <!ATTLIST UISModelElement xmi.id ID #REQUIRED>
    <!ENTITY bs "&#38;#08;">
    <!ENTITY vt "&#38;#11;">
    <!ENTITY ff "&#38;#12;">
    ]>
    //end for extensions
    <XMI xmi.version = '1.0'>
      <XMI.header>
        <XMI.documentation>
          <XMI.exporter>Unisys.IntegratePlus.2</XMI.exporter>
          <XMI.exporterVersion>4.0.3</XMI.exporterVersion>
        </XMI.documentation>
        <XMI.metamodel xmi.name = 'UML' xmi.version = '1.1'/>
      </XMI.header>
      <XMI.content>

      //addModel ici

      </XMI.content>
    </XMI>
    **/

      this.docType ="uml13.dtd";
      this.dtdExtension=" [\n<!ELEMENT uisToolName (#PCDATA)>\n" +
    "<!ELEMENT uisDiagramName (#PCDATA)>\n" +
    "<!ELEMENT uisDiagramStyle (#PCDATA)>\n" +
    "<!ELEMENT uisDiagramPresentation (Foundation.Auxiliary_Elements.Presentation*)>\n" +
    "<!ELEMENT UISDiagram (uisDiagramName, uisToolName, uisDiagramStyle, uisDiagramPresentation*)>\n" +
    "<!ATTLIST UISDiagram xmi.id ID #REQUIRED>\n" +
    "<!ELEMENT uisOwnedDiagram (UISDiagram*)>\n" +
    "<!ELEMENT UISModelElement (uisOwnedDiagram*)>\n" +
    "<!ATTLIST UISModelElement xmi.id ID #REQUIRED>\n" +
    "<!ELEMENT Foundation.Auxiliary_Elements.Presentation (Foundation.Auxiliary_Elements.Presentation.geometry, Foundation.Auxiliary_Elements.Presentation.style, Foundation.Auxiliary_Elements.Presentation.model)>\n" +
    "<!ATTLIST Foundation.Auxiliary_Elements.Presentation xmi.id ID #REQUIRED>\n" +
    "<!ELEMENT Foundation.Auxiliary_Elements.Presentation.geometry (Foundation.Data_Types.Geometry)>\n" +
    "<!ELEMENT Foundation.Data_Types.Geometry (Foundation.Data_Types.Geometry.body)>\n" +
    "<!ELEMENT Foundation.Data_Types.Geometry.body (#PCDATA)>\n" +
    "<!ELEMENT Foundation.Auxiliary_Elements.Presentation.style (Foundation.Data_Types.GraphicMarker)>\n" +
    "<!ELEMENT Foundation.Data_Types.GraphicMarker (Foundation.Data_Types.GraphicMarker.body)>\n" +
    "<!ELEMENT Foundation.Data_Types.GraphicMarker.body (#PCDATA)>\n" +
    "<!ELEMENT Foundation.Auxiliary_Elements.Presentation.model (Behavioral_Elements.Collaborations.ClassifierRole)>\n" +
    "]";

    this.xmiRoot=this.document.createElement("XMI");
    this.xmiRoot.setAttribute("xmi.version","1.0");
    this.document.appendChild(this.xmiRoot);
    Element elem2=this.document.createElement("XMI.header");
    this.xmiRoot.appendChild(elem2);
    this.modelParent=this.document.createElement("XMI.content");
    this.xmiRoot.appendChild(this.modelParent);
    Element elem3=this.document.createElement("XMI.documentation");
    elem2.appendChild(elem3);
    Element elem4=this.document.createElement("XMI.exporter");
    //elem4.appendChild(this.document.createTextNode("Unisys.IntegratePlus.2"));
    elem4.appendChild(this.document.createTextNode("MagicDraw UML"));
    elem3.appendChild(elem4);
    elem4=this.document.createElement("XMI.exporterVersion");
    //elem4.appendChild(this.document.createTextNode("4.0.3"));
    elem4.appendChild(this.document.createTextNode("5.0"));
    elem3.appendChild(elem4);
    elem3=this.document.createElement("XMI.metamodel");
    elem3.setAttribute("xmi.name","UML");
    elem3.setAttribute("xmi.version","1.1");
    /*NOTE: the fucking XMI plugin for Rational Rose accepts
    ONLY version 1.1 of metamodel, even if they say the plugin
    now supports UML 1.3...*/
    elem2.appendChild(elem3);
    Comment com=this.document.createComment("because the f...ing XMI plugin for Rational Rose doesn't accept 1.3!");
    elem2.appendChild(com);
  }

    /**this method adds a model to the document. We only manage one model in this version(!)
      @param model the XmiModel to add
     **/
  public void addModel(XmiModel model){
    this.modelParent.appendChild (model.getElement());
    this.model=model; //we work only with one model in this version
  }

    /**
       this method adds the specific Xmi extensions for the Rational Rose tool.
     **/
  public void createRoseExtensions(){
    /**
    <XMI.extensions xmi.extender = 'Unisys.IntegratePlus.2'>
      <UISModelElement xmi.id = 'G.18'>
        <uisOwnedDiagram>
          <UISDiagram xmi.id = 'S.10009'>
            <uisDiagramName>Main</uisDiagramName>
            <uisToolName>Rational Rose 98</uisToolName>
            <uisDiagramStyle>ClassDiagram</uisDiagramStyle>
          </UISDiagram>
          <UISDiagram xmi.id = 'S.10010'>
            <uisDiagramName>DiagSeq1</uisDiagramName>
            <uisToolName>Rational Rose 98</uisToolName>
            <uisDiagramStyle>SequenceDiagram</uisDiagramStyle>
            <uisDiagramPresentation>

              <Foundation.Auxiliary_Elements.Presentation xmi.id='G.19'>
                <Foundation.Auxiliary_Elements.Presentation.geometry>
                  <Foundation.Data_Types.Geometry>
                    <Foundation.Data_Types.Geometry.body>
                       304, 224, 300, 118,
                    </Foundation.Data_Types.Geometry.body>
                  </Foundation.Data_Types.Geometry>
                </Foundation.Auxiliary_Elements.Presentation.geometry>
                <Foundation.Auxiliary_Elements.Presentation.style>
                  <Foundation.Data_Types.GraphicMarker>
                    <Foundation.Data_Types.GraphicMarker.body>
                      FillColor.Blue= 204,FillColor.Green= 255,FillColor.Red= 255,FillColor.Transparent=1,Font.Blue= 0,Font.Green= 0,Font.Red= 0,Font.FaceName=Arial,Font.Size= 10,Font.Bold=0,Font.Italic=0,Font.Strikethrough=0,Font.Underline=1,LineColor.Blue= 51,LineColor.Green= 0,LineColor.Red= 153,
                    </Foundation.Data_Types.GraphicMarker.body>
                  </Foundation.Data_Types.GraphicMarker>
                </Foundation.Auxiliary_Elements.Presentation.style>
                <Foundation.Auxiliary_Elements.Presentation.model>
                  <Behavioral_Elements.Collaborations.ClassifierRole xmi.idref = 'G.3'/> <!-- InstanceObjet1 -->
                </Foundation.Auxiliary_Elements.Presentation.model>
              </Foundation.Auxiliary_Elements.Presentation>

              <Foundation.Auxiliary_Elements.Presentation xmi.id='G.20'>
                <Foundation.Auxiliary_Elements.Presentation.geometry>
                  <Foundation.Data_Types.Geometry>
                    <Foundation.Data_Types.Geometry.body>
                       880, 224, 300, 118,
                    </Foundation.Data_Types.Geometry.body>
                  </Foundation.Data_Types.Geometry>
                </Foundation.Auxiliary_Elements.Presentation.geometry>
                <Foundation.Auxiliary_Elements.Presentation.style>
                  <Foundation.Data_Types.GraphicMarker>
                    <Foundation.Data_Types.GraphicMarker.body>
                      FillColor.Blue= 204,FillColor.Green= 255,FillColor.Red= 255,FillColor.Transparent=1,Font.Blue= 0,Font.Green= 0,Font.Red= 0,Font.FaceName=Arial,Font.Size= 10,Font.Bold=0,Font.Italic=0,Font.Strikethrough=0,Font.Underline=1,LineColor.Blue= 51,LineColor.Green= 0,LineColor.Red= 153,
                    </Foundation.Data_Types.GraphicMarker.body>
                  </Foundation.Data_Types.GraphicMarker>
                </Foundation.Auxiliary_Elements.Presentation.style>
                <Foundation.Auxiliary_Elements.Presentation.model>
                  <Behavioral_Elements.Collaborations.ClassifierRole xmi.idref = 'G.5'/> <!-- InstanceObjet2 -->
                </Foundation.Auxiliary_Elements.Presentation.model>
              </Foundation.Auxiliary_Elements.Presentation>

              <Foundation.Auxiliary_Elements.Presentation xmi.id='G.21'>
                <Foundation.Auxiliary_Elements.Presentation.geometry>
                  <Foundation.Data_Types.Geometry>
                    <Foundation.Data_Types.Geometry.body>
                       1344, 224, 300, 118,
                    </Foundation.Data_Types.Geometry.body>
                  </Foundation.Data_Types.Geometry>
                </Foundation.Auxiliary_Elements.Presentation.geometry>
                <Foundation.Auxiliary_Elements.Presentation.style>
                  <Foundation.Data_Types.GraphicMarker>
                    <Foundation.Data_Types.GraphicMarker.body>
                      FillColor.Blue= 204,FillColor.Green= 255,FillColor.Red= 255,FillColor.Transparent=1,Font.Blue= 0,Font.Green= 0,Font.Red= 0,Font.FaceName=Arial,Font.Size= 10,Font.Bold=0,Font.Italic=0,Font.Strikethrough=0,Font.Underline=1,LineColor.Blue= 51,LineColor.Green= 0,LineColor.Red= 153,
                    </Foundation.Data_Types.GraphicMarker.body>
                  </Foundation.Data_Types.GraphicMarker>
                </Foundation.Auxiliary_Elements.Presentation.style>
                <Foundation.Auxiliary_Elements.Presentation.model>
                  <Behavioral_Elements.Collaborations.ClassifierRole xmi.idref = 'G.7'/> <!-- InstanceObjet3 -->
                </Foundation.Auxiliary_Elements.Presentation.model>
              </Foundation.Auxiliary_Elements.Presentation>


              <Foundation.Auxiliary_Elements.Presentation xmi.id='G.22'>
                <Foundation.Auxiliary_Elements.Presentation.geometry>
                  <Foundation.Data_Types.Geometry>
                    <Foundation.Data_Types.Geometry.body>
                       591, 340, 12, 52,
                    </Foundation.Data_Types.Geometry.body>
                  </Foundation.Data_Types.Geometry>
                </Foundation.Auxiliary_Elements.Presentation.geometry>
                <Foundation.Auxiliary_Elements.Presentation.style>
                  <Foundation.Data_Types.GraphicMarker>
                    <Foundation.Data_Types.GraphicMarker.body>
                      Message, SQN= 1,
                    </Foundation.Data_Types.GraphicMarker.body>
                  </Foundation.Data_Types.GraphicMarker>
                </Foundation.Auxiliary_Elements.Presentation.style>
                <Foundation.Auxiliary_Elements.Presentation.model>
                  <Behavioral_Elements.Collaborations.Message xmi.idref = 'G.9'/> <!-- operation1( ) -->
                </Foundation.Auxiliary_Elements.Presentation.model>
              </Foundation.Auxiliary_Elements.Presentation>
              <Foundation.Auxiliary_El  public String getUniqueSid(){
    String sid="S." + this.Sid++;
    return sid;
  }ements.Presentation xmi.id='G.23'>
                <Foundation.Auxiliary_Elements.Presentation.geometry>
                  <Foundation.Data_Types.Geometry>
                    <Foundation.Data_Types.Geometry.body>
                       1111, 420, 12, 52,
                    </Foundation.Data_Types.Geometry.body>
                  </Foundation.Data_Types.Geometry>
                </Foundation.Auxiliary_Elements.Presentation.geometry>
                <Foundation.Auxiliary_Elements.Presentation.style>
                  <Foundation.Data_Types.GraphicMarker>
                    <Foundation.Data_Types.GraphicMarker.body>
                      Message, SQN= 2,
                    </Foundation.Data_Types.GraphicMarker.body>
                  </Foundation.Data_Types.GraphicMarker>
                </Foundation.Auxiliary_Elements.Presentation.style>
                <Foundation.Auxiliary_Elements.Presentation.model>
                  <Behavioral_Elements.Collaborations.Message xmi.idref = 'G.10'/> <!-- operation1( ) -->
                </Foundation.Auxiliary_Elements.Presentation.model>
              </Foundation.Auxiliary_Elements.Presentation>
              <Foundation.Auxiliary_Elements.Presentation xmi.id='G.24'>
                <Foundation.Auxiliary_Elements.Presentation.geometry>
                  <Foundation.Data_Types.Geometry>
                    <Foundation.Data_Types.Geometry.body>
                       824, 548, 12, 52,
                    </Foundation.Data_Types.Geometry.body>
                  </Foundation.Data_Types.Geometry>
                </Foundation.Auxiliary_Elements.Presentation.geometry>
                <Foundation.Auxiliary_Elements.Presentation.style>
                  <Foundation.Data_Types.GraphicMarker>
                    <Foundation.Data_Types.GraphicMarker.body>
                      Message, SQN= 3,
                    </Foundation.Data_Types.GraphicMarker.body>
                  </Foundation.Data_Types.GraphicMarker>
                </Foundation.Auxiliary_Elements.Presentation.style>
                <Foundation.Auxiliary_Elements.Presentation.model>
                  <Behavioral_Elements.Collaborations.Message xmi.idref = 'G.11'/> <!-- operation1(Boolean) -->
                </Foundation.Auxiliary_Elements.Presentation.model>
              </Foundation.Auxiliary_Elements.Presentation>

            </uisDiagramPresentation>
          </UISDiagram>
          <UISDiagram xmi.id = 'S.10011'>
            <uisDiagramName>Main</uisDiagramName>
            <uisToolName>Rational Rose 98</uisToolName>
            <uisDiagramStyle>ModuleDiagram</uisDiagramStyle>
          </UISDiagram>
        </uisOwnedDiagram>
      </UISModelElement>
    </XMI.extensions>
    **/

    Element elem=this.document.createElement("XMI.extensions");
    elem.setAttribute("xmi.extender","Unisys.IntegratePlus.2");
    Element elem2=this.document.createElement("UISModelElement");
    String gid=this.getUniqueId();
    //indicate this extension id to the model
    this.model.addExtensionReference(gid);
    elem2.setAttribute("xmi.id",gid);
    elem.appendChild(elem2);
    Element elem3=this.document.createElement("uisOwnedDiagram");
    elem2.appendChild(elem3);
    /**
    Element elem4=this.document.createElement("UISDiagram");
    elem4.setAttribute("xmi.id",this.getUniqueSid());
    elem3.appendChild(elem4);
    Element elem5=this.document.createElement("uisDiagramName");
    elem5.appendChild(this.document.createTextNode("Main"));
    elem4.appendChild(elem5);
    elem5=this.document.createElement("uisToolName");
    elem5.appendChild(this.document.createTextNode("Rational Rose 98"));
    elem4.appendChild(elem5);
    elem5=this.document.createElement("uisDiagramStyle");
    elem5.appendChild(this.document.createTextNode("ClassDiagram"));
    elem4.appendChild(elem5);
    **/
    Element elem4, elem5;
    elem4=this.document.createElement("UISDiagram");
    elem4.setAttribute("xmi.id",this.getUniqueId());
    elem3.appendChild(elem4);
    elem5=this.document.createElement("uisDiagramName");
    elem5.appendChild(this.document.createTextNode(this.model.getSeqDiag().getName())); //name of the sequence diagram
    elem4.appendChild(elem5);
    elem5=this.document.createElement("uisToolName");
    elem5.appendChild(this.document.createTextNode("Rational Rose 98"));
    elem4.appendChild(elem5);
    elem5=this.document.createElement("uisDiagramStyle");
    elem5.appendChild(this.document.createTextNode("SequenceDiagram"));
    elem4.appendChild(elem5);
    elem5=this.document.createElement("uisDiagramPresentation");
    elem4.appendChild(elem5);

    Element elem6, elem7, elem8, elem9;

    //for each ClassifierRole
    int position=300;
    XmiClassifierRole role;

    for(int i=0;i<this.model.getSeqDiag().getRoles().size();i++){
      role=(XmiClassifierRole)this.model.getSeqDiag().getRoles().elementAt(i);
      elem6=this.document.createElement("Foundation.Auxiliary_Elements.Presentation");
      elem6.setAttribute("xmi.id",this.getUniqueId());
      elem5.appendChild(elem6);
      elem7=this.document.createElement("Foundation.Auxiliary_Elements.Presentation.geometry");
      elem6.appendChild(elem7);
      elem8=this.document.createElement("Foundation.Data_Types.Geometry");
      elem7.appendChild(elem8);
      elem9=this.document.createElement("Foundation.Data_Types.Geometry.body");
      elem9.appendChild(this.document.createTextNode(position + ", 224, 300, 118,"));
      elem8.appendChild(elem9);
      position+=500;
      elem7=this.document.createElement("Foundation.Auxiliary_Elements.Presentation.style");
      elem6.appendChild(elem7);
    /**
       this method adds the specific Xmi extensions for the Rational Rose tool.
     **/
      elem8=this.document.createElement("Foundation.Data_Types.GraphicMarker");
      elem7.appendChild(elem8);
      elem9=this.document.createElement("Foundation.Data_Types.GraphicMarker.body");
      elem9.appendChild(this.document.createTextNode("FillColor.Blue= 204,FillColor.Green= 255,FillColor.Red= 255,FillColor.Transparent=1,Font.Blue= 0,Font.Green= 0,Font.Red= 0,Font.FaceName=Arial,Font.Size= 10,Font.Bold=0,Font.Italic=0,Font.Strikethrough=0,Font.Underline=1,LineColor.Blue= 51,LineColor.Green= 0,LineColor.Red= 153,"));
      elem8.appendChild(elem9);
      elem7=this.document.createElement("Foundation.Auxiliary_Elements.Presentation.model");
      elem6.appendChild(elem7);
      elem8=this.document.createElement("Behavioral_Elements.Collaborations.ClassifierRole");
      elem8.setAttribute("xmi.idref",role.getId());
      elem7.appendChild(elem8);
    }
    /**
    elem4=this.document.createElement("UISDiagram");
    elem4.setAttribute("xmi.id",this.getUniqueSid());
    elem3.appendChild(elem4);
    elem5=this.document.createElement("uisDiagramName");
    elem5.appendChild(this.document.createTextNode("Main"));
    elem4.appendChild(elem5);
    elem5=this.document.createElement("uisToolName");
    elem5.appendChild(this.document.createTextNode("Rational Rose 98"));
    elem4.appendChild(elem5);
    elem5=this.document.createElement("uisDiagramStyle");
    elem5.appendChild(this.document.createTextNode("ModuleDiagram"));
    elem4.appendChild(elem5);
    **/
    //add all this to the document
    this.xmiRoot.appendChild(elem);
  }

    /**
       this method adds the specific Xmi extensions for the MagicDraw UML  tool.
     **/
  public void createMagicDrawExtensions(){

      //key: messageID, value: activation id
      HashMap activations=new HashMap();

    Element elem=this.document.createElement("XMI.extensions");
      try{
    elem.setAttribute("xmi.extender","MagicDraw UML 3.6");
    Element elem2=this.document.createElement("mdOwnedDiagrams");
    elem.appendChild(elem2);
    Element elem3=this.document.createElement("mdElement");
    elem3.setAttribute("elementClass","InteractionDiagramData");
    String diagramData=this.getUniqueId();

    //add the reference of this extension to the sequence diagram
    this.model.getSeqDiag().addMagicDrawExtensionReference(diagramData);

    elem3.setAttribute("xmi.id",diagramData);
    elem2.appendChild(elem3);
    Element elem4=this.document.createElement("Foundation.Core.ModelElement.name");
    elem4.appendChild(this.document.createTextNode(this.model.getSeqDiag().getName()));
    elem3.appendChild(elem4);
    elem4=this.document.createElement("parentID");
    elem4.setAttribute("xmi.idref",this.model.getSeqDiag().getId()); //seqDiag Gid
    elem3.appendChild(elem4);
    elem4=this.document.createElement("type");
    elem4.appendChild(this.document.createTextNode("Sequence Diagram"));
    elem3.appendChild(elem4);
    elem4=this.document.createElement("mdElement");
    elem4.setAttribute("elementClass","DiagramView");
    String diagramViewID=this.getUniqueId();
    elem4.setAttribute("xmi.id",diagramViewID);
    elem3.appendChild(elem4);
    Element elem5=this.document.createElement("elementID");
    elem5.setAttribute("xmi.idref",diagramData);
    elem4.appendChild(elem5);
    elem5=this.document.createElement("zoomFactor");
    elem5.setAttribute("xmi.value","1.0");
    elem4.appendChild(elem5);
    elem5=this.document.createElement("mdOwnedViews");
    elem4.appendChild(elem5);

    //for each role
    long rolePosition;//=50;
    Element elem6, elem7, elem8, elem9, elem10, elem11, elem12, elem13, elem14;
    XmiClassifierRole role;
    XmiMessage message;

    for(int i=0;i<this.model.getSeqDiag().getRoles().size();i++){
        role=(XmiClassifierRole)this.model.getSeqDiag().getRoles().elementAt(i);
        elem6=this.document.createElement("mdElement");
        elem6.setAttribute("elementClass","SequenceObjectView");
        elem6.setAttribute("xmi.id",this.getUniqueId());
        elem5.appendChild(elem6);
        elem7=this.document.createElement("elementID");
        elem7.setAttribute("xmi.idref",role.getId()); //classifierRole id
        elem6.appendChild(elem7);
        elem7=this.document.createElement("geometry");
	rolePosition=50+this.model.getSeqDiag().getRoles().indexOf(role)*250;
        elem7.appendChild(this.document.createTextNode(rolePosition + ", 75, 140, 22"));
        elem6.appendChild(elem7);
        elem7=this.document.createElement("mdOwnedViews");
        elem6.appendChild(elem7);
        elem8=this.document.createElement("mdElement");
        elem8.setAttribute("elementClass","LifeLineView");
        elem8.setAttribute("xmi.id",this.getUniqueId());
        elem7.appendChild(elem8);
        elem9=this.document.createElement("elementID");
        elem9.setAttribute("xmi.idref",role.getId()); //classifierRole id
        elem8.appendChild(elem9);
        elem9=this.document.createElement("editable");
        elem9.setAttribute("xmi.value","false");
        elem8.appendChild(elem9);
        elem9=this.document.createElement("geometry");
	long lifePosition=rolePosition+70;
        elem9.appendChild(this.document.createTextNode(lifePosition + ", 97, 0, 410"));
        elem8.appendChild(elem9);
        elem9=this.document.createElement("mdOwnedViews");
        elem8.appendChild(elem9);

	//one activation
	String tempActivation=(String)activations.get(role.getId());
	String activation;
	if (tempActivation==null){
	    activation=this.getUniqueId();
	    activations.put(role.getId(),activation);
	}
	else{
	    activation=tempActivation;
	}

	//for each message
	for (int j=0;j<role.getReceivedMessages().size();j++) {
	    message=(XmiMessage)role.getReceivedMessages().elementAt(j);
	    elem11=this.document.createElement("mdElement");
	    elem11.setAttribute("elementClass","SeqMessageView");
	    elem11.setAttribute("xmi.id",this.getUniqueId());
	    elem9.appendChild(elem11);
	    elem12=this.document.createElement("elementID");
	    elem12.setAttribute("xmi.idref",message.getId());
	    elem11.appendChild(elem12);
	    elem12=this.document.createElement("linkFirstEndID");

	    elem12.setAttribute("xmi.idref",activation);
	    elem11.appendChild(elem12);
	    elem12=this.document.createElement("linkSecondEndID");
	    String tempTarget=(String)activations.get(message.getSender().getId());
	    String target;
	    
	    if (tempTarget==null){
			target=this.getUniqueId();
			activations.put(message.getSender().getId(),target);
	    } else {
			target=tempTarget;
	    }

	    elem12.setAttribute("xmi.idref",target);
	    elem11.appendChild(elem12);
	    elem12=this.document.createElement("geometry");
	    long idx=this.model.getSeqDiag().getMessages().indexOf(message);
	    long posMsg=130+idx*30;
	    long pos1=120+this.model.getSeqDiag().getRoles().indexOf(message.getSender())*250;
	    long pos2=120+this.model.getSeqDiag().getRoles().indexOf(message.getReceiver())*250;
	    elem12.appendChild(this.document.createTextNode(pos2 +", "+ posMsg + "; "+ pos1 + ", "+  posMsg + ";"));
	    elem11.appendChild(elem12);
	    elem12=this.document.createElement("linkNameID");
	    String linkNameID=this.getUniqueId(); //linkNameID
	    elem12.setAttribute("xmi.idref",linkNameID);
	    elem11.appendChild(elem12);
	    elem12=this.document.createElement("linkConstraintID");
	    String linkConstraintID=this.getUniqueId(); //linkConstraintID
	    elem12.setAttribute("xmi.idref",linkConstraintID);
	    elem11.appendChild(elem12);
	    elem12=this.document.createElement("nameVisible");
	    elem12.setAttribute("xmi.value","true");
	    elem11.appendChild(elem12);
	    elem12=this.document.createElement("mdOwnedViews");
	    elem11.appendChild(elem12);
	    elem13=this.document.createElement("mdElement");
	    elem13.setAttribute("elementClass","TextBoxView");
	    elem13.setAttribute("xmi.id",linkConstraintID);
	    elem12.appendChild(elem13);
	    elem14=this.document.createElement("editable");
	    elem14.setAttribute("xmi.value","false");
	    elem13.appendChild(elem14);
	    elem14=this.document.createElement("visible");
	    elem14.setAttribute("xmi.value","false");
	    elem13.appendChild(elem14);
	    elem14=this.document.createElement("geometry");
	    elem14.appendChild(this.document.createTextNode("341, 369, 26, 13"));
	    elem13.appendChild(elem14);

	    elem13=this.document.createElement("mdElement");
	    elem13.setAttribute("elementClass","OperationView");
	    elem13.setAttribute("xmi.id",linkNameID);
	    elem12.appendChild(elem13);
	    elem14=this.document.createElement("elementID");
	    elem14.setAttribute("xmi.idref",message.getId());
	    elem13.appendChild(elem14);
	    elem14=this.document.createElement("geometry");
	    posMsg-=15;
	    //calculate the text position from the roles position
	    long posTxt;
	    if (pos1>pos2) {
			posTxt=pos2+(pos1-pos2)/2;
	    } else {
			posTxt=pos1+(pos2-pos1)/2;
	    }
	    elem14.appendChild(this.document.createTextNode(posTxt + ", " + posMsg + ", 65, 13"));
	    elem13.appendChild(elem14);
	    elem14=this.document.createElement("text");
	    elem14.appendChild(this.document.createTextNode(message.getCallAction().getName()));
	    elem13.appendChild(elem14);
	}

	elem10=this.document.createElement("mdElement");
	elem10.setAttribute("elementClass","Activation");
	elem10.setAttribute("xmi.id",activation);
	elem9.appendChild(elem10);
	elem11=this.document.createElement("geometry");
	elem11.appendChild(this.document.createTextNode(lifePosition +", 130, 10, 1000")); //??????????????
        rolePosition+=250;
	elem10.appendChild(elem11);

        elem7=this.document.createElement("showActivations");
        elem7.setAttribute("xmi.value","true");
        elem6.appendChild(elem7);
    }

    elem2=this.document.createElement("mdOwnedWindows");
    elem.appendChild(elem2);
    elem3=this.document.createElement("mdElement");
    elem3.setAttribute("elementClass","SequenceDiagramWindow");
    elem2.appendChild(elem3);
    elem4=this.document.createElement("elementID");
    elem4.setAttribute("xmi.idref",diagramViewID);
    elem3.appendChild(elem4);
    elem4=this.document.createElement("geometry");
    elem4.appendChild(this.document.createTextNode("0, 0, 771, 594"));
    elem3.appendChild(elem4);
    elem4=this.document.createElement("maximized");
    elem4.setAttribute("xmi.value","true");
    elem3.appendChild(elem4);

    //add all this to the document
    this.xmiRoot.appendChild(elem);
      }
      catch(Exception e){
	  e.printStackTrace();
      }

      /*
      <XMI.extensions xmi.extender = 'MagicDraw UML 3.6' >
        <mdOwnedDiagrams >
          <mdElement elementClass = 'InteractionDiagramData' xmi.id = 'ID00000000000e' >
            <Foundation.Core.ModelElement.name >DiagSeq</Foundation.Core.ModelElement.name>
            <parentID xmi.idref = 'ID00000000000d' />
            <type >Sequence Diagram</type>
            <mdElement elementClass = 'DiagramView' xmi.id = 'ID0000000000ac' >
              <elementID xmi.idref = 'ID00000000000e' />
              <zoomFactor xmi.value = '1.0' />
              <mdOwnedViews >

                //roles here
                <mdElement elementClass = 'SequenceObjectView' xmi.id = 'ID0000000000ad' >
                  <elementID xmi.idref = 'ID00000000000f' />
                  <geometry>80, 75, 140, 22</geometry>
                  <mdOwnedViews>
                    <mdElement elementClass = 'LifeLineView' xmi.id = 'ID0000000000ae' >
                      <elementID xmi.idref = 'ID00000000000f' />
                      <editable xmi.value = 'false' />
                      <geometry >150, 97, 0, 410</geometry>
                      <mdOwnedViews >

                        //messages here
                        <mdElement elementClass = 'SeqMessageView' xmi.id = 'ID0000000000af' >
                          <elementID xmi.idref = 'ID00000000001f' />
                          <linkFirstEndID xmi.idref = 'ID0000000000b0' />
                          <linkSecondEndID xmi.idref = 'ID0000000000b1' />
                          <geometry >160, 337; 525, 337; </geometry>
                          <linkNameID xmi.idref = 'ID0000000000b2' />
                          <linkConstraintID xmi.idref = 'ID0000000000b3' />
                          <nameVisible xmi.value = 'true' />
                          <mdOwnedViews >
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000b3' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >341, 369, 26, 13</geometry>
                            </mdElement>
    <!--
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000b4' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >341, 350, 26, 13</geometry>
                            </mdElement>
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000b5' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >341, 363, 26, 13</geometry>
                            </mdElement>
    -->
                            <mdElement elementClass = 'OperationView' xmi.id = 'ID0000000000b2' >
                              <elementID xmi.idref = 'ID00000000001f' />
                              <geometry >310, 324, 65, 13</geometry>
                              <text>Action2</text>
                            </mdElement>
                          </mdOwnedViews>
    <!--
                          <linkStereotypeID xmi.idref = 'ID0000000000b4' />
                          <linkTaggedValuesID xmi.idref = 'ID0000000000b5' />
    -->
                        </mdElement>
                        <mdElement elementClass = 'Activation' xmi.id = 'ID0000000000b6' >
                          <geometry >150, 132, 10, 110</geometry>
                        </mdElement>




                        <mdElement elementClass = 'SeqMessageView' xmi.id = 'ID0000000000b7' >
                          <elementID xmi.idref = 'ID000000000018' />
                          <linkFirstEndID xmi.idref = 'ID0000000000b6' />
                          <linkSecondEndID xmi.idref = 'ID0000000000b8' />
                          <geometry >160, 172; 525, 172; </geometry>
                          <linkNameID xmi.idref = 'ID0000000000b9' />
                          <linkConstraintID xmi.idref = 'ID0000000000ba' />
                          <nameVisible xmi.value = 'true' />
                          <mdOwnedViews >
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000ba' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >339, 205, 26, 13</geometry>
                            </mdElement>
    <!--
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000bb' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >339, 185, 26, 13</geometry>
                            </mdElement>
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000bc' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >339, 198, 26, 13</geometry>
                            </mdElement>
    -->
                            <mdElement elementClass = 'OperationView' xmi.id = 'ID0000000000b9' >
                              <elementID xmi.idref = 'ID000000000018' />
                              <geometry >308, 160, 65, 13</geometry>
                              <text >Action2</text>
                            </mdElement>
                          </mdOwnedViews>
    <!--
                          <linkStereotypeID xmi.idref = 'ID0000000000bb' />
                          <linkTaggedValuesID xmi.idref = 'ID0000000000bc' />
    -->
                        </mdElement>
                        <mdElement elementClass = 'Activation' xmi.id = 'ID0000000000b0' >
                          <geometry >150, 295, 10, 112</geometry>
                        </mdElement>
                      </mdOwnedViews>
                    </mdElement>
                  </mdOwnedViews>
                  <showActivations xmi.value = 'true' /><!--set to false??-->
                </mdElement>


                <mdElement elementClass = 'SequenceObjectView' xmi.id = 'ID0000000000bd' >
                  <elementID xmi.idref = 'ID000000000013' />
                  <geometry >450, 75, 150, 22</geometry>
                  <mdOwnedViews >
                    <mdElement elementClass = 'LifeLineView' xmi.id = 'ID0000000000be' >
                      <elementID xmi.idref = 'ID000000000013' />
                      <editable xmi.value = 'false' />
                      <geometry >525, 97, 0, 410</geometry>
                      <mdOwnedViews >

                        <mdElement elementClass = 'SeqMessageView' xmi.id = 'ID0000000000bf' >
                          <elementID xmi.idref = 'ID000000000026' />
                          <linkFirstEndID xmi.idref = 'ID0000000000b1' />
                          <linkSecondEndID xmi.idref = 'ID0000000000b0' />
                          <geometry >525, 295; 160, 295; </geometry>
                          <linkNameID xmi.idref = 'ID0000000000c0' />
                          <linkConstraintID xmi.idref = 'ID0000000000c1' />
                          <nameVisible xmi.value = 'true' />
                          <mdOwnedViews >
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000c1' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >341, 327, 26, 13</geometry>
                            </mdElement>
    <!--
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000c2' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >341, 308, 26, 13</geometry>
                            </mdElement>
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000c3' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >341, 321, 26, 13</geometry>
                            </mdElement>
    -->
                            <mdElement elementClass = 'OperationView' xmi.id = 'ID0000000000c0' >
                              <elementID xmi.idref = 'ID000000000026' />
                              <geometry >310, 283, 65, 13</geometry>
                              <text >Action1</text>
                            </mdElement>
                          </mdOwnedViews>
    <!--
                          <linkStereotypeID xmi.idref = 'ID0000000000c2' />
                          <linkTaggedValuesID xmi.idref = 'ID0000000000c3' />
    -->
                        </mdElement>

                        <mdElement elementClass = 'SeqMessageView' xmi.id = 'ID0000000000c4' >
                          <elementID xmi.idref = 'ID00000000002d' />
                          <linkFirstEndID xmi.idref = 'ID0000000000b8' />
                          <linkSecondEndID xmi.idref = 'ID0000000000b6' />
                          <geometry >525, 132; 160, 132; </geometry>
                          <linkNameID xmi.idref = 'ID0000000000c5' />
                          <linkConstraintID xmi.idref = 'ID0000000000c6' />
                          <nameVisible xmi.value = 'true' />
                          <mdOwnedViews >
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000c6' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >341, 164, 26, 13</geometry>
                            </mdElement>
    <!--
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000c7' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >341, 145, 26, 13</geometry>
                            </mdElement>
                            <mdElement elementClass = 'TextBoxView' xmi.id = 'ID0000000000c8' >
                              <editable xmi.value = 'false' />
                              <visible xmi.value = 'false' />
                              <geometry >341, 158, 26, 13</geometry>
                            </mdElement>
    -->
                            <mdElement elementClass = 'OperationView' xmi.id = 'ID0000000000c5' >
                              <elementID xmi.idref = 'ID00000000002d' />
                              <geometry >310, 120, 65, 13</geometry>
                              <text >Action1</text>
                            </mdElement>
                          </mdOwnedViews>
    <!--
                          <linkStereotypeID xmi.idref = 'ID0000000000c7' />
                          <linkTaggedValuesID xmi.idref = 'ID0000000000c8' />
    -->
                        </mdElement>
                        <mdElement elementClass = 'Activation' xmi.id = 'ID0000000000b8' >
                          <geometry >525, 132, 10, 90</geometry>
                        </mdElement>
                        <mdElement elementClass = 'Activation' xmi.id = 'ID0000000000b1' >
                          <geometry >525, 295, 10, 92</geometry>
                        </mdElement>
                      </mdOwnedViews>
                    </mdElement>
                  </mdOwnedViews>
                  <showActivations xmi.value = 'true' /><!-- to false??-->
                </mdElement>
              </mdOwnedViews>
            </mdElement>
          </mdElement>
        </mdOwnedDiagrams>
        <mdOwnedWindows >
          <mdElement elementClass = 'SequenceDiagramWindow' >
            <elementID xmi.idref = 'ID0000000000ac' />
            <geometry >0, 0, 771, 594</geometry>
            <maximized xmi.value = 'true' />
          </mdElement>
        </mdOwnedWindows>
    <!--
        <options >
          <tipsStyle xmi.value = '0' />
          <docsStyle xmi.value = 'false' />
          <interfaceStyle xmi.value = '0' />
          <favoriteElements xmi.value = '' />
          <browserVisible xmi.value = 'true' />
          <browserBounds >1, 1, 233, 594</browserBounds>
        </options>
    -->
        <componentView xmi.idref = 'ID000000000002' />
        <dataTypes xmi.idref = 'ID000000000003' />
      </XMI.extensions>
       **/
  }

}
