package corbaTrace.xmi;

import org.w3c.dom.*;

/**
This class reprensents an Xmi Message. The message has a callAction, a sender Role and a receiver Role.
@author Florian Champalle
 **/
public class XmiMessage extends XmiElement{
    /**the DOM element where the successor and predecessor messages must be added  **/
  private Element afterPrecSuc;
    /**the sender role of the message**/
  private XmiClassifierRole sender;
    /** the receiver role of the message**/
  private XmiClassifierRole receiver;
    /**the callAction of the message **/
  private XmiCallAction callAction;

    /**
       This is the construtor of the class. It calls the init method.
       @param doc the document we are creating
       @param name the name of the message
       @param sender the sender role
       @param receiver the receiver role
       @param action the action of the message
       @param comments a table of strings that contains options of the message that are not stored in the XMI model. They will be stored as comments. The format has to be defined...
     **/
  public XmiMessage(XmiDocument doc, String name, XmiClassifierRole sender, XmiClassifierRole receiver, XmiCallAction action, String[] comments){
    this.doc=doc;
    this.name=name;
    this.sender=sender;
    this.receiver=receiver;
    this.callAction=action;
    initMessage();
  }

    /**
       get accessor of the callAction
     **/
  public XmiCallAction getCallAction(){
    return this.callAction;
  }

    /**
       get accessor of the sender
     **/
  public XmiClassifierRole getSender(){
    return this.sender;
  }

    /**
       get accessor of the receiver
     **/
  public XmiClassifierRole getReceiver(){
    return this.receiver;
  }

    /**
       This method creates the DOM element representing the message.
     **/
  private void initMessage(){
    /**
    <Behavioral_Elements.Collaborations.Message xmi.id = 'G.10'>
      <Foundation.Core.ModelElement.name>operation1( )</Foundation.Core.ModelElement.name>
      <Foundation.Core.ModelElement.visibility xmi.value = 'private'/>

        //setSuccessor ici

        //setPredecessor here

      <Behavioral_Elements.Collaborations.Message.action>
        <Behavioral_Elements.Common_Behavior.CallAction xmi.idref = 'G.16'/> <!-- operation1( ) -->
      </Behavioral_Elements.Collaborations.Message.action>
      <Behavioral_Elements.Collaborations.Message.receiver>
        <Behavioral_Elements.Collaborations.ClassifierRole xmi.idref = 'G.7'/> <!-- InstanceObjet3 -->
      </Behavioral_Elements.Collaborations.Message.receiver>
      <Behavioral_Elements.Collaborations.Message.sender>
        <Behavioral_Elements.Collaborations.ClassifierRole xmi.idref = 'G.5'/> <!-- InstanceObjet2 -->
      </Behavioral_Elements.Collaborations.Message.sender>
    </Behavioral_Elements.Collaborations.Message>
    **/

    this.me=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Message");
    this.id=doc.getUniqueId();
    this.me.setAttribute("xmi.id",this.id);
    Element elem=doc.getDocument().createElement("Foundation.Core.ModelElement.name");
    elem.appendChild(doc.getDocument().createTextNode(this.name));
    this.me.appendChild(elem);
    elem=doc.getDocument().createElement("Foundation.Core.ModelElement.visibility");
    elem.setAttribute("xmi.value","private");
    this.me.appendChild(elem);
    elem=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Message.sender");
    this.me.appendChild(elem);
    Element elem2=doc.getDocument().createElement("Behavioral_Elements.Collaborations.ClassifierRole");
    elem2.setAttribute("xmi.idref",this.sender.getId());
    elem.appendChild(elem2);
    elem=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Message.receiver");
    this.me.appendChild(elem);
    elem2=doc.getDocument().createElement("Behavioral_Elements.Collaborations.ClassifierRole");
    elem2.setAttribute("xmi.idref",this.receiver.getId());
    elem.appendChild(elem2);
    this.afterPrecSuc=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Message.action");
    this.me.appendChild(this.afterPrecSuc);
    elem=doc.getDocument().createElement("Behavioral_Elements.Common_Behavior.CallAction");
    elem.setAttribute("xmi.idref",callAction.getId());
    this.afterPrecSuc.appendChild(elem);


  }

    /**this is a set accessor for the successor message. It creates the DOM element and adds it to the message element.
       @param successor the XmiMessage that follows this one.
 **/
  public void setSuccessor(XmiMessage successor){
    /**
    <Behavioral_Elements.Collaborations.Message.message>
      <Behavioral_Elements.Collaborations.Message xmi.idref = 'G.11'/> <!-- operation1(Boolean) -->
    </Behavioral_Elements.Collaborations.Message.message>
    **/

      //does the "message" tag become message3 or message4 in the UML13.dtd??? haha! I don't know!
    Element elem=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Message.message3");
    Element elem2=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Message");
    elem2.setAttribute("xmi.idref",successor.getId());
    elem.appendChild(elem2);
    this.me.insertBefore(elem,this.afterPrecSuc);
    this.afterPrecSuc=elem;
  }

    /**
       this is a set accessor of the predecessor of this message.  It creates the DOM element and adds it to the message element.
       @param predecessor the XmiMessage that precedes this one
     **/
    public void setPredecessor(XmiMessage predecessor){
      /**
       <Behavioral_Elements.Collaborations.Message.predecessor>
        <Behavioral_Elements.Collaborations.Message xmi.idref = 'G.9'/> <!-- operation1( ) -->
      </Behavioral_Elements.Collaborations.Message.predecessor>
      **/

      Element elem,elem2;
      elem=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Message.predecessor");
      elem2=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Message");
      elem2.setAttribute("xmi.idref",predecessor.getId());
      elem.appendChild(elem2);
      this.me.insertBefore(elem,this.afterPrecSuc);
      this.afterPrecSuc=elem;
    }
}
