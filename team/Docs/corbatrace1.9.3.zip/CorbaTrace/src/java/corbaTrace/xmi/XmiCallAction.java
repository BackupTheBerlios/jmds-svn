package corbaTrace.xmi;

import org.w3c.dom.*;

/**
This class represents an Xmi CallAtion: an action called by a message. It references an operation of a class.
@author Florian Champalle
 **/
public class XmiCallAction extends XmiElement{

    /**the operation called by this action**/
  private XmiOperation operation;

    /**
       This is the constructor of the XmiCallAction. It calls the init method.
       @param doc the XmiDocument we are creating
       @param name the name of the callAction
       @param request the operation (of a class) referenced by this action
     **/
  public XmiCallAction(XmiDocument doc, String name, XmiOperation request){
    this.doc=doc;
    this.name=name;
    this.operation=request;
    initCallAction(request);
  }

    /**
       accessor of the operation
     **/
  public XmiOperation getOperation(){
    return this.operation;
  }

    /**
       this method create the DOM element for this action.
       @param name the name of the action
     **/
  private void initCallAction(XmiOperation request){
    /**
    <Behavioral_Elements.Common_Behavior.CallAction xmi.id = 'G.15'>
      <Foundation.Core.ModelElement.name>operation1( )</Foundation.Core.ModelElement.name>
      <Foundation.Core.ModelElement.visibility xmi.value = 'private'/>
      <Behavioral_Elements.Common_Behavior.Action.recurrence>
         <Foundation.Data_Types.Expression>
          <Foundation.Data_Types.Expression.language></Foundation.Data_Types.Expression.language>
          <Foundation.Data_Types.Expression.body></Foundation.Data_Types.Expression.body>
         </Foundation.Data_Types.Expression>
      </Behavioral_Elements.Common_Behavior.Action.recurrence>
      <Behavioral_Elements.Common_Behavior.Action.target>
         <Foundation.Data_Types.ObjectSetExpression>
          <Foundation.Data_Types.Expression.language></Foundation.Data_Types.Expression.language>
          <Foundation.Data_Types.Expression.body></Foundation.Data_Types.Expression.body>
         </Foundation.Data_Types.ObjectSetExpression>
      </Behavioral_Elements.Common_Behavior.Action.target>
      <Behavioral_Elements.Common_Behavior.Action.isAsynchronous xmi.value = 'true'/>
      <Behavioral_Elements.Common_Behavior.Action.script>
      </Behavioral_Elements.Common_Behavior.Action.script>
      <Behavioral_Elements.Common_Behavior.Action.request>
        <Foundation.Core.Operation xmi.idref = 'S.10002'/> <!-- operation1 -->
      </Behavioral_Elements.Common_Behavior.Action.request>
    </Behavioral_Elements.Common_Behavior.CallAction>
    **/

    this.me=doc.getDocument().createElement("Behavioral_Elements.Common_Behavior.CallAction"); //It was originally a CallAction in Unisys
    this.id=doc.getUniqueId();
    this.me.setAttribute("xmi.id",this.id);
    Element elem=doc.getDocument().createElement("Foundation.Core.ModelElement.name");
    this.me.appendChild(elem);
    elem.appendChild(doc.getDocument().createTextNode(name));
    elem=doc.getDocument().createElement("Foundation.Core.ModelElement.visibility");
    elem.setAttribute("xmi.value","private");
    this.me.appendChild(elem);
    /*elem=doc.getDocument().createElement("Behavioral_Elements.Common_Behavior.Action.recurrence");
    this.me.appendChild(elem);
    Element elem2=doc.getDocument().createElement("Foundation.Data_Types.Expression");
    elem.appendChild(elem2);
    Element elem3=doc.getDocument().createElement("Foundation.Data_Types.Expression.language");
    elem2.appendChild(elem3);
    elem3=doc.getDocument().createElement("Foundation.Data_Types.Expression.body");
    elem2.appendChild(elem3);
    */
    elem=doc.getDocument().createElement("Behavioral_Elements.Common_Behavior.Action.target");
    this.me.appendChild(elem);
    Element elem2=doc.getDocument().createElement("Foundation.Data_Types.ObjectSetExpression");
    elem.appendChild(elem2);
    Element elem3=doc.getDocument().createElement("Foundation.Data_Types.Expression.language");
    elem2.appendChild(elem3);
    elem3=doc.getDocument().createElement("Foundation.Data_Types.Expression.body");
    elem2.appendChild(elem3);
    elem=doc.getDocument().createElement("Behavioral_Elements.Common_Behavior.Action.isAsynchronous");
    elem.setAttribute("xmi.value","false");
    this.me.appendChild(elem);
    /*elem=doc.getDocument().createElement("Behavioral_Elements.Common_Behavior.Action.script");
    this.me.appendChild(elem);
    elem=doc.getDocument().createElement("Behavioral_Elements.Common_Behavior.CallAction.mode");
    elem.setAttribute("xmi.value","asynchronous");
    this.me.appendChild(elem);*/
    elem=doc.getDocument().createElement("Behavioral_Elements.Common_Behavior.CallAction.operation");
    this.me.appendChild(elem);
    elem2=doc.getDocument().createElement("Foundation.Core.Operation");
    elem2.setAttribute("xmi.idref",request.getId());
    elem.appendChild(elem2);
  }
}
