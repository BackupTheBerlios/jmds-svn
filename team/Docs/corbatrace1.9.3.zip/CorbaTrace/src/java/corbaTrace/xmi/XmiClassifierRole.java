package corbaTrace.xmi;

import org.w3c.dom.*;
import java.util.Vector;

/**
This class represents an XMI Classifier Role. This role has sent messages and received messages.
@author Florian Champalle
 **/

public class XmiClassifierRole extends XmiElement{
    /** the DOM element where the received messages must be appended **/
  private Element receivedParent;
    /** the DOM element where the sent messages must be appended **/
  private Element sentParent;
    /** a collection of all the received and sent messages in chronological order**/
  private Vector messages;
    /** a collection of all the received messages**/
  private Vector receivedMessages;

    /**
       the constructor of the class.
       @param doc the document we are creating
       @param name the name of the role. It calls the init method.
       @param type the type (class) of the role
     **/
  public XmiClassifierRole(XmiDocument doc, String name, XmiClass type){
    this.name=name;
    this.doc=doc;
    this.messages=new Vector();
    this.receivedMessages=new Vector();
    initClassifierRole(type);
  }

    /** get accessor for the messages collection**/
  public Vector getMessages(){
    return this.messages;
  }

    /** get accessor for the received messages collection**/
  public Vector getReceivedMessages(){
    return this.receivedMessages;
  }

    /**creates the DOM element representing the role.
       @param theClass the type of the role

     **/
  private void initClassifierRole(XmiClass theClass){
    /**
    <Behavioral_Elements.Collaborations.ClassifierRole xmi.id = 'G.5'>
      <Foundation.Core.ModelElement.name>InstanceObjet2</Foundation.Core.ModelElement.name>
      <Foundation.Core.ModelElement.visibility xmi.value = 'private'/>
      <Foundation.Core.GeneralizableElement.isRoot xmi.value = 'false'/>
      <Foundation.Core.GeneralizableElement.isLeaf xmi.value = 'false'/>
      <Foundation.Core.GeneralizableElement.isAbstract xmi.value = 'false'/>
      <Behavioral_Elements.Collaborations.ClassifierRole.multiplicity>1..1</Behavioral_Elements.Collaborations.ClassifierRole.multiplicity>
      <Behavioral_Elements.Collaborations.ClassifierRole.message2>

        //addReceivedMessage ici

      </Behavioral_Elements.Collaborations.ClassifierRole.message2>
      <Behavioral_Elements.Collaborations.ClassifierRole.message>

        //addSentMessage ici

      </Behavioral_Elements.Collaborations.ClassifierRole.message>

      <Behavioral_Elements.Collaborations.ClassifierRole.base>
        <Foundation.Core.Class xmi.idref = 'S.10001'/> <!-- Objet2 -->
      </Behavioral_Elements.Collaborations.ClassifierRole.base>

      <Behavioral_Elements.Collaborations.ClassifierRole.availableFeature>
        <Foundation.Core.Operation xmi.idref = 'S.10002'/> <!-- operation1 -->
      </Behavioral_Elements.Collaborations.ClassifierRole.availableFeature>

      <Foundation.Core.ModelElement.taggedValue>
        <Foundation.Extension_Mechanisms.TaggedValue>
          <Foundation.Extension_Mechanisms.TaggedValue.tag>persistence</Foundation.Extension_Mechanisms.TaggedValue.tag>
          <Foundation.Extension_Mechanisms.TaggedValue.value>transient</Foundation.Extension_Mechanisms.TaggedValue.value>
        </Foundation.Extension_Mechanisms.TaggedValue>
      </Foundation.Core.ModelElement.taggedValue>
    </Behavioral_Elements.Collaborations.ClassifierRole>
    **/

    this.me=doc.getDocument().createElement("Behavioral_Elements.Collaborations.ClassifierRole");
    this.id=doc.getUniqueId();
    this.me.setAttribute("xmi.id",this.id);
    Element elem2=doc.getDocument().createElement("Foundation.Core.ModelElement.name");
    elem2.appendChild(doc.getDocument().createTextNode(name));
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.ModelElement.visibility");
    elem2.setAttribute("xmi.value","public");
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isRoot");
    elem2.setAttribute("xmi.value","true");
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isLeaf");
    elem2.setAttribute("xmi.value","true");
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isAbstract");
    elem2.setAttribute("xmi.value","false");
    this.me.appendChild(elem2);
    /*elem2=doc.getDocument().createElement("Behavioral_Elements.Collaborations.ClassifierRole.multiplicity");
    elem2.appendChild(doc.getDocument().createTextNode("1..1"));
    this.me.appendChild(elem2);*/
    elem2=doc.getDocument().createElement("Behavioral_Elements.Collaborations.ClassifierRole.base");
    this.me.appendChild(elem2);
    Element elem3=doc.getDocument().createElement("Foundation.Core.Class");
    elem3.setAttribute("xmi.idref",theClass.getId()); //the id of the class
    elem2.appendChild(elem3);
    elem2=doc.getDocument().createElement("Behavioral_Elements.Collaborations.ClassifierRole.availableFeature");
    this.me.appendChild(elem2);

    //for each operation of the class
    XmiOperation op;
    for(int i=0;i<theClass.getOperations().size();i++){
      op=(XmiOperation)theClass.getOperations().elementAt(i);
      elem3=doc.getDocument().createElement("Foundation.Core.Operation");
      elem3.setAttribute("xmi.idref", op.getId());
      elem2.appendChild(elem3);
    }
    this.receivedParent=doc.getDocument().createElement("Behavioral_Elements.Collaborations.ClassifierRole.message2");
    this.me.appendChild(this.receivedParent);
    this.sentParent=doc.getDocument().createElement("Behavioral_Elements.Collaborations.ClassifierRole.message1");
    this.me.appendChild(this.sentParent);


    elem2=doc.getDocument().createElement("Foundation.Core.ModelElement.taggedValue");
    this.me.appendChild(elem2);
    elem3=doc.getDocument().createElement("Foundation.Extension_Mechanisms.TaggedValue");
    elem2.appendChild(elem3);
    Element elem4=doc.getDocument().createElement("Foundation.Extension_Mechanisms.TaggedValue.tag");
    elem4.appendChild(doc.getDocument().createTextNode("persistence"));
    elem3.appendChild(elem4);
    elem4=doc.getDocument().createElement("Foundation.Extension_Mechanisms.TaggedValue.value");
    elem4.appendChild(doc.getDocument().createTextNode("transient"));
    elem3.appendChild(elem4);
  }

    /**
       adds a sent message to this role
       @param message the message to add
     **/
  public void addSentMessage(XmiMessage message){
    /**
    <Behavioral_Elements.Collaborations.Message xmi.idref = 'G.9'/> <!-- operation1( ) -->
    **/
    Element elem=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Message");
    elem.setAttribute("xmi.idref",message.getId());
    this.sentParent.appendChild(elem);
    this.messages.addElement(message);
  }

    /**
       add a received message to this role
       @param message the received message to add
     **/
  public void addReceivedMessage(XmiMessage message){
    /**
    <Behavioral_Elements.Collaborations.Message xmi.idref = 'G.10'/> <!-- operation1( ) -->
    **/
    Element elem=doc.getDocument().createElement("Behavioral_Elements.Collaborations.Message");
    elem.setAttribute("xmi.idref",message.getId());
    this.receivedParent.appendChild(elem);
    this.messages.addElement(message);
    this.receivedMessages.addElement(message);
  }

}
