package corbaTrace.xmi;

import org.w3c.dom.*;
import java.util.HashMap;

/**
This class represents an XMI Model. A model has a sequence diagram, classes, callActions.
@author Florian Champalle
 **/
public class XmiModel extends XmiElement{
    /** the DOM node where the classes must be added**/
  private Element classParent;
    /** the sequence diagramm of the model. We only manage one diagram in this version.**/
  private XmiSequenceDiagram seqDiag;
    /** the DOM node where the datatypes must be added**/
    private Element datatypeParent;

    /**
       constructor of the class. It calls the init method.
       @param doc the document we are creating
       @param name the name of the model
     **/
  public XmiModel(XmiDocument doc, String name){
    this.doc=doc;
    this.name=name;
    initModel();
  }

    /**
       get accessor of the sequence diagram
     **/
  public XmiSequenceDiagram getSeqDiag(){
    return this.seqDiag;
  }

    /**
       This method create the DOM element representing the model.
     **/
  private void initModel(){
    /**
    <Model_Management.Model xmi.id = 'G.1'>
      <Foundation.Core.ModelElement.name>ExempleRose2</Foundation.Core.ModelElement.name>
      <Foundation.Core.ModelElement.visibility xmi.value = 'private'/>
      <Foundation.Core.GeneralizableElement.isRoot xmi.value = 'false'/>
      <Foundation.Core.GeneralizableElement.isLeaf xmi.value = 'false'/>
      <Foundation.Core.GeneralizableElement.isAbstract xmi.value = 'false'/>
      <XMI.extension xmi.extender = 'Unisys.IntegratePlus.2'>
        <XMI.reference xmi.idref = 'G.18'/>
      </XMI.extension>
      <Foundation.Core.Namespace.ownedElement>
        <Model_Management.Package xmi.id = 'ID000000000002' >
          <Foundation.Core.ModelElement.name >Data types</Foundation.Core.ModelElement.name>
	  <Foundation.Core.ModelElement.visibility xmi.value = 'public'/>
          <Foundation.Core.GeneralizableElement.isRoot xmi.value = 'false' />
          <Foundation.Core.GeneralizableElement.isLeaf xmi.value = 'false' />
          <Foundation.Core.GeneralizableElement.isAbstract xmi.value = 'false' />
	    <Foundation.Core.Namespace.ownedElement >
	    //add datatypes here
	    </Foundation.Core.Namespace.ownedElement >
        </Model_Management.Package>

      //addClass ici
      //addDatatypeEnumeration ici
      //addSequenceDiagram ici
      //addCallAction ici

      </Foundation.Core.Namespace.ownedElement>
    </Model_Management.Model>
    **/

    this.me=doc.getDocument().createElement("Model_Management.Model");
    this.id=doc.getUniqueId();
    this.me.setAttribute("xmi.id",this.id );
    Element elem2=doc.getDocument().createElement("Foundation.Core.ModelElement.name");
    elem2.appendChild(doc.getDocument().createTextNode(name));
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.ModelElement.visibility");
    elem2.setAttribute("xmi.value","private");
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isRoot");
    elem2.setAttribute("xmi.value","false");
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isLeaf");
    elem2.setAttribute("xmi.value","false");
    this.me.appendChild(elem2);
    elem2=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isAbstract");
    elem2.setAttribute("xmi.value","false");
    this.me.appendChild(elem2);
    this.classParent=doc.getDocument().createElement("Foundation.Core.Namespace.ownedElement");
    this.me.appendChild(this.classParent);
    Element elem3=doc.getDocument().createElement("Model_Management.Package");
    elem3.setAttribute("xmi.id",this.doc.getUniqueId());
    this.classParent.appendChild(elem3);
    Element elem4=doc.getDocument().createElement("Foundation.Core.ModelElement.name");
    elem4.appendChild(doc.getDocument().createTextNode("Data types"));
    elem3.appendChild(elem4);
    elem4=doc.getDocument().createElement("Foundation.Core.ModelElement.visibility");
    elem4.setAttribute("xmi.value","public");
    elem3.appendChild(elem4);
    elem4=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isRoot");
    elem4.setAttribute("xmi.value","false");
    elem3.appendChild(elem4);
    elem4=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isLeaf");
    elem4.setAttribute("xmi.value","false");
    elem3.appendChild(elem4);
    elem4=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isAbstract");
    elem4.setAttribute("xmi.value","false");
    elem3.appendChild(elem4);
    this.datatypeParent=doc.getDocument().createElement("Foundation.Core.Namespace.ownedElement");
    elem3.appendChild(this.datatypeParent);
  }

    /**
       This method adds a class to the model
       @param theClass the class to add
     **/
  public void addClass(XmiClass theClass){
    theClass.setNamespaceRef(this.id);
    this.classParent.insertBefore(theClass.getElement(), this.classParent.getFirstChild());
  }

    /**
       This method adds a datatype to the model
       @param datatype the datatype to add
     **/
  public void addDatatype(XmiDatatype datatype){
    this.datatypeParent.appendChild(datatype.getElement());
  }
    /**
       This method adds a sequence diagram to the model. We only manage one sequence diagram at this time.
       @param diagram the sequence diagram to add.
     **/
  public void addSequenceDiagram(XmiSequenceDiagram diagram){
    this.classParent.appendChild(diagram.getElement());
    this.seqDiag=diagram; //we work only with one diagram in this version
  }

    /**
       This method adds a callAction to the model.
       @param action the XmiCallAction to add.
     **/
  public void addCallAction(XmiCallAction action){
    this.classParent.appendChild(action.getElement());
  }

    /**
       adds a reference to the extension for the rational Rose tool.
       @param id the identifier of the extension
     **/
  public void addExtensionReference(String id){
    /**
    <XMI.extension xmi.extender = 'Unisys.IntegratePlus.2'>
      <XMI.reference xmi.idref = 'G.18'/>
    </XMI.extension>
    **/
    Element elem=doc.getDocument().createElement("XMI.extension");
    elem.setAttribute("xmi.extender","Unisys.IntegratePlus.2");
    elem.setAttribute("xmi.extenderID","???");
    Element elem2=doc.getDocument().createElement("XMI.reference");
    elem2.setAttribute("xmi.idref",id);
    elem.appendChild(elem2);
    this.me.insertBefore(elem,this.classParent);
  }

    /**
       adds a datatype enumeration to the model. NOT IMPLEMENTED YET!
     **/
  public void addDatatypeEnumeration(String name, String visibility, boolean isRoot, boolean isLeaf, boolean isAbstract, String[] Enumeration){
    //NOT USED YET

    //ceci s'ajoute au m�me niveau que les classes

    /**
    <Foundation.Data_Types.Enumeration xmi.id = 'G.13'>
      <Foundation.Core.ModelElement.name>Boolean</Foundation.Core.ModelElement.name>
      <Foundation.Core.ModelElement.visibility xmi.value = 'private'/>
      <Foundation.Core.GeneralizableElement.isRoot xmi.value = 'false'/>
      <Foundation.Core.GeneralizableElement.isLeaf xmi.value = 'false'/>
      <Foundation.Core.GeneralizableElement.isAbstract xmi.value = 'false'/>
      <Foundation.Data_Types.Enumeration.literal>
        <Foundation.Data_Types.EnumerationLiteral>
          <Foundation.Data_Types.EnumerationLiteral.name>
            false
          </Foundation.Data_Types.EnumerationLiteral.name>
        </Foundation.Data_Types.EnumerationLiteral>
        <Foundation.Data_Types.EnumerationLiteral>
          <Foundation.Data_Types.EnumerationLiteral.name>
            true
          </Foundation.Data_Types.EnumerationLiteral.name>
        </Foundation.Data_Types.EnumerationLiteral>
      </Foundation.Data_Types.Enumeration.literal>
    </Foundation.Data_Types.Enumeration>

    **/

  }
}
