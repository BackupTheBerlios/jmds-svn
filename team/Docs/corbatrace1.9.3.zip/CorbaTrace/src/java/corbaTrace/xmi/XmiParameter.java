package corbaTrace.xmi;

import org.w3c.dom.*;

/**
This class reprensents an Xmi parameter of an operation.
 **/

public class XmiParameter extends XmiElement{
    /**the type of the parameter (in, out, inout)**/
    private String inout;
    /** the type of the parameter(string, boolean..)**/
    private String type;
    /** the datatype of the parameter**/
    private XmiDatatype datatype;

    /** the constructor of the argument. Calls the init method.
	@param doc the document we are creating.
	@param name the name of the operation
	@param type the type of the argument (in, out, inout)
    **/
  public XmiParameter(XmiDocument doc, String name, String inout, XmiDatatype datatype){
    this.doc=doc;
    this.name=name;
    this.datatype=datatype;
    this.inout=inout;
    initParameter();
  }

    public String getInout(){
	return this.inout;
    }

    public String getType(){
	return this.type;
    }

    public XmiDatatype getDatatype(){
	return this.datatype;
    }

    /**
       This method creates the DOM element that represents the parameter.
     **/
  private void initParameter(){
    /**
        <Foundation.Core.Parameter xmi.id = 'G.12'>
          <Foundation.Core.ModelElement.name>arg1</Foundation.Core.ModelElement.name>
          <Foundation.Core.ModelElement.visibility xmi.value = 'private'/>
          <Foundation.Core.Parameter.defaultValue>
             <Foundation.Data_Types.Expression>
              <Foundation.Data_Types.Expression.language></Foundation.Data_Types.Expression.language>
              <Foundation.Data_Types.Expression.body></Foundation.Data_Types.Expression.body>
             </Foundation.Data_Types.Expression>
          </Foundation.Core.Parameter.defaultValue>
          <Foundation.Core.Parameter.kind xmi.value = 'inout'/>
          <Foundation.Core.Parameter.type>
            <Foundation.Core.DataType xmi.idref = 'G.13'/> <!-- Boolean -->
          </Foundation.Core.Parameter.type>
        </Foundation.Core.Parameter>
    **/

      this.me=doc.getDocument().createElement("Foundation.Core.Parameter");
      this.id=doc.getUniqueId();
      this.me.setAttribute("xmi.id",this.id);
      Element elem2=doc.getDocument().createElement("Foundation.Core.ModelElement.name");
      elem2.appendChild(doc.getDocument().createTextNode(this.name));
      this.me.appendChild(elem2);
      elem2=doc.getDocument().createElement("Foundation.Core.ModelElement.visibility");
      elem2.setAttribute("xmi.value","public");
      this.me.appendChild(elem2);
      elem2=doc.getDocument().createElement("Foundation.Core.Parameter.defaultValue");
      this.me.appendChild(elem2);    
      Element elem3=doc.getDocument().createElement("Foundation.Data_Types.Expression");
      elem2.appendChild(elem3);
      Element elem4=doc.getDocument().createElement("Foundation.Data_Types.Expression.language");
      elem3.appendChild(elem4);
      elem4=doc.getDocument().createElement("Foundation.Data_Types.Expression.body");
      elem3.appendChild(elem4);      
      elem2=doc.getDocument().createElement("Foundation.Core.Parameter.kind");
      elem2.setAttribute("xmi.value", this.inout);
      this.me.appendChild(elem2);
      elem2=doc.getDocument().createElement("Foundation.Core.Parameter.type");
      this.me.appendChild(elem2);
      elem3=doc.getDocument().createElement("Foundation.Core.DataType");
      elem3.setAttribute("xmi.idref",this.datatype.getId());
      elem2.appendChild(elem3);
  }
}
