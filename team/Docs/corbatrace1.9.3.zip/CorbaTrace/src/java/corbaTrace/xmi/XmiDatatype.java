package corbaTrace.xmi;

import org.w3c.dom.*;

/**
This class reprensents an Xmi datatype.
 **/

public class XmiDatatype extends XmiElement{
    /** the constructor of the datatype. Calls the init method.
	@param doc the document we are creating.
	@param name the name of the operation
    **/
  public XmiDatatype(XmiDocument doc, String name){
    this.doc=doc;
    this.name=name;
    initDatatype();
  }

    public boolean equals(XmiDatatype datatype){
	return this.name.equals(datatype.getName());
    }


    /**
       This method creates the DOM element that represents the datatype.
     **/
  private void initDatatype(){
      /**
	 <Foundation.Core.DataType xmi.id = 'ID000000000003' >
           <Foundation.Core.ModelElement.name >void</Foundation.Core.ModelElement.name>
	   <Foundation.Core.ModelElement.visibility xmi.value = 'public'/>
           <Foundation.Core.GeneralizableElement.isRoot xmi.value = 'false' />
           <Foundation.Core.GeneralizableElement.isLeaf xmi.value = 'false' />
           <Foundation.Core.GeneralizableElement.isAbstract xmi.value = 'false' />
         </Foundation.Core.DataType>
      **/
      this.me=doc.getDocument().createElement("Foundation.Core.DataType");
      this.id=doc.getUniqueId();
      this.me.setAttribute("xmi.id",this.id);
      Element elem4=doc.getDocument().createElement("Foundation.Core.ModelElement.name");
      elem4.appendChild(doc.getDocument().createTextNode(this.name));
      this.me.appendChild(elem4);
      elem4=doc.getDocument().createElement("Foundation.Core.ModelElement.visibility");
      elem4.setAttribute("xmi.value","public");
      this.me.appendChild(elem4); 
      elem4=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isRoot");
      elem4.setAttribute("xmi.value","false");
      this.me.appendChild(elem4); 
      elem4=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isLeaf");
      elem4.setAttribute("xmi.value","false");
      this.me.appendChild(elem4); 
      elem4=doc.getDocument().createElement("Foundation.Core.GeneralizableElement.isAbstract");
      elem4.setAttribute("xmi.value","false");
      this.me.appendChild(elem4); 
  }
}
