package corbaTrace.xmi;

import org.w3c.dom.*;
import java.util.Vector;

/**
This class reprensents an Xmi operation with its arguments.
 **/

public class XmiOperation extends XmiElement{
    /** the DOM node where the arguments have to be added**/
  private Element argumentParent;
    /**the collection of XmiParameters **/
    private Vector parameters;

    /** the constructor of the operation. Calls the init method.
	@param doc the document we are creating.
	@param name the name of the operation
    **/
  public XmiOperation(XmiDocument doc, String name){
    this.doc=doc;
    this.name=name;
    this.parameters=new Vector();
    initOperation();
  }

    public Vector getParameters(){
	return this.parameters;
    }

    public boolean equals(XmiOperation operation){
	boolean equal=true;
	if (!this.name.equals(operation.getName()))
	    equal=false;

	//if same number of parameters
	if (this.parameters.size()!=operation.getParameters().size())
	    equal=false;
	else{
	    //for each parameter
	    XmiParameter param, param2;
	    for (int i=0;i<this.parameters.size();i++){
		param=(XmiParameter)this.parameters.elementAt(i);
		param2=(XmiParameter)operation.getParameters().elementAt(i);
		if(!param.getType().equals(param.getType()))
		    equal=false;
		if(!param.getInout().equals(param.getInout()))
		    equal=false;
		if(!param.getDatatype().equals(param.getDatatype()))
		    equal=false;
	    }
	}
	return equal;
    }

    /**
       This method creates the DOM element that represents the operation.
     **/
  private void initOperation(){

    /**
    <Foundation.Core.Operation xmi.id = 'S.10002'>
      <Foundation.Core.ModelElement.name>operation1</Foundation.Core.ModelElement.name>
      <Foundation.Core.ModelElement.visibility xmi.value = 'public'/>
      <Foundation.Core.Feature.ownerScope xmi.value = 'instance'/>
      <Foundation.Core.BehavioralFeature.isQuery xmi.value = 'false'/>
      <Foundation.Core.Operation.specification></Foundation.Core.Operation.specification>
      <Foundation.Core.Operation.isPolymorphic xmi.value = 'false'/>
      <Foundation.Core.Operation.concurrency xmi.value = 'sequential'/>
      <Foundation.Core.BehavioralFeature.parameter>

        //addArgument ici

      </Foundation.Core.BehavioralFeature.parameter>
    </Foundation.Core.Operation>
    **/

    this.me=doc.getDocument().createElement("Foundation.Core.Operation");
    this.id=doc.getUniqueId();
    this.me.setAttribute("xmi.id",this.id);
    Element elem=doc.getDocument().createElement("Foundation.Core.ModelElement.name");
    elem.appendChild(doc.getDocument().createTextNode(name));
    this.me.appendChild(elem);
    elem=doc.getDocument().createElement("Foundation.Core.ModelElement.visibility");
    elem.setAttribute("xmi.value","public");
    this.me.appendChild(elem);
    elem=doc.getDocument().createElement("Foundation.Core.Feature.ownerScope");
    elem.setAttribute("xmi.value","instance");
    this.me.appendChild(elem);
    elem=doc.getDocument().createElement("Foundation.Core.BehavioralFeature.isQuery");
    elem.setAttribute("xmi.value","false");
    this.me.appendChild(elem);
    /*elem=doc.getDocument().createElement("Foundation.Core.Operation.specification");
    this.me.appendChild(elem);
    elem=doc.getDocument().createElement("Foundation.Core.Operation.isPolymorphic");
    elem.setAttribute("xmi.value","false");
    this.me.appendChild(elem);*/
    elem=doc.getDocument().createElement("Foundation.Core.Operation.concurrency");
    elem.setAttribute("xmi.value","sequential");
    this.me.appendChild(elem);
    this.argumentParent=doc.getDocument().createElement("Foundation.Core.BehavioralFeature.parameter");
    this.me.appendChild(this.argumentParent);
  }

    /**
       This method adds an argument to the operation.
       @param parameter the XMI parameter to add
     **/
  public void addArgument(XmiParameter parameter){
      this.argumentParent.appendChild(parameter.getElement());
      this.parameters.addElement(parameter);
  }

}
