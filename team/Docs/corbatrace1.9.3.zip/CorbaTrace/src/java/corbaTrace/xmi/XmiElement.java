package corbaTrace.xmi;

import org.w3c.dom.*;

/**
   this class holds the attributes that all Xmi* classes share (except XmlDocument). All these classes inherit from this abstract class.
@author Florian Champalle
 **/
public abstract class XmiElement{
    /**the DOM element that holds the structure of the XmiElement **/
  protected Element me;
    /**the XmiDocument we are creating. This is necessary to create the DOM elements and attributes **/
  protected XmiDocument  doc;
    /** the xmi unique identifier **/
  protected String id;
    /**the name of the Xmi element **/
  protected String name;

    /**
     get accessor of the name
     **/
  public String getName(){
      return this.name;
  }

    /**
     get accessor of the element
     **/
  public Element getElement(){
    return this.me;
  }

    /**
       get accessor of the xmi identifier
     **/
  public String getId(){
    return this.id;
  }

}
