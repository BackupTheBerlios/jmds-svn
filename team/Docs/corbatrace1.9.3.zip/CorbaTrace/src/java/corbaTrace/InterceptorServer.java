/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace;

import org.omg.PortableServer.POA;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import org.omg.CORBA.Policy;
import org.omg.CORBA.Any;
import java.util.Properties;

import corbaTrace.hello.Hello_impl;
import corbaTrace.interceptorCore.*;

/**
 * This class is use for a Corba server software to enable interceptors.<br/>
 * You just have to instanciate this class and to register your server objects.<br/>
 * Your objects are grouped in a component (a component is one POA). It's easier for you to just identifier a set of object as a component. So CorbaTrace will just keep communication beetween components.<br/>
 * Log are store in a file name (for a component name Titi) : Titi_Strace.xml
 * @author Etienne Juliot
 * @author Audrey Jaccard
 * @version 0.1
 */

public class InterceptorServer extends Interceptor {

	public InterceptorServer() {
		init();
	}

	/**
	 * Create a new POA which come from an other POA, and with a logging level
	 * @param orb The orb (already inited)
	 * @param poa Your POA with your policy (it can be the rootPOA)
	 * @param new_poa_name Name of the POA
	 * @param lglvl The log level (>=0 and <=5)
	 * @return The new POA just created
	 */
	public static POA create_poa(
		ORB orb,
		POA poa,
		String new_poa_name,
		int lglvl) {

		Policy[] policies = getInterceptorPolicy(orb, lglvl);
		POA poaInter = null;

		try {
			poaInter =
				poa.create_POA(new_poa_name, poa.the_POAManager(), policies);
		} catch (org.omg.PortableServer.POAPackage.AdapterAlreadyExists e) {
			e.printStackTrace();
			System.exit(1);
		} catch (org.omg.PortableServer.POAPackage.InvalidPolicy e) {
			e.printStackTrace();
			System.exit(1);
		}
		return poaInter;
	}

	/**
	 * Create a new POA which come from an other POA, and switch on interception
	 * @param orb The orb (already inited)
	 * @param poa Your POA with your policy (it can be the rootPOA)
	 * @param new_poa_name Name of the POA
	 * @return The new POA just created
	 */

	public static POA create_poa(ORB orb, POA poa, String new_poa_name) {
		return create_poa(orb, poa, new_poa_name, 1);
	}

	/** 
	 * Activate an object on a POA
	 * @param poa POA to activate
	 * @param ref Implementation of an object
	 * @param object_id Name of the object
	 * @return The object activated
	 */
	public static Object activate_object(POA poa, org.omg.PortableServer.Servant ref, String object_id)
		throws org.omg.CORBA.UserException {

		// Explicit object activation on a given POA (Logger Policy or not)
		// with a USER ID
		//
		byte[] id = object_id.getBytes();
		poa.activate_object_with_id(id, ref);

		org.omg.CORBA.Object obj = null;
		try {
			obj = poa.create_reference_with_id(id, "IDL:" + object_id + ":1.0");
		} catch (org.omg.CORBA.BAD_PARAM ex) {
			throw new RuntimeException();
		}
		activate_POA(poa);
		return obj;
	}

	/**
	 * Activate a POA
	 * @param poa The POA
	 */

	public static void activate_POA(POA poa) {
		try {
			poa.the_POAManager().activate();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit(1);
		}
	}

	/**
	 * Resolve the strategy of interception
	 * @param orb The ORB
	 * @param lglvl The log level
	 * @return Policy[]
	 */

	private static Policy[] getInterceptorPolicy(ORB orb, int lglvl) {
		try {
			Any any = orb.create_any();
			Policy[] policies = new Policy[6];

			org.omg.PortableServer.LifespanPolicyValueHelper.insert(
				any,
				org.omg.PortableServer.LifespanPolicyValue.PERSISTENT);
			policies[0] =
				orb.create_policy(
					org.omg.PortableServer.LIFESPAN_POLICY_ID.value,
					any);

			org.omg.PortableServer.IdAssignmentPolicyValueHelper.insert(
				any,
				org.omg.PortableServer.IdAssignmentPolicyValue.USER_ID);
			policies[1] =
				orb.create_policy(
					org.omg.PortableServer.ID_ASSIGNMENT_POLICY_ID.value,
					any);

			org.omg.PortableServer.RequestProcessingPolicyValueHelper.insert(
				any,
				org
					.omg
					.PortableServer
					.RequestProcessingPolicyValue
					.USE_SERVANT_MANAGER);
			policies[2] =
				orb.create_policy(
					org.omg.PortableServer.REQUEST_PROCESSING_POLICY_ID.value,
					any);

			org.omg.PortableServer.ServantRetentionPolicyValueHelper.insert(
				any,
				org.omg.PortableServer.ServantRetentionPolicyValue.RETAIN);
			policies[3] =
				orb.create_policy(
					org.omg.PortableServer.SERVANT_RETENTION_POLICY_ID.value,
					any);

			org.omg.PortableServer.ImplicitActivationPolicyValueHelper.insert(
				any,
				org
					.omg
					.PortableServer
					.ImplicitActivationPolicyValue
					.NO_IMPLICIT_ACTIVATION);
			policies[4] =
				orb.create_policy(
					org.omg.PortableServer.IMPLICIT_ACTIVATION_POLICY_ID.value,
					any);

			any.insert_short((short) lglvl);
			policies[5] = orb.create_policy(LOGGER_POLICY_ID.value, any);

			return policies;
		} catch (org.omg.CORBA.UserException e) {
			e.printStackTrace();
			System.exit(1);
			return null;
		}
	}

}
