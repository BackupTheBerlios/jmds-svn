/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace;

import org.omg.PortableServer.POA;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Policy;
import org.omg.CORBA.Any;
import java.util.Properties;

import corbaTrace.interceptorCore.*;

/**
 * This class is use for a Corba client software to enable interceptors.<br/>
 * You just have to instanciate this class and to register your clients objects.<br/>
 * Your objects are grouped in a component (a component is one ORB). It's easier for you to just identifier a set of object as a component. So CorbaTrace will just keep communication beetween components.
 * Log are store in a file name (for a component name Titi) : Titi_Ctrace.xml
 * @author Etienne Juliot
 * @author Audrey Jaccard
 * @version 0.1
 */

public class InterceptorClient extends Interceptor {

	public InterceptorClient() {
		init();
	}

	/**
	 * Change level of interception for an client object
	 * @param obj The object concerned by the change
	 * @param orb The orb (already inited)
	 * @param lglvl The log level (>=0 and <=5)
	 */
	public static org.omg.CORBA.Object change_level_interception(
		org.omg.CORBA.Object obj,
		ORB orb,
		int lglvl) {
		// Set the logging policy on the given obj according to the given logging level
		try {
			org.omg.CORBA.Any any = orb.create_any();
			any.insert_short((short) lglvl);
			org.omg.CORBA.Policy[] policies = new org.omg.CORBA.Policy[1];
			policies[0] = orb.create_policy(LOGGER_POLICY_ID.value, any);
			obj = obj._set_policy_override(policies, org.omg.CORBA.SetOverrideType.ADD_OVERRIDE);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit(1);
		}
		return obj;
	}

	/**
	 * Active interception for an client object
	 * @param obj The object concerned by the interception
	 * @param orb The orb (already inited)
	 */

	public static org.omg.CORBA.Object active_interception(
		org.omg.CORBA.Object obj,
		ORB orb) {
		return change_level_interception(obj, orb, 1);
	}

	/**
	 * Desactive interception for an client object
	 * @param obj The object concerned by the interception
	 * @param orb The orb (already inited)
	 */

	public static org.omg.CORBA.Object desactive_interception(
		org.omg.CORBA.Object obj,
		ORB orb) {
		return change_level_interception(obj, orb, 0);
	}

	/**
	 * Active logging interception for an ORB
	 * @param orb The orb (already inited)
	 * @param obj loggerName file used by the logger
	 */

	public static void activate_log(String loggerName, ORB orb) {

		org.omg.PortableInterceptor.Current pic;
		org.omg.CORBA.Object objPic;
		try {
			objPic = orb.resolve_initial_references("PICurrent");
			pic = org.omg.PortableInterceptor.CurrentHelper.narrow(objPic);

			Any anyPic = orb.create_any();
			Dataflow flow = new Dataflow();
			flow.client_id = loggerName;
			DataflowHelper.insert(anyPic, flow);

			pic.set_slot(
				corbaTrace.interceptorCore.RequestInterceptorLogger.slotId,
				anyPic);
		} catch (org.omg.CORBA.ORBPackage.InvalidName ex) {
			throw new RuntimeException();
		} catch (org.omg.PortableInterceptor.InvalidSlot ex) {
		} catch (org.omg.CORBA.BAD_PARAM ex) {
		}
	}

}
