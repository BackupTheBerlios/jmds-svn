/**
 * This file is a part of the project : CorbaTrace
 * It's under LGPL licence.
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 * @author Sebastien Helbert
 * @version 1.0
 */
package corbaTrace.log2sequenceDiagram.parser;

import java.util.*;
import java.io.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.*;

import corbaTrace.log2sequenceDiagram.message.*; // for manipulating temporarily incomplete messages

/**
 * It's our handler for use with SAX parsing.
 * It is also responsible for manipulating temporarily incomplete messages read from logs.
 */
public class LogsHandler extends DefaultHandler {

    /* messages lists */
    private MessageCollection corbaSrcMsg;
    private MessageCollection corbaDestMsg;
    private MessageCollection localMsg;

    private Message currentMsg;
    private String currentElement; // to know in what level of tag we are

    private LinkedList optionsListTmp1, optionsListTmp2;
    private MessageOption optionTmp1, optionTmp2;

    private boolean validatedXML;
    // indicates wether it throws an exception everytime the XML file is not validated with its DTD.
    // if false, ignore such errors.

    // constructor
    public LogsHandler(boolean validatedXML) {
        super();
        this.validatedXML = validatedXML;
        localMsg = new MessageCollection();
        corbaSrcMsg = new MessageCollection();
        corbaDestMsg = new MessageCollection();
        destroyCurrentMessage();
    }

    public int getNbLocalMessages() {
        return localMsg.getNbMessages();
    }
    
    public int getNbIncompleteSourceMessages() {
        return corbaSrcMsg.getNbMessages();
    }

    public int getNbIncompleteDestinationMessages() {
        return corbaDestMsg.getNbMessages();
    }

    //===========================================================
    // SAX DocumentHandler methods
    //===========================================================

    /** executed when a open tag has been detected. */
    public void startElement(String namespaceURI, String lName, String qName, Attributes attrs) throws SAXException {

        String eName = lName; // element name
        if (eName.equals("")) {
            eName = qName; // namespaceAware = false
        }
        String aName = null;

        if (eName.equalsIgnoreCase("MESSAGE")) {
            currentElement = "MESSAGE";

            // we create the right HalfMessage (source or destination)
            // ONLY when we know what type of message it is.
            // while we don't know, we keep temporary infos (IDs) in temp variables.
            String IDtmp = null, requestIDtmp = null, typeTmp = null;

            if (attrs != null) {
                for (int i = 0; i < attrs.getLength(); i++) {
                    aName = attrs.getLocalName(i); // Attr name 
                    if (aName.equals(""))
                        aName = attrs.getQName(i);

                    if (aName.equalsIgnoreCase("MESG_ID")) {
                        IDtmp = attrs.getValue(i);
                    } else if (aName.equalsIgnoreCase("REQUEST_ID")) {
                        requestIDtmp = attrs.getValue(i);
                    } else if (aName.equalsIgnoreCase("TYPE")) {
                        typeTmp = MessageType.giveMessageType(attrs.getValue(i));
                    }
                }

                // we set the boolean saying it's a source or destination
                // AND create the right half-message.
                if(MessageType.isLocalType(typeTmp))  {
                	currentMsg = new LocalMessage();
                } else if(MessageType.isDestinationType(typeTmp))  {
                    currentMsg = new HalfMessageDestination();
                } else {
                    currentMsg = new HalfMessageSource();
                }

                // we complete the new message with temporally variables
                currentMsg.setMessageType(typeTmp);
                currentMsg.setMessageId(IDtmp);
                currentMsg.setRequestId(requestIDtmp);
			}

            if ((currentMsg.getMessageType() == MessageType.NONE) || (currentMsg.getMessageId() == null)) {
                currentMsg = null; // something was getting wrong (bad attributes)
            }

            return;
        }


        // if it's a wrong element name.	
        if (currentMsg == null) {			
            return;
        }

        if (eName.equalsIgnoreCase("LOCAL_OBJECT")) {
            currentElement = "LOCAL_OBJECT";
            for (int i = 0; i < attrs.getLength(); i++) {
                aName = attrs.getLocalName(i); // Attr name 
                if (aName.equals(""))
                    aName = attrs.getQName(i);
                if (aName.equalsIgnoreCase("ID")) {
                    if (currentMsg.isDestination()) {
                        currentMsg.setDestinationObjectId(attrs.getValue(i));
                    } else {
                        currentMsg.setSourceObjectId(attrs.getValue(i));
                    }
                } else if (aName.equalsIgnoreCase("DATE")) {
                    if (currentMsg.isDestination())
                        currentMsg.setReceivingMessageDate(attrs.getValue(i));
                    else
                        currentMsg.setSendingMessageDate(attrs.getValue(i));
                }
            }
            return;
        }

        if (eName.equalsIgnoreCase("DISTANT_OBJECT")) {
            currentElement = "DISTANT_OBJECT";
            if (currentMsg.isDestination()) {
                for (int i = 0; i < attrs.getLength(); i++) {
                    aName = attrs.getLocalName(i); // Attr name 
                    if (aName.equals(""))
                        aName = attrs.getQName(i);
                    if (aName.equalsIgnoreCase("ID")) {
                        currentMsg.setSourceObjectId(attrs.getValue(i));
                    } else if (aName.equalsIgnoreCase("DATE")) {
                        currentMsg.setSendingMessageDate(attrs.getValue(i));
                    }
                }
            } else if (currentMsg.isLocal() || currentMsg.getMessageType() == MessageType.SEND_REPLY) {
                // we KNOW the destination object (we reply to its request)
                for (int i = 0; i < attrs.getLength(); i++) {
                    aName = attrs.getLocalName(i); // Attr name 
                    if (aName.equals(""))
                        aName = attrs.getQName(i);
                    if (aName.equalsIgnoreCase("ID")) {
                        currentMsg.setDestinationObjectId(attrs.getValue(i));
                    } else if (aName.equalsIgnoreCase("DATE")) {
                        currentMsg.setReceivingMessageDate(attrs.getValue(i));
                        // !!!!!! approximative. Should be more than that
                    }
                }
                // else infos aren't useful
            }
            return;
        }

        if (eName.equalsIgnoreCase("OPTIONS")) {
            currentElement = "OPTIONS";
            // nothing special to do !  We will add options one by one in the message, that's all.
            return;
        }

        if (eName.equalsIgnoreCase("REQUEST_ID")) {
            currentElement = "REQUEST_ID";
            addOptiontoCurrentMessage("request_id", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("OPERATION")) {
            currentElement = "OPERATION";
            optionTmp1 = addOptiontoCurrentMessage("operation", attrs); // reference to the added MessageOption
            optionsListTmp1 = new LinkedList(); // arguments list for that option (its value)
            return;
        }

        if (eName.equalsIgnoreCase("ARGUMENT")) {
            if (currentElement.equals("OPERATION"))
                currentElement = "ARGUMENT";
            if (currentElement.equals("ARGUMENT"))
                optionsListTmp1.add(constructOptionMessage("argument", attrs)); // adds a new attribute for "Operation"
            // else nothing
            return;
        }

        if (eName.equalsIgnoreCase("EXCEPTIONS")) {
            currentElement = "EXCEPTIONS";
            optionTmp1 = addOptiontoCurrentMessage("exceptions", attrs); // reference to the added MessageOption
            optionsListTmp1 = new LinkedList(); // exceptions list for that option (its value)
            return;
        }

        if (eName.equalsIgnoreCase("EXCEPTION")) {
            if (currentElement.equals("EXCEPTIONS"))
                currentElement = "EXCEPTION";
            if (currentElement.equals("EXCEPTION"))
                optionsListTmp1.add(constructOptionMessage("exception", attrs));
            return;
        }

        if (eName.equalsIgnoreCase("CONTEXTS")) {
            currentElement = "CONTEXTS";
            optionTmp2 = addOptiontoCurrentMessage("contexts", attrs); // reference to the added MessageOption
            optionsListTmp2 = new LinkedList(); // contexts list for that option (its value)
            return;
        }

        if (eName.equalsIgnoreCase("CONTEXT")) {
            if (currentElement.equals("PROPERTY") || currentElement.equals("CONTEXTS"))
                currentElement = "CONTEXT";
            if (currentElement.equals("CONTEXT")) {
                optionTmp1 = new MessageOption("context");
                optionsListTmp2.add(optionTmp1); // contexts list for that option (its value)
                optionsListTmp1 = new LinkedList(); // properties list for that context option (its value)
            }
            return;
        }

        if (eName.equalsIgnoreCase("PROPERTY")) {
            if (currentElement.equals("CONTEXT"))
                currentElement = "PROPERTY";
            if (currentElement.equals("PROPERTY"))
                optionsListTmp1.add(constructOptionMessage("property", attrs));
            return;
        }

        if (eName.equalsIgnoreCase("OPERATION_CONTEXT")) {
            currentElement = "OPERATION_CONTEXT";
            optionTmp1 = addOptiontoCurrentMessage("operation_context", attrs); // reference to the added MessageOption
            optionsListTmp1 = new LinkedList(); // context properties list for that option (its value)
            return;
        }

        if (eName.equalsIgnoreCase("CONTEXT_PROPERTY")) {
            if (currentElement.equals("OPERATION_CONTEXT"))
                currentElement = "CONTEXT_PROPERTY";
            if (currentElement.equals("CONTEXT_PROPERTY"))
                optionsListTmp1.add(constructOptionMessage("context_property", attrs));
            return;
        }

        if (eName.equalsIgnoreCase("RESULT")) {
            currentElement = "RESULT";
            addOptiontoCurrentMessage("result", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("RESPONSE_EXPECTED")) {
            currentElement = "RESPONSE_EXPECTED";
            addOptiontoCurrentMessage("response_expected", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("SYNC_SCOPE")) {
            currentElement = "SYNC_SCOPE";
            addOptiontoCurrentMessage("sync_scope", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("REPLY_STATUS")) {
            currentElement = "REPLY_STATUS";
            addOptiontoCurrentMessage("reply_status", attrs);
        } else if (eName.equalsIgnoreCase("FORWARD_REFERENCE")) {
            currentElement = "FORWARD_REFERENCE";
            addOptiontoCurrentMessage("forward_reference", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("SLOTS")) {
            currentElement = "SLOTS";
            optionTmp1 = addOptiontoCurrentMessage("slots", attrs); // reference to the added MessageOption
            optionsListTmp1 = new LinkedList(); // slots list for that option (its value)
            return;
        }

        if (eName.equalsIgnoreCase("SLOT")) {
            if (currentElement.equals("SLOTS"))
                currentElement = "SLOT";
            if (currentElement.equals("SLOT"))
                optionsListTmp1.add(constructOptionMessage("slot", attrs));
            return;
        }

        if (eName.equalsIgnoreCase("REQUEST_SERVICE_CONTEXTS")) {
            currentElement = "REQUEST_SERVICE_CONTEXTS";
            optionTmp1 = addOptiontoCurrentMessage("request_service_contexts", attrs);
            // reference to the added MessageOption
            optionsListTmp1 = new LinkedList(); // service contexts list for that option (its value)
            return;
        }

        if (eName.equalsIgnoreCase("REPLY_SERVICE_CONTEXTS")) {
            currentElement = "REPLY_SERVICE_CONTEXTS";
            optionTmp1 = addOptiontoCurrentMessage("reply_services_contexts", attrs);
            // reference to the added MessageOption
            optionsListTmp1 = new LinkedList(); // service contexts list for that option (its value)
            return;
        }

        if (eName.equalsIgnoreCase("SERVICE_CONTEXT")) {
            if (currentElement.equals("REQUEST_SERVICE_CONTEXTS") || currentElement.equals("REPLY_SERVICE_CONTEXTS"))
                currentElement = "SERVICE_CONTEXT";
            if (currentElement.equals("SERVICE_CONTEXT"))
                optionsListTmp1.add(constructOptionMessage("service_context", attrs));
            return;
        }

        if (eName.equalsIgnoreCase("SENDING_EXCEPTION")) {
            currentElement = "SENDING_EXCEPTION";
            addOptiontoCurrentMessage("sending_exception", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("OBJECT_ID")) {
            currentElement = "OBJECT_ID";
            addOptiontoCurrentMessage("object_id", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("ADAPTER_ID")) {
            currentElement = "ADAPTER_ID";
            addOptiontoCurrentMessage("adapter_id", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("TARGET_MOST_DERIVED_INTERFACE")) {
            currentElement = "TARGET_MOST_DERIVED_INTERFACE";
            addOptiontoCurrentMessage("target_most_derived_interface", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("SERVER_POLICIES")) {
            currentElement = "SERVER_POLICIES";
            optionTmp1 = addOptiontoCurrentMessage("server_policies", attrs); // reference to the added MessageOption
            optionsListTmp1 = new LinkedList(); // policies list for that option (its value)
            return;
        }

        if (eName.equalsIgnoreCase("TARGET_IS_A")) {
            currentElement = "TARGET_IS_A";
            addOptiontoCurrentMessage("target_is_a", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("TARGET")) {
            currentElement = "TARGET";
            addOptiontoCurrentMessage("target", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("EFFECTIVE_TARGET")) {
            currentElement = "EFFECTIVE_TARGET";
            addOptiontoCurrentMessage("effective_target", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("EFFECTIVE_PROFILE")) {
            currentElement = "EFFECTIVE_PROFILE";
            addOptiontoCurrentMessage("effective_profile", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("RECEIVED_EXCEPTION")) {
            currentElement = "RECEIVED_EXCEPTION";
            addOptiontoCurrentMessage("received_exception", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("RECEIVED_EXCEPTION_ID")) {
            currentElement = "RECEIVED_EXCEPTION_ID";
            addOptiontoCurrentMessage("received_exception_id", attrs);
            return;
        }

        if (eName.equalsIgnoreCase("EFFECTIVE_COMPONENTS")) {
            currentElement = "EFFECTIVE_COMPONENTS";
            optionTmp1 = addOptiontoCurrentMessage("effective_components", attrs);
            // reference to the added MessageOption
            optionsListTmp1 = new LinkedList(); // effective components list for that option (its value)
            return;
        }

        if (eName.equalsIgnoreCase("EFFECTIVE_COMPONENT")) {
            if (currentElement.equals("EFFECTIVE_COMPONENTS"))
                currentElement = "EFFECTIVE_COMPONENT";
            if (currentElement.equals("EFFECTIVE_COMPONENT"))
                optionsListTmp1.add(constructOptionMessage("effective_component", attrs));
            return;
        }

        if (eName.equalsIgnoreCase("REQUEST_POLICIES")) {
            currentElement = "REQUEST_POLICIES";
            optionTmp1 = addOptiontoCurrentMessage("request_policies", attrs); // reference to the added MessageOption
            optionsListTmp1 = new LinkedList(); // policies list for that option (its value)
            return;
        }

        if (eName.equalsIgnoreCase("POLICY")) {
            if ((currentElement.equals("REQUEST_POLICIES")) || (currentElement.equals("SERVER_POLICIES")))
                currentElement = "POLICY";
            if (currentElement.equals("POLICY"))
                optionsListTmp1.add(constructOptionMessage("policy", attrs));
            return;
        } // else it's a wrong element name.
    }

    // ----------------------------------------------------------------------

    /** executed when a close tag has been detected */
    public void endElement(String namespaceURI, String sName, String qName) throws SAXException {
        String eName = sName; // element name
        if (sName.equals(""))
            eName = qName; // namespaceAware = false

        if (eName.equalsIgnoreCase("MESSAGE")) {
            addMessage(); // we keep it in the right list of incomplete messages.
            destroyCurrentMessage(); // the temporary message has been treated : we "delete" it
            return;
        }

        if (eName.equalsIgnoreCase("OPERATION")) {
            if (currentElement.equals("ARGUMENT")) {
                updateCurrentOptionList1(); // add a list of its arguments as a new property
            }
            return;
        }

        if (eName.equalsIgnoreCase("EXCEPTIONS")) {
            if (currentElement.equals("EXCEPTION")) {
                updateCurrentOptionList1(); // add a list of its exceptions as a new property
            }
            return;
        }

        if (eName.equalsIgnoreCase("CONTEXTS")) {
            if (currentElement.equals("CONTEXT") || (currentElement.equals("PROPERTY"))) {
                updateCurrentOptionList2();
            }
            return;
        }

        if (eName.equalsIgnoreCase("CONTEXT")) {
            if (currentElement.equals("PROPERTY")) {
                updateCurrentOptionList1();
            }
            return;
        }

        if (eName.equalsIgnoreCase("OPERATION_CONTEXT")) {
            if (currentElement.equals("CONTEXT_PROPERTY")) {
                updateCurrentOptionList1();
            }
            return;
        }

        if (eName.equalsIgnoreCase("SLOTS")) {
            if (currentElement.equals("SLOT")) {
                updateCurrentOptionList1();
            }
            return;
        }

        if (eName.equalsIgnoreCase("REQUEST_SERVICE_CONTEXTS")) {
            if (currentElement.equals("SERVICE_CONTEXT")) {
                updateCurrentOptionList1();
            }
            return;
        }

        if (eName.equalsIgnoreCase("REPLY_SERVICE_CONTEXTS")) {
            if (currentElement.equals("SERVICE_CONTEXT")) {
                updateCurrentOptionList1();
            }
            return;
        }

        if (eName.equalsIgnoreCase("SERVER_POLICIES")) {
            if (currentElement.equals("POLICY")) {
                updateCurrentOptionList1();
            }
            return;
        }

        if (eName.equalsIgnoreCase("EFFECTIVE_COMPONENTS")) {
            if (currentElement.equals("EFFECTIVE_COMPONENT")) {
                updateCurrentOptionList1();
            }
            return;
        }

        if (eName.equalsIgnoreCase("REQUEST_POLICIES")) {
            if (currentElement.equals("POLICY")) {
                updateCurrentOptionList1();
            }
        }

        // else nothing special to do.
    }

    public void error(SAXParseException e) throws SAXException {
        destroyCurrentMessage();
        if (validatedXML) {
            throw e; // spreads the error for a "special" treatment by the calling method.
        }
    }

    public void fatalError(SAXParseException e) throws SAXException {
        destroyCurrentMessage();
        throw e; // spreads the error
    }

    //===========================================================
    // Utility Methods ...
    //===========================================================

    // initialise temporary variables used to keep a trace of already read informations (and still incomplete)
    public void destroyCurrentMessage() {
        currentMsg = null;
        currentElement = "";
        optionsListTmp1 = null;
        optionsListTmp2 = null;
        optionTmp1 = null;
        optionTmp2 = null;
    }

    /**
     * adds message to the right list.
     */
    private boolean addMessage() {
        if(currentMsg == null) return false;
        if (currentMsg.isUseful()) {
            if (currentMsg.isLocal()) {
                localMsg.addMessage(currentMsg);
            } else if (currentMsg.isSource()) {
                corbaSrcMsg.addMessage(currentMsg);
            } else if (currentMsg.isDestination()) {
                corbaDestMsg.addMessage(currentMsg);
            }
            return true;
        }
        return false;
    }

    /**
     * general method for adding attributes as properties of the option (vector of (name + value)),
     * then adding option to the current message.
     *
     * precond : message is not null
     *
     * attention : no checks relative coherence between option name & attributes are made
     *             (we suppose all attributes are coherent with it !)
     *
     * @return a reference to the newly created MessageOption.
     */
    private MessageOption addOptiontoCurrentMessage(String optionName, Attributes attrs) {
        MessageOption optionTmp = constructOptionMessage(optionName, attrs);
        if (currentElement.equals("OPERATION")) {
            currentMsg.addOperation(optionTmp);
        } else {
            currentMsg.addMessageOption(optionTmp);
        }
        return optionTmp;
    }

    private MessageOption constructOptionMessage(String optionName, Attributes attrs) {
        MessageOption optionTmp = new MessageOption(optionName);
        String aName;
        for (int i = 0; i < attrs.getLength(); i++) {
            aName = attrs.getLocalName(i); // Attr name 
            if (aName.equals("")) {
                optionTmp.addProperty(attrs.getQName(i), attrs.getValue(i));
            } else {
                optionTmp.addProperty(aName, attrs.getValue(i));
            }
        }
        return optionTmp;
    }

    private void updateCurrentOptionList1() {
        optionTmp1.addProperty(optionTmp1.getName(), optionsListTmp1);
        optionsListTmp1 = null;
        optionTmp1 = null;
    }

    private void updateCurrentOptionList2() {
        optionTmp2.addProperty(optionTmp2.getName(), optionsListTmp2);
        optionsListTmp2 = null;
        optionTmp2 = null;
    }

    /** asks for some informations at current state of parsing (number of complete and incomplete messages read) */
    public String showInfos(boolean moreInfos) {
        StringBuffer rsl = new StringBuffer("");
        if (moreInfos) { // we add more infos.
            rsl.append(
                "============= local messages ====================================\n" +
               localMsg.toString() + "\n");
            rsl.append(
                "============= incomplete corba source messages ==================\n" +
                corbaSrcMsg.toString() + "\n");
            rsl.append(
            	"============= incomplete corba destination messages =============\n" +
            	corbaDestMsg.toString() + "\n");
     rsl.append("=================================================================\n");
        }

        rsl.append(">parsing process is over.\n");
        rsl.append("\t" + getNbLocalMessages() + " local message" +
        (getNbLocalMessages() > 1 ? "s have" : " has") +
        " been read.\n");
        rsl.append("\t" + getNbIncompleteSourceMessages() + " source message" +
        (getNbIncompleteSourceMessages() > 1 ? "s have" : " has") +
        " been read.\n");
        rsl.append("\t" + getNbIncompleteDestinationMessages() + " destination message" +
        (getNbIncompleteDestinationMessages() > 1 ? "s have" : " has") +
        " been read.\n");
        System.out.println(rsl.toString());

        return rsl.toString();
    }

	public MessageCollection getLocalMessages() {
		return (MessageCollection) localMsg.clone();
	}

    public MessageCollection getHalfDestinationMessages() {
        return (MessageCollection) corbaDestMsg.clone();
    }

    public MessageCollection getHalfSourceMessages() {
        return (MessageCollection) corbaSrcMsg.clone();
    }

    public void clearAll() {
        System.out.println("deleting partial messages");
        localMsg.clear();
        corbaDestMsg.clear();
        corbaSrcMsg.clear();
    }

}
