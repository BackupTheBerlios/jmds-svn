package corbaTrace.log2sequenceDiagram.parser;

import java.util.*;
import java.io.*;
import java.lang.NumberFormatException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.*;

import corbaTrace.log2sequenceDiagram.message.filter.*;

/**
 * It's our handler for use with SAX parsing of Messages Filter file.
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public class FilterHandler extends DefaultHandler {

    private MessagesFilter readFilter;  // current read filter

    private String currentElement; // to know in what level of tag we are
    private String currentFilterCreation;

    private ObjectFilter currentObject;
    private OperationFilter currentOperation;

    private boolean validatedXML;  // indicates wether it throws an exception everytime the XML file is not validated with its DTD.
                                   // if false, ignore such errors.

    private static final String OBJECTS = new String("OBJECTS");
    private static final String OBJECT = new String("OBJECT");
    private static final String MESSAGE_TYPES = new String("MESSAGE_TYPES");
    private static final String METHODS = new String("METHODS");
    private static final String DATES = new String("DATES");


    //-----------------------------------------------------------
    // constructor
    public FilterHandler(boolean validatedXML) {
	super();
	this.validatedXML = validatedXML;
        readFilter = new MessagesFilter();
        currentFilterCreation = null;
	currentElement = "";
        destroyCurrentFilters();
    }
    
    
    //===========================================================
    // SAX DocumentHandler methods
    //===========================================================

    /** executed at the beginning of the document */
    public void startDocument()
	throws SAXException {
    }
    
    
    /** executed when the log is completely read */
    public void endDocument()
	throws SAXException {
    }
    
    // executed when a open tag has been detected
    public void startElement(String namespaceURI,
                             String lName, // local name
                             String qName, // qualified name
                             Attributes attrs)
	throws SAXException {
	    String eName = lName; // element name
	    if ("".equals(eName)) eName = qName; // namespaceAware = false
	    String aName = null;
	    if( eName.equalsIgnoreCase("MESSAGE_TYPES") ) {
		currentElement = "MESSAGE_TYPES";
		if (currentFilterCreation != OBJECT)
		   currentFilterCreation = MESSAGE_TYPES; // meaning global, not object specific.
	    } else if( eName.equalsIgnoreCase("TYPE") ) {
		    // it should have only one attribute of name "value".
		    if (attrs.getLength() == 1) {
			aName = attrs.getLocalName(0); // Attr name 
			if ("".equals(aName)) aName = attrs.getQName(0);
			if (aName.equalsIgnoreCase("VALUE")) {
			    addMessageTypeFilter(attrs.getValue(0));
                        }
                    }
	    } else if ( eName.equalsIgnoreCase("DATES") ) {
		currentElement = "DATES";
		if (currentFilterCreation != OBJECT)
		   currentFilterCreation = DATES; // meaning global, not object specific.
	    } else if ( eName.equalsIgnoreCase("BETWEEN") ) {
		    // it should have only two attributes of names "from" and "to".
		    String from = null, to = null;
                    for (int i=0; i<attrs.getLength(); ++i) {
			aName = attrs.getLocalName(i); // Attr name 
			if ("".equals(aName)) aName = attrs.getQName(i);
			if (aName.equalsIgnoreCase("FROM"))
			    from = attrs.getValue(i);
                        else if (aName.equalsIgnoreCase("TO"))
			    to = attrs.getValue(i);
                    }
                    if ((from != null) && (to != null))
                        addDateFilter(new DateFilter(from, to));
	    } else if ( eName.equalsIgnoreCase("AFTER") ) {
		    // it should have only one attribute of name "date".
		    if (attrs.getLength() == 1) {
			aName = attrs.getLocalName(0); // Attr name 
			if ("".equals(aName)) aName = attrs.getQName(0);
			if (aName.equalsIgnoreCase("DATE")) {
			    addDateFilter(new DateFilter(attrs.getValue(0), true));
                        }
                    }
	    } else if ( eName.equalsIgnoreCase("BEFORE") ) {
		    // it should have only one attribute of name "date".
		    if (attrs.getLength() == 1) {
			aName = attrs.getLocalName(0); // Attr name 
			if ("".equals(aName)) aName = attrs.getQName(0);
			if (aName.equalsIgnoreCase("DATE")) {
			    addDateFilter(new DateFilter(attrs.getValue(0), false));
                        }
                    }
	    } else if ( eName.equalsIgnoreCase("METHODS") ) {
		currentElement = "METHODS";
		if (currentFilterCreation != OBJECT)
		   currentFilterCreation = METHODS; // meaning global, not object specific.
	    } else if ( eName.equalsIgnoreCase("METHOD") ) {
		    // it should have only one attribute of name "name".
		    if (attrs.getLength() == 1) {
			aName = attrs.getLocalName(0); // Attr name 
			if ("".equals(aName)) aName = attrs.getQName(0);
			if (aName.equalsIgnoreCase("NAME")) {
			    addOperationFilter(attrs.getValue(0));
                        }
		        currentElement = "METHOD";
                    }
	    } else if ( eName.equalsIgnoreCase("ARGUMENTAT") ) {
		    if (currentElement.equals("METHOD")) {
		       // it should have only two attributes of names "position" and "value".
		       String position = null, value = null;
                       for (int i=0; i<attrs.getLength(); ++i) {
			   aName = attrs.getLocalName(i); // Attr name 
			   if ("".equals(aName)) aName = attrs.getQName(i);
			   if (aName.equalsIgnoreCase("POSITION"))
			       position = attrs.getValue(i);
                           else if (aName.equalsIgnoreCase("VALUE"))
			       value = attrs.getValue(i);
                       }
                       if ((position != null) && (value != null))
                           // we check if position can be parsed as an int value.
                           try {
                           	int intposition = Integer.parseInt(position);
                           	if (intposition > 0) // position is from 1 to max_nb of attributes.
                           	   addAttributeFilter(new AttributeFilter(intposition, value));
                           } catch (NumberFormatException e) {
                           	// error while converting string to int. It may not be a valid int value.
                           }
                    }   // else no method has been found : so this attribute should not be there.
	    } else if ( eName.equalsIgnoreCase("TYPEDARGUMENT") ) {
		    if (currentElement.equals("METHOD")) {
		       // it should have only two attributes of names "type" and "value".
		       String type = null, value = null;
                       for (int i=0; i<attrs.getLength(); ++i) {
			   aName = attrs.getLocalName(i); // Attr name 
			   if ("".equals(aName)) aName = attrs.getQName(i);
			   if (aName.equalsIgnoreCase("TYPE"))
			       type = attrs.getValue(i);
                           else if (aName.equalsIgnoreCase("VALUE"))
			       value = attrs.getValue(i);
                       }
                       if ((type != null) && (value != null))
                           addAttributeFilter(new AttributeFilter(type, value));
                    }
            } else if ( eName.equalsIgnoreCase("OBJECTS") ) {
		currentElement = "OBJECTS";
		currentFilterCreation = OBJECTS; // meaning object specific.
	    } else if ( eName.equalsIgnoreCase("OBJECT") ) {
		    // it should have only one attribute of name "id".
		    if (attrs.getLength() == 1) {
			aName = attrs.getLocalName(0); // Attr name 
			if ("".equals(aName)) aName = attrs.getQName(0);
			if (aName.equalsIgnoreCase("ID")) {
			    addObjectFilter(attrs.getValue(0));
                        }
		        currentFilterCreation = OBJECT; // meaning object specific.
                    }
	    } // else it's a wrong element name.
    }
    
    // ----------------------------------------------------------------------

    /** executed when a close tag has been detected */
    public void endElement(String namespaceURI,
                           String sName, // simple name
                           String qName  // qualified name
			   )
	throws SAXException {
	    String eName = sName; // element name
	    if ("".equals(sName)) eName = qName; // namespaceAware = false
	    if( eName.equalsIgnoreCase("MESSAGE_TYPES") ) {
		currentFilterCreation = null;
	    } else if ( eName.equalsIgnoreCase("DATES") ) {
		currentFilterCreation = null;
	    } else if ( eName.equalsIgnoreCase("METHODS") ) {
		currentFilterCreation = null;
	    } else if ( eName.equalsIgnoreCase("METHOD") ) {
                currentOperation = null;
		currentElement = "METHODS";
	    } else if ( eName.equalsIgnoreCase("OBJECT") ) {
                destroyCurrentFilters();
		currentFilterCreation = OBJECTS; // meaning object specific (for adding new objects).
	    } // else nothing special to do.
    }
    
    /** executed when a #PCDATA or #CDATA has been detected beetween "start" and "end" tags */
    public void characters(char buf[], int offset, int length)
	throws SAXException {
	/* String s = new String(buf, offset, length);
	   if (!s.trim().equals("")) {
	   if( currentElement.equalsIgnoreCase("") ) {
	   }
	   else if( currentElement.equalsIgnoreCase("") ) {
	   }
	   }
	*/
    }
    

    public void error(SAXParseException e) throws SAXException {
        destroyCurrentFilters();
	if (validatedXML) {
	    throw e; // spreads the error for a "special" treatment by the calling method.
	}
    }

    public void fatalError(SAXParseException e) throws SAXException {
        destroyCurrentFilters();
	throw e; // spreads the error
    }

    private void destroyCurrentFilters() {
        currentObject = null;
	currentOperation = null;
    }

    //===========================================================
    // Filters Creation Methods ...
    //===========================================================    
    private void addDateFilter(DateFilter date) {
         if (! date.isCorrupted()) {
            if (currentFilterCreation == DATES)
                readFilter.addDateFilter(date);
            else if ((currentFilterCreation == OBJECT) && (currentObject != null))
                readFilter.addDateFilter(currentObject, date);
         }
    }
    private void addMessageTypeFilter(String type) {
         if (currentFilterCreation == MESSAGE_TYPES)
             readFilter.addMessageTypeFilter(type);
         else if ((currentFilterCreation == OBJECT) && (currentObject != null))
             readFilter.addMessageTypeFilter(currentObject, type);
    }
    private void addOperationFilter(String operationName) {
         if (currentFilterCreation == METHODS)
             currentOperation = readFilter.addOperationFilter(operationName);
         else if ((currentFilterCreation == OBJECT) && (currentObject != null))
             currentOperation = readFilter.addOperationFilter(currentObject, operationName);
    }
    private void addObjectFilter(String objectID) {
         if (currentFilterCreation == OBJECTS) {
            currentObject = readFilter.addObjectFilter(objectID);
         }
    }
    private void addAttributeFilter(AttributeFilter attF) {
         if (currentOperation != null) {
              currentOperation.addAttributeFilter(attF);
         }
    }

    //===========================================================
    // Utility Methods ...
    //===========================================================    
    public MessagesFilter getMessagesFilter() {
	return readFilter;
    }
}
