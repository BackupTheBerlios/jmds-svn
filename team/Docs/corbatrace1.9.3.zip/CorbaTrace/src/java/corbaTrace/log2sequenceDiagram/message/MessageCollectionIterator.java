package corbaTrace.log2sequenceDiagram.message;
import java.util.*;
import java.lang.*;

/**
 * A MessageCollectionIterator is an iterator to go through all messages.
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public class MessageCollectionIterator implements Iterator {

    // attributes
    private ListIterator currentObject;   // a reference to current object of collection.
    private ListIterator currentMessage;   // a reference to current message of current object.

    // Constructors
    public MessageCollectionIterator (MessageCollection m) {
	currentObject = m.getObjectsIterator();
        boolean notamessage = true;
        while (notamessage && currentObject.hasNext()) {
            currentMessage = ((ObjectMessage)currentObject.next()).getMessagesIterator();
            notamessage = !(currentMessage.hasNext()); // if true, no message for this object, we pass it.
        }
        if (notamessage)  // this collection has no message at all!
           currentMessage = null;
    }


    /** methods defined by Iterator interface. */

    /** gets the next mesage from this MessageCollection */
    public Object next() throws NoSuchElementException {
        boolean thereIsAmessage = false;
        if (currentMessage != null) {       // tests whether this collection has NO message.
            thereIsAmessage = currentMessage.hasNext();  // one message for current object
            // if this object has no more message, we get the next object.
            while (!thereIsAmessage && currentObject.hasNext()) {
                currentMessage = ((ObjectMessage)currentObject.next()).getMessagesIterator();
                thereIsAmessage = currentMessage.hasNext(); // if false, no message for this object, we pass it.
            }
        }
        // if thereIsAmessage is false, no more message are available : we throw an exception.
        if (thereIsAmessage) {
           return currentMessage.next();
        } else {
           throw new NoSuchElementException();
	}
    }
    
    /** tells whether this MessageCollection has still one more message */
    public boolean hasNext() {
        boolean thereIsAmessage = false;
        if (currentMessage != null) {       // tests whether this collection has NO message.
            thereIsAmessage = currentMessage.hasNext();  // one message for current object
            // if this object has no more message, we get the next object.
            while (!thereIsAmessage && currentObject.hasNext()) {
                currentMessage = ((ObjectMessage)currentObject.next()).getMessagesIterator();
                thereIsAmessage = currentMessage.hasNext(); // if false, no message for this object, we pass it.
            }
        }
        return thereIsAmessage;
    }

    public void remove() throws UnsupportedOperationException {
        currentMessage.remove();
	// throw new UnsupportedOperationException();
    }

}
