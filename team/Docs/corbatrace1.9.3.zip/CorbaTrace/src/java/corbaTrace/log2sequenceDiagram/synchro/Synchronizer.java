package corbaTrace.log2sequenceDiagram.synchro;

import java.util.*;
import corbaTrace.log2sequenceDiagram.message.*;
import corbaTrace.log2sequenceDiagram.message.filter.MessagesFilter;

/**
 * It's the class devoted to synchronize object's clocks (and their messages).
 *
 * @author Antoine Parra del Pozo & Brice FRANCOIS
 * @version 1.1
 */
public class Synchronizer{
    
    /** messages to synchronize (NOT synchronized while in memory) */
    private MessageCollection messagesToSynchronize;  
    
    /** it's a graph structure that help to synchronize objects between them 
	(synchronize their clocks) */
    private ObjectGraph synchronizedObjects;
    
    /** contains the messages which we have already synchronize */
    private LinkedList synchronizedMessages;
    
    /** boolean parameter which define the type of synchronization : 
	simple or with an specific algorithm */
    private boolean simpleSynchronize;

/*---------------------------------------------------------------------------*/
    
    /** constructor (by defect) of the synchronizer: 
	without the messages to synchronize */
    public Synchronizer(){
    	messagesToSynchronize = new MessageCollection();
        synchronizedObjects = new ObjectGraph();
	synchronizedMessages = new LinkedList();
        simpleSynchronize = true;
    }
    
/*---------------------------------------------------------------------------*/

    /** usual constructor of the synchronizer: 
	with the messages to synchronize */
    public Synchronizer(MessageCollection messagesToSynchronize){
	synchronizedObjects = new ObjectGraph();
	synchronizedMessages = new LinkedList();
    	initialize(messagesToSynchronize, true);
    }
    
/*---------------------------------------------------------------------------*/

    /**
     * set new MessageCollection (initialize everything with it) 
       and calculate the synchronization graph.
     * @param synchronize tell to synchronize messages 
       (with a synchronization algorithm)
     * when 'synchronize' is false, 
       the Synchronizer make a "simple synchronization".
     * the term 'simple' means that we keep time as default 
       and simply return a sorted list of messages when calling synchronize().
     * (to use when all messages are already based on a common clock).
     */
    public void initialize(MessageCollection messagesToSynchronize, 
			   boolean synchronize){
	 this.simpleSynchronize = !synchronize;
	 // if there are messages to synchronize ...
         if (messagesToSynchronize != null)
	     // we instanciate our local MessageCollection with it 
             this.messagesToSynchronize = messagesToSynchronize;
         else
	     // we create a new local MessageCollection 
    	     this.messagesToSynchronize = new MessageCollection();
         
	 if (!simpleSynchronize)
            buildSynchronizationGraph(); // else nothing to do
    }

/*---------------------------------------------------------------------------*/

    /** realized in two times (steps of synchronization) */
    private void buildSynchronizationGraph(){
	
	/* (1) --> we instanciate the graph edges and nodes with the messages 
	           (edge value = difference of time between objects) 
		   (first step of synchronization: weight of edges)
	*/
	Iterator msgTmp = messagesToSynchronize.iterator();
	while (msgTmp.hasNext()){
	    synchronizedObjects.addMessage((Message)msgTmp.next());
	}
	
	/* when all messages have been added, the difference of time between 
	   objects is the weight of the nodes 
	*/
	
	/* (2) ---> when all messages have been added, we can calculate 
	            clock difference of the objects
		    (second step of synchronization: weightMax of the nodes) 
	*/
	synchronizedObjects.longestWaysCalculation();
    }
    
/*---------------------------------------------------------------------------*/

    /**
     * synchronize message on a common date.
     * launch the method 'getSynchronizedMessages' without filter (null)
     * @param moreInfos print more informations on screen (if value is true)
     */
    public void applySynchronization(boolean moreInfos){
		applySynchronization(moreInfos, null);
    }

/*---------------------------------------------------------------------------*/

    /**
     * get all messages synchronized on a common date.
     */
    public LinkedList getSynchronizedMessages(){
		return synchronizedMessages;
    }

	/**
		* synchronize message on a common date.
		* @param moreInfos print more informations on screen (if value is true)
		* @param filter is a filter to apply during synchronization 
		  (if null, no filter is applied).
		*/
	   public void applySynchronization(boolean moreInfos, 
							 MessagesFilter filter){
	
	   /* we apply the synchronization to obtain the synchronized messages */
	   applySynchronization(filter);
	
	   /* All messages are now synchronized, 
		  but it could have negative clocks,
		  so we adjust the clock of the objects 
		  to obtain only positive clocks */
	   //adjustClocks();
	
	   /* we eventually print informations on screen */
	   if (moreInfos) printOnScreen(filter);
	   }
	   
/*---------------------------------------------------------------------------*/

     /** add a new synchronized message. Messages are sorted by sendind dates 
	 (except if it's unknown).
       * @param msg is supposed synchronized 
       */
    private void addSynchronizedMessage(EntireMessage msg){
	boolean quit = false;
	ListIterator it = synchronizedMessages.listIterator(0);
	EntireMessage msgTmp;
	Date dateMsgToAdd,
	     dateTmp;
	/* we use rather destination object date */
        if (msg.getSourceObjectId() == EntireMessage.BROKEN_OBJECT){ 
	    dateMsgToAdd = msg.getReceivingMessageDate();
        }else{
	    dateMsgToAdd = msg.getSendingMessageDate();
        }
	
	while (!quit && it.hasNext()){
            msgTmp = ((EntireMessage)it.next());
	    /* we use rather destination object date */
            if (msgTmp.getSourceObjectId() == EntireMessage.BROKEN_OBJECT){  
		dateTmp = msgTmp.getReceivingMessageDate();
            }else{
		dateTmp = msgTmp.getSendingMessageDate();
            }
	    
            if (dateMsgToAdd.compareTo(dateTmp) <= 0){ 
		/* means dateMsgToAdd is before dateTmp 
		   (it should be added before current) */
		quit = true;
		it.previous();  // the one before
            }
	}
	/* we add it at this place */
	it.add(msg);
     }

/*---------------------------------------------------------------------------*/
    
    /** We consider at this step of the synchronization, that we have already 
        calculate the clock difference between the objects in the graph. 
      * We have now to apply the calculated clock differences to the messages. 
      */
    public void applySynchronization(MessagesFilter filter){
	
	/* We work with a temporary MessageCollection 
	   (because dates of messages are going to change now) */
	/* If we need, the filter is also applied here */
	MessageCollection filteredMessages = 
	    (filter==null ? 
	     ((MessageCollection)messagesToSynchronize.clone()) : 
	     filter.applyFilter(messagesToSynchronize));
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	
	if (simpleSynchronize){
	    /* in this case, 
	       we simply add the synchronized messages one by one */
	    Iterator it = filteredMessages.iterator();
	    while (it.hasNext()){
		addSynchronizedMessage( (EntireMessage)it.next() );
	    }
	    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	}else{
	    /* in this case, we update all messages: their receiving and 
	       sending dates thanks to the graph */
	    Iterator msgIt = filteredMessages.iterator();
	    EntireMessage msg;
	    String sourceObjectId, destObjectId;
	    /* it correspond to the difference of time (clock) between objects
	       that we have to apply to the messages */
	    long sourceTimeDiff, destTimeDiff;
	    
	    /* for each message, we do ... */
	    while (msgIt.hasNext()){
		msg = (EntireMessage)msgIt.next();
	
		/** firstly, we treat and update the receiving date */
		if (msg.getDestinationObjectId() 
		    != EntireMessage.BROKEN_OBJECT){
		    /* we get the object identifier */
		    sourceObjectId = msg.getSourceObjectId();
		    
		    /* we get the clock difference*/
		    sourceTimeDiff = 
			synchronizedObjects.getObjectWeightMax(sourceObjectId);
		    
		    /* we update the sending date of the message */
		    msg.increaseSendingMessageDate(-sourceTimeDiff);
		    /* it's the same operation if time difference <0 or >0 */
		}    
			
		/** then, we treat and update the sending date */
		if (msg.getSourceObjectId() != EntireMessage.BROKEN_OBJECT){
		    /* we get the object identifier */
		    destObjectId = msg.getDestinationObjectId();
		    
		    /* we get the clock difference */
		    destTimeDiff = 
			synchronizedObjects.getObjectWeightMax(destObjectId);
		
		    /* we update the receiving date of the message */
		    msg.increaseReceivingMessageDate(-destTimeDiff);
		    /* it's the same operation if time difference <0 or >0 */
		}
		
		/* we add the synchronized message */
		addSynchronizedMessage(msg);    
	    } 	    	    
	} 
    }
    
/*---------------------------------------------------------------------------*/

    /* It's the last step of synchronization 
     * not obliged because result is already correct 
     * adjust the clock of the objects to obtain only positive clocks 
     */
    public void adjustClocks(){
	long clockTmp, clockMin;
	ObjectMessage oTmp;	
	MessageCollection messagesToAdjust;
	EntireMessage msg;
	
	messagesToAdjust = new MessageCollection((LinkedList)synchronizedMessages.clone());
	
	/* we search the value of the possible correction to apply */
	ListIterator objIt = messagesToAdjust.getObjectsIterator();
	clockMin = 1000;
	while (objIt.hasNext()){
	    oTmp = (ObjectMessage)objIt.next();
	    clockTmp = synchronizedObjects.
		getObjectWeightMax(oTmp.getIdObject());
	    if (clockTmp < clockMin)
		clockMin = clockTmp;
	}
	
	/* we apply this possible correction to synchronized messages */
	if ((clockMin>0)&&(clockMin!=1000)){
	    Iterator msgIt = synchronizedMessages.iterator();
	    while (msgIt.hasNext()){
		msg = (EntireMessage)msgIt.next();
		msg.increaseSendingMessageDate(-clockMin);
		msg.increaseReceivingMessageDate(-clockMin);
	    }
	}
    }

/*---------------------------------------------------------------------------*/

/** it's a method to print informations 
    about synchronized messages on screen */
    public void printOnScreen(MessagesFilter filter){
	
	/* contains the informations to print on screen */
	StringBuffer rsl = new StringBuffer("");    
	
	/* we get filtered messages */
	MessageCollection filteredMessages = 
	    (filter==null ? 
	     ((MessageCollection)messagesToSynchronize.clone()) : 
	     filter.applyFilter(messagesToSynchronize));
	
	/* we print filtered messages */
	if (filteredMessages.getNbMessages() > 0){
		rsl.append("\n===================================================================\n");
	    rsl.append("============= filtered messages ===================================\n");
    	rsl.append("===================================================================\n\n\n");

		rsl.append(filteredMessages.toString() + "\n\n");
	}
	rsl.append("> synchronization process is over.\n");
	
	/* we print synchronized messages */
	if (synchronizedMessages.size() > 0){
		rsl.append("\n===================================================================\n");
	    rsl.append("============= After synchronization process =========================\n");
    	rsl.append("=====================================================================\n\n\n");

	    
	    ListIterator lit = synchronizedMessages.listIterator(0);
	    EntireMessage eTmp;
	    while (lit.hasNext()){
		eTmp = (EntireMessage)lit.next();
		rsl.append(eTmp.getSourceObjectId() + "\t\t--> " 
			   + eTmp.getDestinationObjectId() + "\t("
			   + eTmp.getMessageId()+", "+eTmp.getMessageType()
			   + ", "+eTmp.getOperationName()+")\t"
			   +"\tfrom " + eTmp.getSendingMessageDateToString()+"\tto "
			   +eTmp.getReceivingMessageDateToString()+"\n");
	    }
	}	
	System.out.println(rsl.toString());	       
    }
    
}

