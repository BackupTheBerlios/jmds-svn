package corbaTrace.log2sequenceDiagram.message.filter;

import java.util.*;
import corbaTrace.log2sequenceDiagram.message.Message;
import corbaTrace.log2sequenceDiagram.message.MessageOption;
import corbaTrace.utils.IndentString;


/** It's a class that define some restriction for an operation (attributes' values).
 *
 * @author Antoine Parra del Pozo
 */

public class OperationFilter {
    private String operationName;

    // restricted objects.
    private LinkedList filteredAttributes;   // AttributeFilter list

    public OperationFilter(String s) {
	operationName = s;
	filteredAttributes = new LinkedList();
    }

    public void addAttributeFilter(AttributeFilter a) {
	if (a != null)
	   filteredAttributes.add(a);
    }

    public String getOperationName() {
	return this.operationName;
    }

    boolean isAllowed (Message m) {
        MessageOption operation = m.getOperation();
	boolean rsl = (operation != null) && operationName.equals((String)operation.getPropertyValue("name"));
        if (rsl) { // checks its attributes if needed.
             rsl = (filteredAttributes.size() == 0);  // if true : no restrictions on attributes.
             if (!rsl) { // meaning we must check also attributes
               ListIterator l = filteredAttributes.listIterator(0);
               while (!rsl && l.hasNext()) {
                   rsl = ((AttributeFilter)l.next()).isAllowed(m);
               }
             }
        }
        return rsl;
    }


    //===========================================================
    // Printing methods.
    //===========================================================
    protected void toString(IndentString s) {
	s.indent(); s.append("<method name=\""+operationName+"\">\n");
	ListIterator l = filteredAttributes.listIterator(0);
	s.inc();
	while (l.hasNext()) {
	    ((AttributeFilter)l.next()).toString(s);
	}
	s.dec();
	s.indent(); s.append("</method>\n");
    }
}
