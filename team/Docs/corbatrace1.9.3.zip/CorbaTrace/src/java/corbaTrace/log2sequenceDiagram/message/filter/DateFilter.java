package corbaTrace.log2sequenceDiagram.message.filter;

import java.util.*;
import corbaTrace.log2sequenceDiagram.message.Message;
import corbaTrace.utils.*;

/** It's a class that define some restriction for a date.
 *  There are three modes :  
 *       - filters messages between two given dates.
 *       - filters messages before one given date.
 *       - filters messages after one given date.
 *  (check constructors)
 *
 * @author Antoine Parra del Pozo
 */

public class DateFilter {

    private Date beginningDate;
    private Date endingDate;

    private short mode;

    private static final short BETWEEN_MODE = 0;
    private static final short AFTER_MODE = 1;
    private static final short BEFORE_MODE = 2;

    /**  build a DateFilter that filters messages between two given dates. */
    public DateFilter(Date beginningDate, Date endingDate) {
        this.beginningDate = beginningDate;
        this.endingDate = endingDate;
        mode = BETWEEN_MODE;
    }

    /**  build a DateFilter that filters messages after or before one given date.
         @param after as false means 'before' date. */
    public DateFilter(Date date, boolean after) {
        beginningDate = date;
        if (after)
           mode = AFTER_MODE;
        else
           mode = BEFORE_MODE;
    }

    /**  same version but Date as a String (depending on format defined in utils.DateUtilities) */
    public DateFilter(String beginningDate, String endingDate) {
        this.beginningDate = DateUtilities.stringToDate(beginningDate);
	if (this.beginningDate == null)
	   System.err.println(">>> error : date (between) is not in valid format ("+beginningDate+").");
        this.endingDate = DateUtilities.stringToDate(endingDate);
	if (this.endingDate == null)
	   System.err.println(">>> error : date (between) is not in valid format ("+endingDate+").");
        mode = BETWEEN_MODE;
    }

    /**  same version but Date as a String (depending on format defined in utils.DateUtilities)
         @param after as false means 'before' date. */
    public DateFilter(String date, boolean after) {
        beginningDate = DateUtilities.stringToDate(date);
	if (beginningDate == null)
	   System.err.println(">>> error : date ("+(after?"after":"before")+") is not in valid format ("+date+").");
	if (after)
           mode = AFTER_MODE;
        else
           mode = BEFORE_MODE;
    }

    /** tells whether this message is allowed for that date filter */
    boolean isAllowed (Message m) {
	// (supposed) precondition :  all dates are correct (or better, synchronized).
	boolean rsl = false;
        Date date1 = m.getSendingMessageDate(),
             date2 = m.getReceivingMessageDate();
	switch (mode) {
           case BETWEEN_MODE :
                 rsl = (beginningDate != null) && (endingDate != null)  // if null, there was an error while constructing date! see errors on screen.
                       && (((date1!=null) && (date1.compareTo(beginningDate) >= 0) && (date1.compareTo(endingDate) <= 0))
                           || ((date2!=null) && (date2.compareTo(beginningDate) >= 0) && (date2.compareTo(endingDate) <= 0)));
               break;
           case AFTER_MODE :
                 rsl = (beginningDate != null)
                       && (((date1!=null) && (date1.compareTo(beginningDate) >= 0))
                           || ((date2!=null) && (date2.compareTo(beginningDate) >= 0)));
               break;
           case BEFORE_MODE :
                 rsl = (beginningDate != null)
                       && (((date1!=null) && (date1.compareTo(beginningDate) <= 0))
                           || ((date2!=null) && (date2.compareTo(beginningDate) <= 0)));
               break;
        }
        return rsl;
    }

    /** tells whether this date filter is corrupted (ans shouldn't be used!!) */
    public boolean isCorrupted() {
	boolean rsl = false;
	switch (mode) {
           case BETWEEN_MODE :
               rsl = (beginningDate == null) || (endingDate != null);  // if null, there was an error while constructing date!.
               break;
           case AFTER_MODE :
               rsl = (beginningDate == null);
               break;
           case BEFORE_MODE :
               rsl = (beginningDate == null);
               break;
        }
        return rsl;
    }


    //===========================================================
    // Printing methods.
    //===========================================================
    protected void toString(IndentString s) {
	s.indent();
	switch (mode) {
           case BETWEEN_MODE :
               s.append("<between from=\""+DateUtilities.dateToString(beginningDate)+"\" to=\""+DateUtilities.dateToString(endingDate)+"\"/>\n");
               break;
           case AFTER_MODE :
               s.append("<after date=\""+DateUtilities.dateToString(beginningDate)+"\"/>\n");
               break;
           case BEFORE_MODE :
               s.append("<before date=\""+DateUtilities.dateToString(beginningDate)+"\"/>\n");
               break;
        }
    }
}
