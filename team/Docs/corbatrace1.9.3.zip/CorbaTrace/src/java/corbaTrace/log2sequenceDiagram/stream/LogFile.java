package corbaTrace.log2sequenceDiagram.stream;

import java.io.*;

/**
 * extends LogStream for using a physical log file.
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public class LogFile implements LogStream {
    
    private String filename;
    public static final short FILE_ID = 0;
    
    public LogFile (String file) {
        this.filename = file;
    }
    
    public InputStream getStream() {
	try {
	    return (new FileInputStream(new File(filename)));
	} catch (java.io.FileNotFoundException e) {
	    System.err.println(">>> I/O error : file " + filename + " not found.");
	}
	return null;
    }
    
    public String getStringValue() {
	return filename;
    }

    public File getFile() {
	return new File(filename);
    }

    public short getStreamType() {
	return FILE_ID;
    }
}

