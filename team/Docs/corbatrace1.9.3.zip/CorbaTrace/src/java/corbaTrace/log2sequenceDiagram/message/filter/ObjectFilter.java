package corbaTrace.log2sequenceDiagram.message.filter;

import java.util.*;

import corbaTrace.log2sequenceDiagram.message.*;
import corbaTrace.utils.IndentString;


/** It's a class that defines some restriction for a filtered object.
 *
 * @author Antoine Parra del Pozo
 */
public class ObjectFilter {
    private String objectID;

    // restricted objects.
    private LinkedList filteredDates;         // DateFilter list
    private LinkedList filteredOperations;    // OperationFilter list
    private LinkedList filteredMessageTypes;  // list of allowed Message types


    public ObjectFilter (String s) {
	objectID = s;
	filteredDates = new LinkedList();
	filteredOperations = new LinkedList();
	filteredMessageTypes = new LinkedList();
    }

    void addDateFilter(DateFilter d) {
	// doubles are allowed (not relevant)
	if (d != null)
	   filteredDates.add(d);
    }
    
    OperationFilter addOperationFilter(String opName) {
	// doubles are not allowed because of possibly newly added attributeFilter on an Operation.
	if (opName != null) {
           boolean found = false;
	   ListIterator l = filteredOperations.listIterator(0);
           OperationFilter oTmp = null;
           while (!found && l.hasNext()) {
              oTmp = (OperationFilter)l.next();
              found = oTmp.getOperationName().equals(opName);
           }
           if (!found) {
              oTmp = new OperationFilter(opName);
              filteredOperations.add(oTmp);
           }
           return oTmp;
        } else {
           return null;
        }
    }

    OperationFilter addOperationFilter(OperationFilter o) {
	// doubles are not allowed because of possibly newly added attributeFilter on an Operation.
	if (o != null) {
           return addOperationFilter(o.getOperationName());
        } else {
           return null;
        }
    }

    void addMessageTypeFilter(String messageType) {
	// the message Type MUST be consistent (so we use constants from MessageType)
    	if (messageType != null)
	   filteredMessageTypes.add(MessageType.giveMessageType(messageType));
    }

    String getObjectId() {
	return this.objectID;
    }

    boolean isAllowed (Message m) {
// WARNING !  Date Filters are supposed not corrupted. Parsing should be aware of that before adding corrupted dates.
//            if all dates are corrupted in the list of date filters, this method consider the message NOT applicable.
//            (meaning this message is not allowed and would not appear in results) whereas it should ignore that
//            to consider date filters are useless.
	boolean rsl = (m != null) && (objectID.equals(m.getSourceObjectId())
	                             || objectID.equals(m.getDestinationObjectId())
	                             || (m.getSourceObjectId() == EntireMessage.BROKEN_OBJECT)
	                             || (m.getDestinationObjectId() == EntireMessage.BROKEN_OBJECT));
        // 1) filters message type
	if (rsl) {
	   rsl = (filteredMessageTypes.size() == 0);
	   ListIterator l;
           if (!rsl) {
               l = filteredMessageTypes.listIterator(0);
               while (!rsl && l.hasNext()) {
                   rsl = (MessageType.giveMessageType((String)l.next()) == m.getMessageType()) && (m.getMessageType() != MessageType.NONE);
               }
           }
           // 2) filters dates
           // there must be one date for which it is allowed and one operation too.
	   // if filteredDates is empty, it's like there is NO restriction, so it is allowed (idem for filteredOperations)
           if (rsl) {  // else is not allowed, whatever date filters are !
               rsl = (filteredDates.size() == 0);
	       if (!rsl) {
                  l = filteredDates.listIterator(0);
                  while (!rsl && l.hasNext()) {
                        rsl = ((DateFilter)l.next()).isAllowed(m);
                  }
	       }
               // 3) filters operations
               if (rsl) {  // else is not allowed, whatever date filters are !
	         rsl = (filteredOperations.size() == 0);
	         if (!rsl) {
	            // tests if this is the right operation of this object (if operation concerned by
	            // this message can be avalaible for this object).
	            if (MessageType.operationIsAvailableOnSourceObject(m.getMessageType()))
	               rsl = objectID.equals(m.getSourceObjectId()) || (m.getSourceObjectId() == EntireMessage.BROKEN_OBJECT);
	            else
	               rsl = objectID.equals(m.getDestinationObjectId()) || (m.getDestinationObjectId() == EntireMessage.BROKEN_OBJECT);
                    if (rsl) { // else it's false : no operation filter is applicable to this object : we don't keep the message.
                       rsl = false;
                       l = filteredOperations.listIterator(0);
                       while (!rsl && l.hasNext()) {
                          rsl = ((OperationFilter)l.next()).isAllowed(m);
                       }
	            }
	         }
               } // endif filtering operations
           } // endif - filtering message dates
        } // endif - filtering message types
	return rsl;
    }

    //===========================================================
    // Printing methods.
    //===========================================================
    public void toString(IndentString s) {
	s.indent(); s.append("<object id=\""+objectID+"\">\n");
	s.inc();
	printTypes(s);
	printDates(s);
	printMethods(s);
	s.dec();
	s.indent(); s.append("</object>\n");
    }

    protected void printTypes (IndentString s) {
	ListIterator l = filteredMessageTypes.listIterator(0);
	s.indent(); s.append("<messages_type>\n");
	s.inc();
	while (l.hasNext()) {
	    s.indent();
	    s.append("<type value=\""+((String)l.next())+"\"/>\n");
	}
	s.dec();
	s.indent(); s.append("</messages_type>\n");
    }

    protected void printDates (IndentString s) {
	ListIterator l = filteredDates.listIterator(0);
	s.indent(); s.append("<dates>\n");
	s.inc();
	while (l.hasNext()) {
	    ((DateFilter)l.next()).toString(s);
	}
	s.dec();
	s.indent(); s.append("</dates>\n");
    }

    protected void printMethods (IndentString s) {
	ListIterator l = filteredOperations.listIterator(0);
	s.indent(); s.append("<methods>\n");
	s.inc();
	while (l.hasNext()) {
	    ((OperationFilter)l.next()).toString(s);
	}
	s.dec();
	s.indent(); s.append("</methods>\n");
    }

}
