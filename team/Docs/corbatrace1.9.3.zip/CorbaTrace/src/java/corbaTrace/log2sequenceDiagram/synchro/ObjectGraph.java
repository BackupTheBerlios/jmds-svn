package corbaTrace.log2sequenceDiagram.synchro;

import java.util.*;
import corbaTrace.log2sequenceDiagram.message.*;

/**
 * It's a graph structure to keep objects and value time differences
 * (to approximate synchronization between object's clock).
 *
 * @author Antoine Parra del Pozo & Brice FRANCOIS
 * @version 1.1
 */
class ObjectGraph{

    /** 'objects' is the list (hasbtable) of all nodes */
    private Hashtable objects;  
    /** the 'referenceObject' is a particular node for the synchronization */
    private ObjectGraphNode referenceObject;    

/*---------------------------------------------------------------------------*/
   
    /** default constructor to build an empty graph */
    public ObjectGraph() {
        objects = new Hashtable();
        referenceObject = null;
    }

/*---------------------------------------------------------------------------*/
   
    /** add a simple object (if not already added) */
    public ObjectGraphNode addObject(String objectID){
	ObjectGraphNode oRsl = (ObjectGraphNode)objects.get(objectID);
    	if (oRsl == null){
	    /* if it doesn't already exist: we create it */
	    oRsl = new ObjectGraphNode(objectID);
	    /* then add it */
	    objects.put(objectID, oRsl);
	}
	return oRsl;
    }

/*---------------------------------------------------------------------------*/
   
    /** add a simple object (if not already added), 
	and update weights with this message.
	After adding all messages, each edge have a weight which correspond to
	the minimal clock difference between two objects.
    */
    public void addMessage(Message m){
	
	String idSrc = m.getSourceObjectId(),
	       idDest = m.getDestinationObjectId();
	
	/* we only treat the message for synchronization if it is not broken 
	   (because they don't have enough useful informations),
	   but we add anyway all "known" objects side 
	   of these broken messages in graph */
	
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	if (!MessageType.isBrokenType(m.getMessageType())){
	    // get objects. If not found, add new ones.
	    long timeDifference = 0;
	    // get Object; add it in not found.
	    ObjectGraphNode oDest = addObject(idDest), 
		            oSrc = addObject(idSrc);
	    /* get difference of time beetween this 2 objects(for this message)
	       (from source to destination, meaning what to add to source time
	       to have destination time) */
	    timeDifference = m.getReceivingMessageDate().getTime() 
		           - m.getSendingMessageDate().getTime();
	    /* add the edges (then update weights) */
	    ObjectGraphEdge tmpEdge1 = 
		oDest.addNeighbour(oSrc, new ObjectGraphEdge(-timeDifference));
	    ObjectGraphEdge tmpEdge2 = 
		oSrc.addNeighbour(oDest, new ObjectGraphEdge(timeDifference));

	    /* if not null, it means that there was already an edge between 
	       these two objects. We check whether the new edge weight 
	       (if timeDifference is lower than the current one) */
	    
	    if ((tmpEdge2 != null)
	       && (Math.abs(tmpEdge2.getWeight()) < Math.abs(timeDifference))){
	        /* we update edges weight */
		tmpEdge2.setWeight(timeDifference);
		tmpEdge1.setWeight(-timeDifference);
	    }
	    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	}else{ 
	    /* else it's a broken message, 
	       not relevant. Just add objects if needed */
	    if (idSrc != EntireMessage.BROKEN_OBJECT)
		addObject(idSrc);
	    if (idDest != EntireMessage.BROKEN_OBJECT)
		addObject(idDest);
	}
    }
    
/*---------------------------------------------------------------------------*/
   
    /** get the weight of an object of the graph known thanks to its 'id' */
    public long getObjectWeight(String objectID){
        ObjectGraphNode nodeTmp = (ObjectGraphNode)objects.get(objectID);
        if (nodeTmp != null)
	    return nodeTmp.getWeight();
        else{
	    System.err.println(objectID + 
	           " is not found in memory (ObjectGraph::getObjectWeight())");
	    return 0;  /* MEANS it's an error! should throw an exception. */
	}
    }
    
/*---------------------------------------------------------------------------*/
   
    /** get the maximal weight of an object of the graph */
    public long getObjectWeightMax(String objectID){
        ObjectGraphNode nodeTmp = (ObjectGraphNode)objects.get(objectID);
        if (nodeTmp != null)
	    return nodeTmp.getWeightMax();
        else{
	    System.err.println(objectID + 
	        " is not found in memory (ObjectGraph::getObjectWeightMax())");
	    return 0;  /* MEANS it's an error! should throw an exception. */
	}
    }    
    
/*---------------------------------------------------------------------------*/
   
    /** all edges have a weight (thanks to messages) 
        (which give a difference of clock beetween 2 objects),
        we can now make a second calculation: clock difference 
	between reference object and each node: weightMax of a node. 
    */
    public void updateWeightMax(String referenceObject){
        /* if there isn't 'refence object', it will create one */
	this.referenceObject = (ObjectGraphNode)objects.get(referenceObject);
        /* then we begin updating of nodes' weight */
	updateWeightMax();
    }
    
/*---------------------------------------------------------------------------*/
   
    /** this method update weightMax of nodes (0 by defect), 
	traversing the graph in width */
    public void updateWeightMax(){
        ObjectGraphNode objectTmp;
        ObjectGraphNode referenceObjectTmp;
        Enumeration elem;
        
	if (referenceObject == null){  
	    /* if no one is selected, we get one automatically */
	    referenceObject = getReferenceObject();
        }
	
        referenceObjectTmp = referenceObject;
        while (referenceObjectTmp != null){
	    /* we have our reference object which have a weight equal to 0 */
	    referenceObject.setWeight(0);
	    /* we mark it */
	    referenceObject.markIt();
	    
	    LinkedList stillToComplete = new LinkedList();
	    stillToComplete.add(referenceObject);
	    
	    // we value all it's neighbours' maximal weight
	    weightMaxCalculation(stillToComplete);
	    // all these objects (or related to) have been processed.
	    
	    /* we get a new reference object, 
	       if there is other isolated communicating objects */
	    referenceObjectTmp = getReferenceObject();    
        }
        // we unmark all objects now
        elem = objects.elements();
        int maxCount = 0, currentCount = 0;
        while (elem.hasMoreElements()){
            objectTmp = (ObjectGraphNode)elem.nextElement();
            objectTmp.unmarkIt();
        }
    }
    
/*---------------------------------------------------------------------------*/
    
    /**
     * For all its neighbour nodes, value their maximal weight by updating 
       current node instance maximal weight with edge's weight between these
       two nodes. And so on (recursively, in width).
     * It calculate the maximal weight 
       between the reference object and this node.
       (the maximal clock difference between them 
     * for example :  let say  A is our current node with a weightMax 2 
                      and B is its neighbour of weightMax 5 
		      and edge 'A->B' weight is 4,
		      then (as 2+4 > 5) B weightMax become 6
    */
    private void weightMaxCalculation(LinkedList stillToComplete){
	ObjectGraphNode currentNode, nodeTmp;
	ObjectGraphEdge edgeTmp;
	ListIterator nodeIt, edgeIt;
	long weightMaxTmp;
	
	while (! stillToComplete.isEmpty()){
	    /* the current node is removed from the list */
	    currentNode = (ObjectGraphNode)stillToComplete.removeFirst();
	    /* we get node and edge of its first neighbour */
	    nodeIt = currentNode.getNeighbourNodesList().listIterator(0);
	    edgeIt = currentNode.getNeighbourEdgesList().listIterator(0);
	    
	    /* we will update weightMax of each neighbour */
	    while (nodeIt.hasNext()){
		nodeTmp = (ObjectGraphNode)nodeIt.next();
		/* we update its weightMax value */
		edgeTmp = (ObjectGraphEdge)edgeIt.next();
		/* we calculate node maximal weight + edge weight */
		weightMaxTmp = currentNode.getWeightMax() +edgeTmp.getWeight();
		if ( weightMaxTmp > nodeTmp.getWeightMax() ){
		    /* this value ameliorate the old value */
		    nodeTmp.setWeightMax(weightMaxTmp);
		}
		
		/* then we add this node in the list 
		   to continue the graph crossing */
		if (! nodeTmp.isMarked()){
		    nodeTmp.markIt();
		    stillToComplete.addLast(nodeTmp);
		}else{
		    edgeIt.next();
		}
	    } // end 1� while
	}// end 2� while
    }
    
/*---------------------------------------------------------------------------*/
   
    /* get a reference object among all unmarked ones */
    private ObjectGraphNode getReferenceObject(){
        /* for all objects, we count distinct neighbours, 
	   then we keep the one that have more neighbours */
	Enumeration elem = objects.elements();
        int maxCount = 0,
            currentCount = 0;
        ObjectGraphNode objectTmp,
                        referenceObjectTmp = null;
        while (elem.hasMoreElements()) {
            objectTmp = (ObjectGraphNode)elem.nextElement();
            if (! objectTmp.isMarked()) {
               currentCount = objectTmp.countNeighbours();
               if (maxCount < currentCount) {
                   maxCount = currentCount;
                   referenceObjectTmp = objectTmp;
               }
            }
        }
        return referenceObjectTmp;
    }
    
/*---------------------------------------------------------------------------*/
 
    /** calculate the longest ways of the graph : 
      * after this calculation, each node will have as maximal weight 
        the value of the longest way 
        between a reference object and this node 
      */
    public void longestWaysCalculation(){
	
	/* (1�) for each group of related nodes, 
	        - we get a reference object 
                - we calculate :
	 * (2�) for each node, the longest way from the reference object. 
	 *      this value is the maximal weight of the node: weightMax 
	 */
	updateWeightMax();
	
	/* (3�) after having all 
	 */
    }




}

