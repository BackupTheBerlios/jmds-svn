package corbaTrace.log2sequenceDiagram.message;
import java.util.*;

public class LocalMessage extends Message {

    public boolean isSource() {
        return false;
    }

    public boolean isDestination() {
        return false;
    }

    public boolean isLocal() {
        return true;
    }

    public boolean equals(Message m) {
    	return (this.sourceObjectId.equals(m.getSourceObjectId())) &&
		(this.sendingMessageDate.equals(m.getSendingMessageDate()));
    }

    public int compareTo(Message m) {
        if (m instanceof LocalMessage) {
            return this.getSendingMessageDate().compareTo(m.getSendingMessageDate());
        }

        return 1;
    }
}
