package corbaTrace.log2sequenceDiagram.log2svg;

/**
 * CorbaTraceMessage records information of a corba trace message 
 *
 * @author FRANCHETEAU Aurelien
 */

public class CorbaTraceComment{

    
    private String sender;
    private String comment;
    private long timeSender;

    
    public CorbaTraceComment(String sender,long timeSender,String comment){
	this.sender = sender;
	this.comment = comment;
	this.timeSender = timeSender;
    }
    //===========================================================
    // Access Methods
    //===========================================================
    public String getSender(){
	return sender;
    }

    public String getText(){
	return comment;
    }
    public long getTimeSender(){
	return timeSender;
    }
   
    public void setTimeSender(long time){
	timeSender = time;
    }
    
}
