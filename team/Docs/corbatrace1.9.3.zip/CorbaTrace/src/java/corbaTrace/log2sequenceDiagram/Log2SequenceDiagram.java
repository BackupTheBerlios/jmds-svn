package corbaTrace.log2sequenceDiagram;

import java.util.*;
import corbaTrace.log2sequenceDiagram.log2xmi.*;

import java.util.*;
import java.io.InputStream;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import corbaTrace.xmi.*;
import corbaTrace.xmi2tex.*;
import corbaTrace.log2sequenceDiagram.Merger.*;
import corbaTrace.log2sequenceDiagram.log2svg.*;
import corbaTrace.log2sequenceDiagram.log2xmi.*;
import corbaTrace.log2sequenceDiagram.stream.*;
import corbaTrace.log2sequenceDiagram.parser.*;
import corbaTrace.log2sequenceDiagram.message.*;
import corbaTrace.log2sequenceDiagram.message.filter.*;
import corbaTrace.log2sequenceDiagram.synchro.*;

public class Log2SequenceDiagram {
    /** It's the executive class.
      * It works in 4 steps :
      *    - logs Parsing step
      *    - half-messages parsed Merging step
      *    - Synchronization step of merged messages
      *    - XMI file generation from synchronized messages
      * Be aware that at the end of each step, the next step is prepared.
      *
      * NOTE : For now, filter is applied only before generating XMI file (at the end of synchronization - see synchronizeAll() body);
      */

    private LinkedList LogStreams; /* list of LogStreams objects to parse */

    private boolean valideXMLFiles;
    private boolean rationalRoseExtension;
    private boolean magicDrawExtension;
    private boolean debug; /* debug mode (for more precise informations) */
    private boolean synchronize;

    private LogsParser saxLogsParser; /* corbatrace messages parse */
    private FilterParser saxFilterParser; /* filter parser */

    private LogMerger messagesMerger; /* the merge engine */
    private Synchronizer messagesSynchronizer; /* the synchronization engine */
    private MessagesFilter messagesFilter; /* the messages filter */
    private XmiGenerator xmiMessagesGenerator; /* the XMI generation engine object */
    private SvgGenerator svgMessagesGenerator; /* the SVG generation engine object */
    private Xmi2tex texMessagesGenerator; /* the TEX generation engine object */

    public Log2SequenceDiagram() {

        valideXMLFiles = true;
        rationalRoseExtension = false;
        magicDrawExtension = false;
        debug = false;
        synchronize = true;

        LogStreams = new LinkedList();

        saxLogsParser = new LogsParser(valideXMLFiles);
        saxFilterParser = new FilterParser(valideXMLFiles);

        messagesMerger = new LogMerger();
        messagesSynchronizer = new Synchronizer();
        messagesFilter = new MessagesFilter();
        xmiMessagesGenerator = new XmiGenerator();
        svgMessagesGenerator = new SvgGenerator();
    }

    /** add a new log file to parse */
    public void addInputFile(String inputFile) {
        LogStream logTmp = makeLogStream(inputFile);

        if (logTmp != null) {
            LogStreams.add(logTmp);
        }
    }

    /**
     * set the fileName containing the filter wich will be applied before
     * synchronizing
     */
    public void setFilterFile(String filterFile) {
        if (filterFile == null)
            return;

        saxFilterParser.parse(makeLogStream(filterFile));

        messagesFilter = saxFilterParser.getMessagesFilter();

        if (debug) {
            System.out.println(
                "\n\n ============================================================"
                    + "\n ================== parsed filter ==================\n"
                    + messagesFilter.toString()
                    + "\n");
            System.out.println("\n> filter has been imported.\n");
        }
    }

    /**
     * @param value if true validate Logs and filter XML files with their DTD
     */
    public void valideXMLFiles(boolean value) {
        this.valideXMLFiles = value;
    }

    /**
     * @param value if true print debug messages
     */
    public void debug(boolean value) {
        this.debug = value;
    }

    /**
     * @param value if true synchronize messages before output files generation
     */
    public void synchronize(boolean value) {
        this.synchronize = value;
    }

    /**
     * @param value if true add Rational Rose extention to XMI file during generation
     */
    public void addRationalRoseExtension(boolean value) {
        rationalRoseExtension = value;
    }

    /**
     * @param value if true add Magic Draw extention to XMI file during generation
     */
    public void addMagicDrawExtension(boolean value) {
        magicDrawExtension = value;
    }

    /**
     * Parse all logs added by addInputFile() method.
     * @return false if no message have been correctly read, or no file parsed correctly.
     */
    public boolean parse() {

        if (LogStreams.size() == 0) {
            if (debug) {
                System.out.println("> no file to parse\n");
            }
            return false;
        }

        /* parse each logStream */
        ListIterator l = LogStreams.listIterator();
        while (l.hasNext()) {
            saxLogsParser.parse((LogStream) l.next());
        }

        /* debugging message */
        if (debug) {
            System.out.println("\n===================================================================");
            System.out.println("============= After parsing process ===============================");
            System.out.println("===================================================================\n\n");

            saxLogsParser.showInfos(debug);
        }

        return (
            (saxLogsParser.getNbIncompleteSourceMessages() == 0)
                && (saxLogsParser.getNbIncompleteDestinationMessages() == 0));
    }

    /**
     * merge all messages created after parsing logs.
     */
    public void merge() {
        // initialises the merge engine with these parsed half-messages.
        messagesMerger.initialize(
            saxLogsParser.getLocalMessages(),
            saxLogsParser.getHalfSourceMessages(),
            saxLogsParser.getHalfDestinationMessages());

        // merge
        messagesMerger.mergeAll();

        /* debugging message */
        if (debug) {
            System.out.println("\n===================================================================");
            System.out.println("============= After merging process ===============================");
            System.out.println("===================================================================\n\n");
            messagesMerger.showInfos(debug);
        }
    }

    /**
     * synchronize all entire messages created after merging.
     */
    public void synchronize() {
        // initialises the synchronization engine with already merged entire messages.
        //messagesSynchronizer.reInit(messagesMerger.getEntireMessages(true), synchronize);
        messagesSynchronizer.initialize(messagesMerger.getEntireMessages(true), synchronize);
		messagesSynchronizer.applySynchronization(debug, messagesFilter);
        // initialises the XMI generation engine with these entire synchronized messages.
        if ((messagesFilter != null) && (!messagesFilter.filterIsEmpty())) {
			xmiMessagesGenerator.addAllMessages(messagesSynchronizer.getSynchronizedMessages());
			if (this.rationalRoseExtension) {
                xmiMessagesGenerator.setExtension(xmiMessagesGenerator.ROSE_EXTENSION);
            }
            if (this.magicDrawExtension) {
                xmiMessagesGenerator.setExtension(xmiMessagesGenerator.MAGICDRAW_EXTENSION);
            }
        } else {
            xmiMessagesGenerator.addAllMessages(messagesSynchronizer.getSynchronizedMessages());
        }
        svgMessagesGenerator.addMessages(messagesSynchronizer.getSynchronizedMessages());
    }

    /**
     * generate xmi file from entire messages list created after merging (and synchronization)
     */
    public void generateXmiFile(String outputfile) {
        xmiMessagesGenerator.saveFile(outputfile);
    }

    /**
     * generate tex file from entire messages list created after merging (and synchronization)
     */
    public void generateTexFile(String outputfile) {
        texMessagesGenerator = new Xmi2tex(outputfile);
    }

    /**
     * generate svg file from entire messages list created after merging (and synchronization)
     */
    public void generateSvgFile(String outputfile) {
        svgMessagesGenerator.save(outputfile,1);
    }
    
	/**
	 * generate svg file from entire messages list created after merging (and synchronization)
	 */
	public void generateSvgFile(String outputfile, float scale) {
		svgMessagesGenerator.save(outputfile,scale);
	}
    

    /** process all steps in one.
      * i.e. parse, merge and synchronize.
      */
    public void processAll() {
        parse(); // parse all logs.
        merge(); // merge all parsed messages.
        synchronize(); // synchronize all.
		 
    }

    /**
     * return a Object wich implement LogStream interface
     * if inputFile is an URL a LogUrl Object is returned
     * else a LogFile Object is returned
     */
    private LogStream makeLogStream(String inputFile) {
        // checks if it can be converted to an URL.
        try {
            java.net.URL x = new java.net.URL(inputFile);
            // no exception : it can be converted : it's an url
            return (new LogUrl(inputFile));
        } catch (java.net.MalformedURLException e) {
            // it's not an URL : we consider it is a file.
            return (new LogFile(inputFile));
        }
    }
}
