package corbaTrace.log2sequenceDiagram.message;

import java.util.*;
import corbaTrace.utils.*;

/**
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public abstract class Message {
    protected String messageId;
    protected String messageType;
    protected String requestId;

    protected String sourceObjectId;
    protected String destinationObjectId;
    protected Date sendingMessageDate;
    protected Date receivingMessageDate;
    protected Vector messageOptionList;
    protected MessageOption operation;

    public Message() {
        messageId = null;
        messageType = MessageType.NONE;
        requestId = null;
        sourceObjectId = null;
        destinationObjectId = null;
        sendingMessageDate = null;
        receivingMessageDate = null;
        operation = null;
        messageOptionList = null;
    }

    //===========================================================
    // Access Methods
    //===========================================================

    public String getMessageId() {
        return messageId;
    }

    public String getMessageType() {
        return messageType;
    }

    public String getRequestId() {
        return requestId;
    }

    public String getDestinationObjectId() {
        return destinationObjectId;
    }

    public String getSourceObjectId() {
        return sourceObjectId;
    }

    public Date getSendingMessageDate() {
        return sendingMessageDate;
    }

    public Date getReceivingMessageDate() {
        return receivingMessageDate;
    }

    public String getSendingMessageDateToString() {
        return DateUtilities.dateToString(sendingMessageDate);
    }

    public String getReceivingMessageDateToString() {
        return DateUtilities.dateToString(receivingMessageDate);
    }

    public Vector getMessageOptionList() {
        return messageOptionList;
    }

    public MessageOption getOperation() {
        return operation;
    }

    /** tells whether the message is a source message
     */
    public abstract boolean isSource();

    /** tells whether the message is a destination message
     */
    public abstract boolean isDestination();

    /** tells whether the message is a local message
     */
    public abstract boolean isLocal();

    /** tells whether the message has set at least an ID and a type, one date, and one ObjetID
     *  it is used before adding a message, to be sure it's useful enough.
     */
    public boolean isUseful() {
        return (
            (messageId != null)
                && (messageId.length() > 0)
                && (messageType != MessageType.NONE)
                && ((sourceObjectId != null)
                    && (sourceObjectId.length() > 0)
                    || (destinationObjectId != null)
                    && (destinationObjectId.length() > 0))
                && ((sendingMessageDate != null) || (receivingMessageDate != null)));
    }

    /** 
     * @return the name of the operation for this message
     */
    public String getOperationName() {
        if (operation != null) {
            // gets its attribute named "name" (the name of this operation)
            return ((String) operation.getPropertyValue("name")); // null if not defined
        } else {
            return null; // operation is not defined
        }
    }
    
    public String getArgumentsValues(){
    	String result = "";
    	if (operation != null) {
            // gets its attribute named "arguments"
            LinkedList arguments = ((LinkedList) operation.getPropertyValue("operation")); // null if not defined
            Iterator it = arguments.iterator();
            while (it.hasNext()) {
                MessageOption element = (MessageOption) it.next();
                result = result + element.getPropertyValue("value");
                if(it.hasNext()){
                	result = result + ", ";
                }
            }
        }
        return result;	
    }

    /** returns a list of MessageOption which are arguments of this operation. */
    public LinkedList getOperationArguments() {
        if (operation != null) {
            // gets its attribute named "arguments"
            return ((LinkedList) operation.getPropertyValue("operation")); // null if not defined
        } else {
            return null; // operation is not defined
        }
    }

    /** 
     * @param name is the name of the option we're looking for.
     * @return true if this option is defined.
     */
    public boolean optionIsDefined(String name) {
        int cpt = messageOptionList.size() - 1;
        boolean exit = (operation != null && operation.getName().equals(name));
        while (!exit && (cpt >= 0)) {
            exit = (name.equals(((MessageOption) (messageOptionList.elementAt(cpt))).getName()));
            cpt--;
        }
        return (exit);
    }

    /** 
     * @param name is the name of the option we're looking for.
     * @return the MessageOption;  null if this option is not found.
     */
    public MessageOption getOption(String name) {
        if (operation != null && operation.getName().equals(name))
            return operation;
        else {
            int cpt = this.messageOptionList.size() - 1;
            boolean exit = false;
            while (!exit && (cpt >= 0)) {
                exit = (name.equals(((MessageOption) (messageOptionList.elementAt(cpt))).getName()));
                cpt--;
            }
            if (exit) { // option found
                return (MessageOption) messageOptionList.elementAt(++cpt);
            } else {
                return null;
            }
        }
    }

    //===========================================================
    // Modification Methods
    //===========================================================

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public void setMessageType(String type) {
        messageType = MessageType.giveMessageType(type);
    }

    public void setRequestId(String rqs) {
        if (rqs != null) {
            requestId = rqs;
        }
    }

    public void setDestinationObjectId(String id) {
        destinationObjectId = id;
    }

    public void setSourceObjectId(String id) {
        sourceObjectId = id;
    }

    /** version with a formated String to parse as a Date.
      * @see DateUtilities
      */
    public void setSendingMessageDate(String date) {
        sendingMessageDate = DateUtilities.stringToDate(date);
        if (sendingMessageDate == null) {
            System.err.println(">>> error : date is not in valid format.");
        }
    }

    public void setReceivingMessageDate(String date) {
        receivingMessageDate = DateUtilities.stringToDate(date);
        if (receivingMessageDate == null) {
            System.err.println(">>> error : date is not in valid format.");
        }
    }

    public void setSendingMessageDate(Date date) {
        sendingMessageDate = date;
    }

    public void setReceivingMessageDate(Date date) {
        receivingMessageDate = date;
    }

    /** 
      * increase (or decrease) by duration this sending date.
      * @param duration is the time to add in milliseconds.
      */
    public void increaseSendingMessageDate(long duration) {
        sendingMessageDate.setTime(sendingMessageDate.getTime() + duration);
    }

    /**
      * increase (or decrease) by duration this Receiving date.
      * @param duration is the time to add in milliseconds.
      */
    public void increaseReceivingMessageDate(long duration) {
        receivingMessageDate.setTime(receivingMessageDate.getTime() + duration);
    }

    public void addMessageOption(MessageOption m) {
        if (messageOptionList == null) {
            messageOptionList = new Vector();
        }
        messageOptionList.add(m);
    }

    public void addOperation(MessageOption m) {
        if (m == null)
            this.operation = new MessageOption("operation");
        else {
            if (m.getName() != "operation") {
                m.setName("operation");
            }
            this.operation = m;
        }
    }

    //===========================================================
    // toString Utility Methods
    //===========================================================

    public String toString() {
        return toString(new IndentString());
    }

    public String toString(IndentString s) {
        printHeader(s);
        printOperation(s);
        printOptions(s);
        printFoot(s);
        return s.toString();
    }

    protected void printHeader(IndentString s) {
        s.append("\n");
        s.indent();
        s.append("<message ");
        s.append("mesg_id=\"" + messageId + "\" ");
        s.append("type=\"" + messageType + "\" ");
        if (requestId!=null) s.append("request_ID=\"" + requestId + "\">");
        s.inc();
        s.append("\n");
        s.indent();
        s.append("<local_object ID=\"" + sourceObjectId + "\" date=\"" + getSendingMessageDateToString() + "\" />");
        if (destinationObjectId != null && receivingMessageDate != null) {
            s.append("\n");
            s.indent();
            s.append("<distant_object ID=\"");
            if (destinationObjectId != null)
                s.append(destinationObjectId);
            s.append("\" date=\"");
            if (receivingMessageDate != null)
                s.append(getReceivingMessageDateToString());
            s.append("\" />");
        }
    }

    protected void printOperation(IndentString s) {
        // prints its operation
        if (operation != null) {
            operation.toString(s);
        }
    }

    protected void printOptions(IndentString s) {
        // prints its options
        if (messageOptionList != null) {
            s.append("\n");
            s.indent();
            s.append("<options>");
            s.inc();
            for (int i = 0; i < messageOptionList.size(); ++i) {
                ((MessageOption) messageOptionList.elementAt(i)).toString(s);
            }
            s.dec();
            s.append("\n");
            s.indent();
            s.append("</options>");
        }
    }

    protected void printFoot(IndentString s) {
        s.dec();
        s.append("\n");
        s.indent();
        s.append("</message>\n");
    }

    abstract public boolean equals(Message m);

    abstract public int compareTo(Message m);

}
