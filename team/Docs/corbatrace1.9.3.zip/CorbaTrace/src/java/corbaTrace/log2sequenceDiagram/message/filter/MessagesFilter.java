package corbaTrace.log2sequenceDiagram.message.filter;

import java.util.*;

import corbaTrace.log2sequenceDiagram.message.*;
import corbaTrace.utils.IndentString;

/** It's a class that operates as a Filter to a MessageCollection.
 *
 * @author Antoine Parra del Pozo
 */
public class MessagesFilter {

    /** there are some elements of filtering to consider.
     *   => objects
     *   => types of messages
     *   => operations of objects (and values of some operation attributes)
     *   => interval of dates
     *
     */
    private LinkedList filteredObjects;       // date, types, operations filters on a given object
    private LinkedList filteredDates;         // applies globally
    private LinkedList filteredMessageTypes;  // applies globally
    private LinkedList filteredOperations;    // applies globally


    public MessagesFilter() {
        filteredObjects = new LinkedList();
        filteredDates = new LinkedList();
        filteredMessageTypes = new LinkedList();
        filteredOperations = new LinkedList();
    }


    //===========================================================
    // Filter Creation.
    //===========================================================

    /* add a new object to filter (if needed).
     * @returns the ObjectFilter.
     */
    public ObjectFilter addObjectFilter(String objectID) {
      if (objectID != null) {
        boolean found = false;
	ListIterator l = filteredObjects.listIterator(0);
	ObjectFilter oTmp = null;
        while (!found && l.hasNext()) {
           oTmp = (ObjectFilter)l.next();
           found = oTmp.getObjectId().equals(objectID);
        }
        if (!found) {
           oTmp = new ObjectFilter(objectID);
           filteredObjects.add(oTmp);
        }
        return oTmp;
      } else {
        return null;
      }
    }

    //--------------------
    // Dates
    //--------------------

    /** add a new date to filter for the whole messages */
    public void addDateFilter(Date date, boolean after) {
	filteredDates.add(new DateFilter(date, after));
    }

    /** add a new date to filter for the whole messages */
    public void addDateFilter(Date beginingDate, Date endingDate) {
	filteredDates.add(new DateFilter(beginingDate, endingDate));
    }

    /** add a new date to filter for the whole messages */
    public void addDateFilter(DateFilter date) {
	filteredDates.add(date);
    }

    /** add a new date to filter for a given object */
    public void addDateFilter(String objectID, Date date, boolean after) {
	ObjectFilter oTmp = addObjectFilter(objectID);
        oTmp.addDateFilter(new DateFilter(date, after));
    }

    /** add a new date (interval) to filter for a given object */
    public void addDateFilter(String objectID, Date beginingDate, Date endingDate) {
	ObjectFilter oTmp = addObjectFilter(objectID);
        if (oTmp != null)
           oTmp.addDateFilter(new DateFilter(beginingDate, endingDate));
    }

    /** add a new date to filter for the whole messages */
    public void addDateFilter(ObjectFilter obj, DateFilter date) {
        if (obj != null)
           obj.addDateFilter(date);
    }

    //--------------------
    // Operations
    //--------------------
    private OperationFilter addanOperationFilter(String opName) {
	// doubles are not allowed because of possibly newly added attributeFilter on an Operation.
	if (opName != null) {
           boolean found = false;
	   ListIterator l = filteredOperations.listIterator(0);
           OperationFilter oTmp = null;
           while (!found && l.hasNext()) {
              oTmp = (OperationFilter)l.next();
              found = oTmp.getOperationName().equals(opName);
           }
           if (!found) {
              oTmp = new OperationFilter(opName);
              filteredOperations.add(oTmp);
           }
           return oTmp;
        } else {
           return null;
        }
    }

    /** add a new operation to filter for the whole system (globally) */
    public OperationFilter addOperationFilter(String operationName) {
	return (addanOperationFilter(operationName));
    }

    /** add a new operation to filter for a given object */
    public void addOperationFilter(OperationFilter op) {
        if (op != null)
           filteredOperations.add(op);
    }

    public OperationFilter addOperationFilter(String operationName, String attributeType, String attributeValue) {
	OperationFilter operationTmp = addanOperationFilter(operationName);
	if (operationTmp != null)
	   operationTmp.addAttributeFilter(new AttributeFilter(attributeType, attributeValue));
        return operationTmp;
    }

    public OperationFilter addOperationFilter(String operationName, int attributePosition, String attributeValue) {
	OperationFilter operationTmp = addanOperationFilter(operationName);
	if (operationTmp != null)
	   operationTmp.addAttributeFilter(new AttributeFilter(attributePosition, attributeValue));
        return operationTmp;
    }

    /** add a new operation to filter for a given object */
    public OperationFilter addOperationFilter(String objectID, String operationName) {
	ObjectFilter oTmp = addObjectFilter(objectID);
        if (oTmp != null)
           return (oTmp.addOperationFilter(operationName));
        else
           return null;
    }

    public OperationFilter addOperationFilter(ObjectFilter obj, String operationName) {
        if ((obj != null) && (operationName != null))
           return (obj.addOperationFilter(operationName));
        else
           return null;
    }

    public void addOperationFilter(ObjectFilter obj, OperationFilter op) {
        if ((obj != null) && (op != null))
           obj.addOperationFilter(op);
    }
    
    public OperationFilter addOperationFilter(String objectID, String operationName, String attributeType, String attributeValue) {
	ObjectFilter oTmp = addObjectFilter(objectID);
        OperationFilter operationTmp = null;
        if (oTmp != null) {
           operationTmp = oTmp.addOperationFilter(operationName);
           if (operationTmp != null)
              operationTmp.addAttributeFilter(new AttributeFilter(attributeType, attributeValue));
        }
        return operationTmp;
    }

    public OperationFilter addOperationFilter(String objectID, String operationName, int attributePosition, String attributeValue) {
	ObjectFilter oTmp = addObjectFilter(objectID);
        OperationFilter operationTmp = null;
        if (oTmp != null) {
           operationTmp = oTmp.addOperationFilter(operationName);
           if (operationTmp != null)
              operationTmp.addAttributeFilter(new AttributeFilter(attributePosition, attributeValue));
        }
        return operationTmp;
    }


    //--------------------
    // Message Types
    //--------------------
    public void addMessageTypeFilter(String objectID, String type) {
	ObjectFilter oTmp = addObjectFilter(objectID);
        if (oTmp != null)
           oTmp.addMessageTypeFilter(type);
    }

    public void addMessageTypeFilter(ObjectFilter obj, String type) {
        if (obj != null)
           obj.addMessageTypeFilter(MessageType.giveMessageType(type));
    }

    public void addMessageTypeFilter(String type) {
	filteredMessageTypes.add(MessageType.giveMessageType(type));
    }

    //===========================================================
    // Filter Application.
    //===========================================================

    /** applies this filter to a MessageCollection.
      * @returns a new MessageCollection */
    public MessageCollection applyFilter(MessageCollection messagesIn) {
        MessageCollection msgsRsl = (MessageCollection)messagesIn.clone();
        Iterator msgIt = msgsRsl.iterator();
        Message currentMessage;
        while (msgIt.hasNext()) {
             currentMessage = (Message)msgIt.next();
             if (! filterIsApplicable(currentMessage)) {
                msgIt.remove();
             }
        }
	return msgsRsl;
    }


    /** indicates whether this filter is applicable to the message given as parameter.
        (in other ways, returns true if the message must be kept)
        @param message : the message to test. */
    public boolean filterIsApplicable(Message m) {
// WARNING !  Date Filters are supposed not corrupted. Parsing should be aware of that before adding corrupted dates.
//            if all dates are corrupted in the list of date filters, this method consider the message NOT applicable.
//            (meaning this message would not appear) whereas it should ignore that to consider date filters are useless.
        // 1) filters message type
	boolean rsl = (filteredMessageTypes.size() == 0);
	ListIterator l;
        if (!rsl) {
            l = filteredMessageTypes.listIterator(0);
            while (!rsl && l.hasNext()) {
                rsl = (MessageType.giveMessageType((String)l.next()) == m.getMessageType()) && (m.getMessageType() != MessageType.NONE);
            }
        }
        // 2) filters dates
        if (rsl) {  // else is not allowed, whatever date filters are !
           rsl = (filteredDates.size() == 0);
	   if (!rsl) {
               l = filteredDates.listIterator(0);
               while (!rsl && l.hasNext()) {
                     rsl = ((DateFilter)l.next()).isAllowed(m);
               }
           }
        }
        // 3) filters operations
        if (rsl) {  // else is not allowed, whatever date filters are !
	  rsl = (filteredOperations.size() == 0);
	  if (!rsl) {
             l = filteredOperations.listIterator(0);
             while (!rsl && l.hasNext()) {
                rsl = ((OperationFilter)l.next()).isAllowed(m);
             }
	  }
	}
        // 4) filters objects
        if (rsl) {
           rsl = (filteredObjects.size() <= 0);
	   if (!rsl) {
              // for each ObjectFilter, check if it is applicable (until one is).
	      l = filteredObjects.listIterator(0);
	      while (!rsl && l.hasNext()) {
                 rsl = ((ObjectFilter)l.next()).isAllowed(m);
              }
           }
        }
        return rsl;
    }

    //===========================================================
    // Utility methods.
    //===========================================================

    /** indicates that this filter has nothing to filter (for now). */
    public boolean filterIsEmpty() {
        return (((filteredObjects == null) || (filteredObjects.size() == 0))
                && ((filteredDates == null) || (filteredDates.size() == 0))
                && ((filteredMessageTypes == null) || (filteredMessageTypes.size() == 0))
                && ((filteredOperations == null) || (filteredOperations.size() == 0)) );
    }

    //===========================================================
    // Printing methods.
    //===========================================================
    public String toString() {
	return toString(new IndentString());
    }

    public String toString(IndentString s) {
	s.append("<filter>\n");
	s.inc();
	printTypes(s);
	printDates(s);
	printMethods(s);
	printObjects(s);
	s.dec();
	s.append("</filter>\n");
	return s.toString();
    }

    protected void printTypes (IndentString s) {
	ListIterator l = filteredMessageTypes.listIterator(0);
	s.indent(); s.append("<messages_type>\n");
	s.inc();
	while (l.hasNext()) {
	    s.indent();
	    s.append("<type value=\""+((String)l.next())+"\"/>\n");
	}
	s.dec();
	s.indent(); s.append("</messages_type>\n");
    }

    protected void printDates (IndentString s) {
	ListIterator l = filteredDates.listIterator(0);
	s.indent(); s.append("<dates>\n");
	s.inc();
	while (l.hasNext()) {
	    ((DateFilter)l.next()).toString(s);
	}
	s.dec();
	s.indent(); s.append("</dates>\n");
    }

    protected void printMethods (IndentString s) {
	ListIterator l = filteredOperations.listIterator(0);
	s.indent(); s.append("<methods>\n");
	s.inc();
	while (l.hasNext()) {
	    ((OperationFilter)l.next()).toString(s);
	}
	s.dec();
	s.indent(); s.append("</methods>\n");
    }

    protected void printObjects (IndentString s) {
	ListIterator l = filteredObjects.listIterator(0);
	s.indent(); s.append("<objects>\n");
	s.inc();
	while (l.hasNext()) {
	    ((ObjectFilter)l.next()).toString(s);
	}
	s.dec();
	s.indent(); s.append("</objects>\n");
    }

}
