package corbaTrace.log2sequenceDiagram.log2svg;

import java.util.*;
import svgSequenceDiagramObjects.*;

//import corbaTrace.xmi.*;
import corbaTrace.log2sequenceDiagram.message.*;

import org.w3c.dom.*;
//import org.w3c.dom.svg.*;
import org.apache.batik.dom.util.DOMUtilities;
import org.apache.batik.dom.svg.SVGDOMImplementation;
import org.apache.batik.svggen.SVGGraphics2D;
import java.io.*;
import java.lang.reflect.Array;

/**
 * It's a class that generates svg files from entire (synchronized) parsed messages.
 *
 * @author jerome Limousin
 */
public class SvgGenerator {

	// general document
	private Document doc;
	// name of svg result file
	private String filename;
	// svg NS
	private String svgNS;
	// general svg sequence diagram document
	private SVGCorbaTraceDocument svgDoc;
	// list of begin activity message
	private Hashtable beginActivity;
	// list of end activity message
	private Hashtable endActivity;
	private ArrayList beginTemp;
	
	
	/**
	 * Constructor for SvgGenerator.
	 */
	public SvgGenerator() {

		// defaut file name
		filename = "testsvg.svg";
		//etape1: creation d'une instance du SVG Document Object Model(qui dit comment va etre organise le doc XML)
		DOMImplementation impl = SVGDOMImplementation.getDOMImplementation();
		//etape2: creation du document XML depuis le SVGDOM
		svgNS = SVGDOMImplementation.SVG_NAMESPACE_URI;
		doc = impl.createDocument(svgNS, "svg", null);
		Element svgRoot = doc.getDocumentElement();
		svgDoc = new SVGCorbaTraceDocument(svgNS, doc, svgRoot);
		beginActivity = new Hashtable();
		endActivity = new Hashtable();
		beginTemp = new ArrayList();
	}

	/** adds a whole collection of messages to current XMI tree. */
	public void addMessages(Object messages) {
		Iterator it;
		if (messages instanceof LinkedList) {
			// linkedList of synchronized messages
			it = ((LinkedList) messages).listIterator(0);
		} else { // else it's a MessageCollection (not synchronized - or at least not sorted)
			it = ((MessageCollection) messages).iterator();
		}
		EntireMessage msg;
		// for all messages
		while (it.hasNext()) {
			msg = (EntireMessage) it.next();
			// create svg symbol
			if(msg.isLocal()){
				if(msg.getMessageType().compareToIgnoreCase(MessageType.LOCAL_ACTIVITY_BEGIN)==0){
					beginTemp.add(msg.getSourceObjectId());
					if(!beginActivity.containsKey(msg.getSourceObjectId())){
						beginActivity.put(msg.getSourceObjectId(),new ArrayList());
					}
					((ArrayList)beginActivity.get(msg.getSourceObjectId())).add(msg);						
				}
				else{
					if(msg.getMessageType().compareToIgnoreCase(MessageType.LOCAL_ACTIVITY_END)==0){
						if(!endActivity.containsKey(msg.getSourceObjectId())){
							endActivity.put(msg.getSourceObjectId(),new ArrayList());
						}
						((ArrayList)endActivity.get(msg.getSourceObjectId())).add(msg);										
					}
					else{
						createLocalSymbol(msg);
					}
				}
			}
			else{
				createSVGAsynchronousCommunication(msg);
			}
		}
		createAction();
		
	}

	/** create svg symbole pour Local Object */
	public void createLocalSymbol(EntireMessage msg) {
		if(msg.getMessageType().compareToIgnoreCase(MessageType.LOCAL_CALL_BEGIN)==0){
			createSVGAsynchronousCommunication(msg);
		}
		else{
			if(msg.getMessageType().compareToIgnoreCase(MessageType.LOCAL_CALL_END)==0){
				createSVGAsynchronousCommunication(msg);
			}
			else{

					if(msg.getMessageType().compareToIgnoreCase(MessageType.LOCAL_TRACE)==0){
						createTraceSymbol(msg);
					}
				}
			}
		}
	
	
	
	
	/** create action symbol */
	public void createAction(){
		boolean exception = false;
		EntireMessage msg;
		ArrayList resultat = new ArrayList();
		ArrayList erreur = new ArrayList();
		boolean trouve = false;
		long time=0;
		for(int i=0;i<beginTemp.size();i++){
			if(((ArrayList)beginActivity.get(beginTemp.get(i))).size()==((ArrayList)endActivity.get(beginTemp.get(i))).size()&&((ArrayList)beginActivity.get(beginTemp.get(i))).size()!=0&&((ArrayList)endActivity.get(beginTemp.get(i))).size()!=0){
				Collections.sort((ArrayList)beginActivity.get(beginTemp.get(i)), new Comparator() {
					public int compare(Object o1, Object o2) {
						if(((EntireMessage) o1).getSendingMessageDate().getTime() > ((EntireMessage) o2).getSendingMessageDate().getTime()){
							return 1;
						}
						else{
							return 0;
						}
					}
				});
				Collections.sort((ArrayList)endActivity.get(beginTemp.get(i)), new Comparator() {
					public int compare(Object o1, Object o2) {
						if(((EntireMessage) o1).getSendingMessageDate().getTime() > ((EntireMessage) o2).getSendingMessageDate().getTime()){
							return 1;
						}
						else{
							return 0;
						}
					}
				});
				if(((EntireMessage)((ArrayList)beginActivity.get(beginTemp.get(i))).get(0)).getSendingMessageDate().getTime() < ((EntireMessage)((ArrayList)endActivity.get(beginTemp.get(i))).get(0)).getSendingMessageDate().getTime()){
					if(i+1<beginTemp.size()){
						if(((EntireMessage)((ArrayList)beginActivity.get(beginTemp.get(i+1))).get(0)).getSendingMessageDate().getTime() < ((EntireMessage)((ArrayList)endActivity.get(beginTemp.get(i))).get(0)).getSendingMessageDate().getTime()){
							((ArrayList)beginActivity.get(beginTemp.get(i))).remove(0);
							((ArrayList)endActivity.get(beginTemp.get(i))).remove(0);
							((ArrayList)beginActivity.get(beginTemp.get(i+1))).remove(0);
							((ArrayList)endActivity.get(beginTemp.get(i+1))).remove(0);
						}
						else{
							resultat.add((EntireMessage)((ArrayList)beginActivity.get(beginTemp.get(i))).get(0));
							resultat.add((EntireMessage)((ArrayList)endActivity.get(beginTemp.get(i))).get(0));
							((ArrayList)beginActivity.get(beginTemp.get(i))).remove(0);
							((ArrayList)endActivity.get(beginTemp.get(i))).remove(0);
						}
					}
					else{
						resultat.add((EntireMessage)((ArrayList)beginActivity.get(beginTemp.get(i))).get(0));
						resultat.add((EntireMessage)((ArrayList)endActivity.get(beginTemp.get(i))).get(0));
						((ArrayList)beginActivity.get(beginTemp.get(i))).remove(0);
						((ArrayList)endActivity.get(beginTemp.get(i))).remove(0);
					}
				}
				else{
					((ArrayList)beginActivity.get(beginTemp.get(i))).remove(0);
					((ArrayList)endActivity.get(beginTemp.get(i))).remove(0);
				}
			}
		} 
		for(int j=0;j<resultat.size();j=j+2){
			svgDoc.addAction(((EntireMessage)resultat.get(j)).getSourceObjectId(),((EntireMessage)resultat.get(j)).getSendingMessageDate().getTime(),((EntireMessage)resultat.get(j+1)).getSendingMessageDate().getTime()-((EntireMessage)resultat.get(j)).getSendingMessageDate().getTime());
		}
		
	}
	
	/** create trace symbol */
	public void createTraceSymbol(EntireMessage msg) {
		svgDoc.addComment(msg.getSourceObjectId(),msg.getSendingMessageDate().getTime(),msg.getOperationName());
	}
	
	/** create svg message */
	public void createSVGAsynchronousCommunication(EntireMessage msg) {
		if(msg.getMessageType().equalsIgnoreCase(MessageType.REQUEST)||msg.getMessageType().equalsIgnoreCase(MessageType.LOCAL_CALL_BEGIN)||msg.getMessageType().equalsIgnoreCase(MessageType.EXCEPTION)){
			svgDoc.addMessage(msg.getSourceObjectId(),msg.getSendingMessageDate().getTime(),msg.getDestinationObjectId(),msg.getReceivingMessageDate().getTime(),msg.getOperationName()+"("+msg.getArgumentsValues()+")");
		}
		else{
			if(msg.getMessageType().equalsIgnoreCase(MessageType.BROKEN_REQUEST)){
				svgDoc.addMessage("NULL",msg.getSendingMessageDate().getTime(),msg.getDestinationObjectId(),msg.getReceivingMessageDate().getTime());
			}
			else{
				if(msg.getMessageType().equalsIgnoreCase(MessageType.BROKEN_REPLY)){
					svgDoc.addMessage(msg.getSourceObjectId(),msg.getSendingMessageDate().getTime(),"NULL",msg.getReceivingMessageDate().getTime());			
				}
				else{
					
					svgDoc.addMessage(msg.getSourceObjectId(),msg.getSendingMessageDate().getTime(),msg.getDestinationObjectId(),msg.getReceivingMessageDate().getTime());
				}
			}
		}
	}

	/** save the svg file */
	public void save(String fileName,float scale) {
		try {
			svgDoc.createSVGFrame(scale);
			PrintWriter writer =
			new PrintWriter(new FileOutputStream(fileName));
			DOMUtilities.writeDocument(doc, writer);
			writer.flush();
			writer.close();
		} catch (IOException exp) {
			exp.printStackTrace();
		}
	}

}
