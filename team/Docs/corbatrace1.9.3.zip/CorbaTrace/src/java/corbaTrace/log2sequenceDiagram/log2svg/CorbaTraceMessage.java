package corbaTrace.log2sequenceDiagram.log2svg;

/**
 * CorbaTraceMessage records information of a corba trace message 
 *
 * @author FRANCHETEAU Aurelien
 */

public class CorbaTraceMessage{

    
    private String sender;
    private String receiver;
    private String txt;
    private long timeSender;
    private long timeReceiver;

    
    public CorbaTraceMessage(String sender,String receiver,String txt,long timeSender,long timeReceiver){
	this.sender = sender;
	this.receiver = receiver;
	this.txt = txt;
	this.timeSender = timeSender;
	this.timeReceiver = timeReceiver;
    }
    //===========================================================
    // Access Methods
    //===========================================================
    public String getSender(){
	return sender;
    }

    public String getReceiver(){
	return receiver;
    }
    public String getText(){
	return txt;
    }
    public long getTimeSender(){
	return timeSender;
    }
    public long getTimeReceiver(){
	return timeReceiver;
    }
    public void setTimeSender(long time){
	timeSender = time;
    }
    public void setTimeReceiver(long time){
	timeReceiver = time;
    }
}
