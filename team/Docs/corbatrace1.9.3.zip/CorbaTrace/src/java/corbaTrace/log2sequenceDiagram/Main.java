package corbaTrace.log2sequenceDiagram;

/**
 * CorbaTrace log2xmi tool.
 * (main class)
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */

public class Main {
	
    public static void main(String argv[]) {

	String outputFile = "out";    	
	boolean makeXmiFile = false;
	boolean makeTexFile = false;
	boolean makeSvgFile = false;
	
        if ((argv.length <= 0) || (argv[0].equals("--h")) ||
        	(argv[0].equals("--help")) || (argv[0].equals("/?"))) {
            
            System.out.println("\nUsage: log2xmi [options] <XML logs>\n"
			       + "\noptions:  -o <file>  ... output prefix filename (\"out\") by default"
			       + "\n          -f <file>  ... apply this filter file before generating messages"
			       + "\n          -x{rm}     ... generate XMI file (*.xmi)"
			       + "\n                          r: add Rational Rose extension"
			       + "\n                          m: add Magic Draw extension"
			       + "\n          -t         ... generate TeX file (*.tex)"			       
			       + "\n          -s         ... generate SVG file (*.svg)"			       			       
			       + "\n          -v         ... do not validate XML logs with DTD (use only well formed logs)"
			       + "\n          -s         ... do not synchronize object's clock."
			       + "\n          -d         ... debug mode"
			       + "\n\nExample :  generate xmi as \"afile.xml\" with rose & mdraw extensions from logs :"
			       + "\n              log2xmi -o afile -xrm obj1_CTrace.xml obj2_STrace.xml\n");

            System.exit(1);
        }

		Log2SequenceDiagram l2sd = new Log2SequenceDiagram();
					
		int beginningFiles = 0;	
		
		while (argv.length > beginningFiles) {
		    if (argv[beginningFiles].equals("-o")) {
				beginningFiles++;
				if (beginningFiles <= argv.length) {
					outputFile = argv[beginningFiles];
				}
				beginningFiles++;
			} else if (argv[beginningFiles].equals("-f")) {
				beginningFiles++;
				if (argv.length > beginningFiles) {
				    l2sd.setFilterFile(argv[beginningFiles]);
				} else {
				    System.err.println("\n>>> Warning (option -f) : no filter file given !");
				}
				beginningFiles++;
		    } else if ((argv[beginningFiles].startsWith("-x")) && (argv[beginningFiles].length()>=3)) {
                makeXmiFile = true;
                for (int i=2; i<=argv[beginningFiles].length()-1; ++i) {
                   switch (argv[beginningFiles].charAt(i)) {
                      case 'r' :
		                    l2sd.addRationalRoseExtension(true);
                      		break;
                      case 'm' :
		                    l2sd.addMagicDrawExtension(true);
                      		break;
                      default :
                      		makeXmiFile = false;
                      		System.err.println(" >>> Error : option -x" + argv[beginningFiles].charAt(i) + " is not defined.");
                	}
				}
				beginningFiles++;
		    } else if (argv[beginningFiles].equals("-t")) {
                makeTexFile = true;
				beginningFiles++;
		    } else if (argv[beginningFiles].equals("-s")) {
                makeSvgFile = true;
				beginningFiles++;
		    } else if (argv[beginningFiles].equals("-v")) {
				l2sd.valideXMLFiles(false);
				beginningFiles++;
		    } else if (argv[beginningFiles].equals("-s")) {
				l2sd.synchronize(false);
				beginningFiles++;
		    } else if (argv[beginningFiles].equals("-d")) {
				l2sd.debug(true);
				beginningFiles++;
		    } else {
				l2sd.addInputFile(argv[beginningFiles]);
				beginningFiles++;
		    }
		}
	
		l2sd.processAll();
		
		if(makeXmiFile) {
			l2sd.generateXmiFile(outputFile + ".xmi");
		}
		if(makeTexFile) {
			l2sd.generateTexFile(outputFile + ".tex");
		}
		if(makeSvgFile) {
			l2sd.generateSvgFile(outputFile + ".svg");
		}
		
        System.exit(0);
    }    
}


