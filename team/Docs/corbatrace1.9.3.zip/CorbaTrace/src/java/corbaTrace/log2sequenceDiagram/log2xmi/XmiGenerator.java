package corbaTrace.log2sequenceDiagram.log2xmi;

import java.util.*;

import corbaTrace.xmi.*;
import corbaTrace.log2sequenceDiagram.message.*;

/**
 * It's a class that generates xmi files from entire (synchronized) parsed messages.
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public class XmiGenerator {

    // --------------------------------------------------------------------------------
    // NOTE TO DEVELOPPERS :
    // to add a new extension :  1) adds a new constant below and its boolean (IF NEEDED-see below)
    //                           2) modify addExtensionsToXmiDocument()
    //                           3) modify setExtension()
    //                           4) modify Main class too of course.
    //
    // For now, extensions can be combined (rose and mdraw), so boolean attributes are used.
    // If for some reason they shouldn't, or if you add other extensions that are not compatibles
    // (meaning that users must indicate only one of them at a time),
    // you should rather use an "short" attribute with the current value as your XXX_EXTENSION, or YYY_EXNTION, or NONE 
    // if optional extension is allowed (of course you do what you want, this is just a suggestion :-)
    // Then use a "switch/case" in addExtensionsToXmiDocument() rather than a if...then.
    // We used that before we succeed in adding both magic draw and rose extensions without conflict.
    // --------------------------------------------------------------------------------

    /** some constants are used to set xmi output file properties :
     *  NONE, ROSE_EXTENSION, MAGICDRAW_EXTENSION
     */

    // extensions
    public static final int NONE = 0;
    public static final int ROSE_EXTENSION = 1;
    public static final int MAGICDRAW_EXTENSION = 2;

    private boolean roseExtension;
    private boolean mdrawExtension;

    // default values
    public static final String DEFAULT_OUTPUT_FILENAME = new String("out.xml");
    public static final String DEFAULT_XMI_MODEL_NAME = new String("CorbaTrace");

    private String outputfile; // output filename.
    private int nbGeneratedMessages; // at least one message to generate.

    // XMI stuff.
    private XmiDocument xmiDocument; // root of our XMI tree.
    private XmiModel xmiModel; // current xmi model.
    private Hashtable definedObjects; // to know objects already encountered.
    private Hashtable definedClasses; // to know classes (and their operations) already encountered.
    private Hashtable definedDataTypes; // to know parameter's dataType already encountered.

    // debugging stuff
    private boolean debug;

    // XXXXXXXXXXXXXXXXXXXXXXXXXX
    // TO CHANGE ???????
    // => xmi package considers one model by document.
    // but :  - what to use ?  a model is created with a document as parameter, and a model is added to a document.
    //                         => no accessors are sets: get a document from a model - OR - get a model form a document !!
    //        - maybe we'd like to have more than one model later (so var xmiModel is our current model)

    // -------------------------------------------------------------------
    /**
      * some constructors : with an extension option (NONE by default) and/or an output filename.
      * @param outfile is the name of the xmi output file.
      * @param outfile is the name of the xmi output file.
      */
    public XmiGenerator(String outfile, int extension) {
        clearAll();
        setExtension(extension);
        outputfile = outfile;
        debug = false;
    }

    public XmiGenerator() {
        this(DEFAULT_OUTPUT_FILENAME, NONE);
    }

    public XmiGenerator(String outfile) {
        this(outfile, NONE);
    }

    public XmiGenerator(int extension) {
        this(DEFAULT_OUTPUT_FILENAME, extension);
    }

    public void setDebugMode(boolean moreInfos) {
        debug = moreInfos;
    }

    // -------------------------------------------------------------------
    /** xmi tree building methods. */
    private void clearAll() {
        xmiDocument = new XmiDocument(); // create the XMI document that will be generated 
        xmiModel = null;
        roseExtension = false;
        mdrawExtension = false;
        definedObjects = new Hashtable();
        definedClasses = new Hashtable();
        definedDataTypes = new Hashtable();
        nbGeneratedMessages = 0;
    }

    /** defines a new model for this XMI file */
    public void newXMIModel(String xmiModelName) {
        if ((xmiModelName != null) && (xmiModelName.length() > 0))
            xmiModel = new XmiModel(xmiDocument, xmiModelName);
        else
            xmiModel = new XmiModel(xmiDocument, DEFAULT_XMI_MODEL_NAME);
        xmiDocument.addModel(xmiModel);
        xmiModel.addSequenceDiagram(new XmiSequenceDiagram(xmiDocument, "Sequence Diagram"));
    }

    /** adds a whole collection of messages to current XMI tree. */
    public void addAllMessages(Object messages) {
        if (debug) {
            System.out.println(
                "\n\n ============================================================"
                    + "\n =================== messages to generate ===================\n");
        }
        Iterator it;
        if (messages instanceof LinkedList) { // linkedList of synchronized messages
            it = ((LinkedList) messages).listIterator(0);
        } else { // else it's a MessageCollection (not synchronized - or at least not sorted)
            it = ((MessageCollection) messages).iterator();
        }
        EntireMessage msg;
        while (it.hasNext()) {
            msg = (EntireMessage) it.next();
            if (debug) {
                System.out.println(msg);
            }
            addXmiMessage(msg); // adds XMI message
        }
        if (debug) {
            System.out.println("\n\n\n =================================================================\n\n");
        }
    }

    /** adds a new message to current XMI tree. */
    private void addXmiMessage(EntireMessage m) {
    	//skip local messages
    	if(m.isLocal()) return;
    	
        if (xmiModel == null)
            newXMIModel(DEFAULT_XMI_MODEL_NAME);
        // XXXXXX Warning : method to be improved !!!!
        // At the moment : we need to memorize all to be able to add an operation (because of doubles not managed by xmi classes themselves).
        // It's a bit more complicated...
        String srcIdObject = m.getSourceObjectId();
        String destIdObject = m.getDestinationObjectId();
        XmiClassifierRole destRole = null, srcRole = null;
        XmiClass destClass = null, srcClass = null; // for adding new classes & roles
        // check whether our communicating objects (class instances) are already defined.
        if (srcIdObject != null) {
            srcRole = (XmiClassifierRole) definedObjects.get(srcIdObject);
            srcClass = (XmiClass) definedClasses.get(srcIdObject);
        }
        if (destIdObject != null) {
            destRole = (XmiClassifierRole) definedObjects.get(destIdObject);
            destClass = (XmiClass) definedClasses.get(destIdObject);
        }

        //XXXXXX what class name to use ?????

        // adds the new roles & classes if necessary
        if ((srcRole == null) && (srcIdObject != null)) {
            // object has not been defined in this XMI document : we add a new class & a new instance (role).
            srcClass = new XmiClass(xmiDocument, srcIdObject);
            xmiModel.addClass(srcClass);
            definedClasses.put(srcIdObject, srcClass); // adds the new class
            srcRole = new XmiClassifierRole(xmiDocument, srcIdObject, srcClass);
            ;
            xmiModel.getSeqDiag().addClassifierRole(srcRole);
            // adds this role to the diagram sequence of this xmiModel
            definedObjects.put(srcIdObject, srcRole); // adds the new role
        }
        if ((destRole == null) && (destIdObject != null)) {
            // object has not been defined in this XMI document : we add a new class & a new instance (role).
            destClass = new XmiClass(xmiDocument, destIdObject);
            xmiModel.addClass(destClass);
            definedClasses.put(destIdObject, destClass); // adds the new class
            destRole = new XmiClassifierRole(xmiDocument, destIdObject, destClass);
            ;
            xmiModel.getSeqDiag().addClassifierRole(destRole);
            // adds this role to the diagram sequence of this xmiModel
            definedObjects.put(destIdObject, destRole); // adds the new role
        }

        // find for which object the operation is available : for the destination object or for the source object ?
        XmiOperation opTmp = null;
        if (MessageType.operationIsAvailableOnSourceObject(m.getMessageType())) {
            if (srcClass != null)
                opTmp = getXmiOperation(srcClass, m);
        } else { // this operation is the destination one
            if (destClass != null)
                opTmp = getXmiOperation(destClass, m);
        }

        if (opTmp != null) {
            // creates an action for this message & operation
            //XXXXXXX it creates one new action by new message (not really optimum...)
            XmiCallAction actionTmp = new XmiCallAction(xmiDocument, "action", opTmp);
            xmiModel.addCallAction(actionTmp);

            // adds the message m to this sequence diagram.
            xmiModel.getSeqDiag().addMessage(
                new XmiMessage(xmiDocument, m.getMessageId(), srcRole, destRole, actionTmp, null));
            nbGeneratedMessages++;
        }
    }

    // -------------------------------------------------
    /** get XmiOperation in current Xmi Tree for this message operation (and create it if necessary)
      * @param xmiclass : the current class and all its operations.
      * @param m : message to test.
      * @return : the XmiOperation newly added (null if add was not possible)
      */
    private XmiOperation getXmiOperation(XmiClass xmiclass, Message m) {
        XmiOperation opTmp = null;
        // our message operation name and its args.
        String opNameToAdd = m.getOperationName();
        LinkedList lArgsToAdd = m.getOperationArguments();
        if (opNameToAdd != null) {
            Vector ops = xmiclass.getOperations();
            // we get operations vector (already added) for this class.
            boolean exit = false;
            if (ops.size() > 0) {
                // we check if it's already defined for this class.
                int cpt = ops.size() - 1;
                // while we don't find this operation (if already added) and we don't reach the end of operations already added,
                // we test our message operation to current added operation for this class.
                while (!exit && (cpt >= 0)) {
                    opTmp = (XmiOperation) (ops.elementAt(cpt));
                    exit = operationAlreadyAdded(opNameToAdd, lArgsToAdd, opTmp);
                    // tests if this message operation has already been added.
                    cpt--;
                }
            } // else no operation for this class : we necesserily add it (exit=false).
            if (!exit) { // we definitively add this new operation to current XmiDocument.
                opTmp = addOperation(xmiclass, opNameToAdd, lArgsToAdd);
            } // else : operation already defined.
        }
        return opTmp;
    }

    /** test if operation (defined by opName and its list lArgs of attributes (MessageOption list))
      * is equal to current operation.
      */
    private boolean operationAlreadyAdded(String opName, LinkedList lArgs, XmiOperation operation) {
        // 1) we test operation names.
        boolean rsl = opName.equals(operation.getName()); // warning :  test is case sensitive !
        // 2) if true, tests all its attributes (supposed in same order)
        //    until two don't fit.
        if (rsl) {
            Vector operationParameters = operation.getParameters();
            // 2a) tests number arguments
            if (lArgs == null) // can be a problem...
                lArgs = new LinkedList();
            rsl = (lArgs.size() == operationParameters.size());
            if (rsl) { // same size : we check more deeply.
                // we take args one by one and we test them one to each other.
                MessageOption argTmp;
                XmiParameter paramTmp;
                ListIterator itArg = lArgs.listIterator(0);
                int paramCounter = 0;
                String argName;
                while (rsl && (paramCounter < operationParameters.size())) {
                    // take 1st argument from message (MessageOption)
                    argTmp = (MessageOption) itArg.next();
                    // take 1st parameter from CmiOperation (XmiParameter)
                    paramTmp = (XmiParameter) operationParameters.elementAt(paramCounter);
                    // don't test name if null;
                    // type
                    rsl = ((String) argTmp.getPropertyValue("type")).equals(paramTmp.getDatatype().getName());
                    // case sensitive
                    if (rsl) {
                        // inout
                        rsl = ((String) argTmp.getPropertyValue("inout")).equalsIgnoreCase(paramTmp.getInout());
                        // NOT case sensitive
                        if (rsl) {
                            // name
                            argName = (String) argTmp.getPropertyValue("name");
                            if (argName != null) {
                                rsl = argName.equals(paramTmp.getName()); // case sensitive
                            }
                        }
                    }
                    paramCounter++; // next parameter
                } // end while
            } // else they are different operations.
        }
        return rsl;
    }

    /** add a new XmiOperation to current XmiDocument.
      * @param msg : the message from which an operation is created.
      * @return : this XmiOperation newly added (null if add was not possible)
      */
    private XmiOperation addOperation(XmiClass xmiclass, String operationName, LinkedList lArgs) {
        XmiOperation opRsl = null;
        if (operationName != null) {
            // 1) we create a new XmiOperation
            opRsl = new XmiOperation(xmiDocument, operationName);
            // 2) for each args of this operation, we add them too.
            MessageOption argTmp;
            if (lArgs != null) {
                ListIterator itArg = lArgs.listIterator(0);
                XmiParameter parameterTmp;
                String argName, argType, argInOut;
                XmiDatatype datatypeTmp;
                int currentArgNb = 1;
                while (itArg.hasNext()) {
                    argTmp = (MessageOption) itArg.next();
                    argType = (String) argTmp.getPropertyValue("type");
                    argName = (String) argTmp.getPropertyValue("name");
                    // gets the datatype if already added. Else create one new.
                    datatypeTmp = (XmiDatatype) definedDataTypes.get(argType);
                    if (datatypeTmp == null) { // we create one new
                        datatypeTmp = new XmiDatatype(xmiDocument, argType);
                        xmiModel.addDatatype(datatypeTmp);
                        definedDataTypes.put(argType, datatypeTmp);
                    }

                    // as name is optional it could be null. But XmiParameter doesn't allow null name.
                    // so we create one if needed, based on type name + this argument number.
                    if ((argName == null) || (argName.length() <= 0))
                        argName = argType + "_" + currentArgNb;
                    argInOut = (String) argTmp.getPropertyValue("inout");
                    parameterTmp = new XmiParameter(xmiDocument, argName, argInOut, datatypeTmp);
                    // we add this argument
                    opRsl.addArgument(parameterTmp);
                    currentArgNb++; // one argument more.
                }
            }
        } // else return null (operation can't be added)
        if (opRsl != null) // we add it definitively to the class.
            xmiclass.addOperation(opRsl);

        return opRsl;
    }

    // -------------------------------------------------------------------
    /** output methods */

    public void setOutputFilename(String outfile) {
        outputfile = outfile;
    }

    // !! options are considered ONLY before output it to file,
    //    because each option alters Xmi tree (and it's simpler to generate it one time
    //    when saving to file, rather than deleting it each time we change extension !)
    //    there should be a bug anyway when a file has been saved with an extension (let's say rose one for ex.),
    //    and then if a new extension is set a 2nd time (without clearing all the document),
    //    old extensions are still in the tree.
    //    improvment => Think to add a "delete extension" process in xmi package (if needed).
    public void setExtension(int extension) {
        switch (extension) {
            case ROSE_EXTENSION :
                roseExtension = true;
                break;
            case MAGICDRAW_EXTENSION :
                mdrawExtension = true;
                break;
        } // else : nothing to set.
    }

    /** save current built XMI tree to file (defined by setOutputFilename() or DEFAULT_OUTPUT_FILENAME by default) */
    public void saveFile() {
        if ((outputfile == null) || (outputfile.length() <= 0))
            setOutputFilename(DEFAULT_OUTPUT_FILENAME);
        if (xmiModel == null) // in that case, the document is empty (not very useful...)
            newXMIModel(DEFAULT_XMI_MODEL_NAME);
        if (nbGeneratedMessages > 0) {
            System.out.println(
                ">>> "
                    + nbGeneratedMessages
                    + " message"
                    + (nbGeneratedMessages > 1 ? "s have" : " has")
                    + " been generated.");
            // sets extensions (definitively)
            addExtensionsToXmiDocument();
            // save Xmi tree in a file
            xmiDocument.writeToFile(outputfile);
            System.out.println(">>> file " + outputfile + " saved on disk\n");
        } else {
            System.out.println(">>> no message to generate. File " + outputfile + " not saved.\n");
        }
    }

    /** save current built XMI tree to file.
        @param outfile : the filename (and its path) */
    public void saveFile(String outfile) {
        setOutputFilename(outfile);
        saveFile();
    }

    /** sets extensions definitively to generated Xmi tree before saving it to file. */
    private void addExtensionsToXmiDocument() {
        if (roseExtension) {
            xmiDocument.createRoseExtensions();
            System.out.println(">>> Rational Rose extensions added.");
        }
        if (mdrawExtension) {
            xmiDocument.createMagicDrawExtensions();
            System.out.println(">>> Magic Draw extensions added.");
        } // else : nothing to add.
    }

}
