package corbaTrace.log2sequenceDiagram.Merger;

import java.util.*;

import corbaTrace.log2sequenceDiagram.message.*;


/**
 * This is just a class devoted to merge all incomplete messages in memory
 * (which are parsed in the previous step), while trying to link source part of the
 * message with its destination part.
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 * @author sebastien Helbert
 */
public class LogMerger {

    /** attributes :   - MessageCollection of half-messages (source or destination) still to complete.
     *                 - MessageCollection of entire messages.
     *                 - hasToBeMerged is true anytime a new half-message is added to indicate to do a new merging process.
     */
    private MessageCollection localMsgs, corbaSrcMsgs, corbaDestMsgs;
    private MessageCollection entireMsgs;
    private boolean hasToBeMerged;

    public LogMerger () {
       clearAll();
    }

    /**
     * sets new Collection of messages (reinit everything with them)
     */
    public void initialize(MessageCollection local, MessageCollection sources, MessageCollection destinations) {
         localMsgs = local;
         corbaSrcMsgs = sources;
         corbaDestMsgs = destinations;
         entireMsgs = new MessageCollection();
         hasToBeMerged = true;
    }

    public MessageCollection localMessages() {
		return (MessageCollection)localMsgs.clone();
    }
    
    public MessageCollection getHalfSourceMessages() {
		return (MessageCollection)corbaSrcMsgs.clone();
    }

    public MessageCollection getHalfDestinationMessages() {
		return (MessageCollection)corbaDestMsgs.clone();
    }

    /** gets EntireMessages correctly parsed.
      * @param addsBrokenMessage tells whether half-messages should also be added as "broken" entire messages.
      */
    public MessageCollection getEntireMessages(boolean addsBrokenMessage) {
		Iterator it;
		MessageCollection rsl = (MessageCollection)entireMsgs.clone();
        if (addsBrokenMessage) {  // we add half sources and destination messages too
             it = localMsgs.iterator();
             while (it.hasNext()) {
                  rsl.addMessage(new EntireMessage((LocalMessage)it.next()));
	         }
             
             it = corbaSrcMsgs.iterator();
             while (it.hasNext()) {
                  rsl.addMessage(new EntireMessage((HalfMessageSource)it.next()));
             }
             
             it = corbaDestMsgs.iterator();
             while (it.hasNext()) {
                  rsl.addMessage(new EntireMessage((HalfMessageDestination)it.next()));
             }
        }
        return rsl;
    }

    /**
     * destroy entire messages built while merging.
     */
    public void clearEntireMessages() {
         entireMsgs = new MessageCollection();
    }

    /**
     * clean all messages in memory (half or not).
     */
    public void clearAll() {
         localMsgs = new MessageCollection();
         corbaSrcMsgs = new MessageCollection();
         corbaDestMsgs = new MessageCollection();
         entireMsgs = new MessageCollection();
         hasToBeMerged = false;
    }



    //===========================================================
    // Merging method
    //===========================================================

    /**
     * process the Merging at current state of messages.
     */
    public void mergeAll() {
		// principle :
		//
		// At first, we consider every request messages, because they are full of data.
		// Then we consider reply and exception that we complete with usefull data
		// contained in linked request.
		// For each destination message, we try to find the corresponding source
		// message in half-message sources collection.
		// If found, the two half messages are deleted and a new complete one is added
		// to entire messages collection.
		ListIterator objectTmp = null;
		ListIterator destMsg = null;
		ListIterator srcMsg = null;
	
	    Message entMsg = null;
		
	    Iterator it = localMsgs.iterator();
		while (it.hasNext()) {
        	entireMsgs.addMessage(new EntireMessage((LocalMessage)it.next()));
	    }
        localMsgs.clear();
		// At first, we try to merge parts of every request messages
		objectTmp = corbaDestMsgs.getObjectsIterator();
		while(objectTmp.hasNext()) {
	        destMsg = ((ObjectMessage) objectTmp.next()).getMessagesIterator();
	        while(destMsg.hasNext()) {
	            entMsg = mergeRequestWithDestination((HalfMessageDestination)destMsg.next());
	            if (entMsg != null) {
	                 // entire message has been created.
	                 // this half message is now useless (iterator is on it),
	                 // so we delete it. Then we add newly created entire message 
	                 // to the right collection (entireMessages).
	                 destMsg.remove();
	                 entireMsgs.addMessage(entMsg);
	            }
	        }
	   	}
		
		// Then, we try to merge parts of every others messages (local requests, reply and exceptions)
		// Because the server have more information than the client we analyse this time
		// source message list.
		objectTmp = corbaSrcMsgs.getObjectsIterator();
	   	while(objectTmp.hasNext()) {
		    srcMsg = ((ObjectMessage)objectTmp.next()).getMessagesIterator();
		    while(srcMsg.hasNext()) {
				entMsg = mergeOthersWithSource((HalfMessageSource)srcMsg.next());
		        if (entMsg != null) {
				    // entire message has been created.
				    // this half message is now useless (iterator is on it),
				    // so we delete it. Then we add newly created entire message 
				    // to the right collection (entireMessages).
				    srcMsg.remove();
				    entireMsgs.addMessage(entMsg);
		        }
	        }
	   	}
	   	hasToBeMerged = false;
	}



    /** 
     *   method "mergeRequestWithDestination"
     * try to find the source part of a request message.
     * and if found, delete that part from the list and return a merged Message
     * of the two parts.
     * @param the source of the incomplete message
     * @return null if destination part of this source message is not found
     */
    // If message type is a Receive Request, we know destination part of that message
    // has its "sourceObjectID" and "sendingDate" at the same value as the source part 
    // we are trying to locate.
    // We also use messageID to locate more precisely (and quickly) this message.
    // Others type of message are ignored.
    
    private EntireMessage mergeRequestWithDestination(HalfMessageDestination destination) {
		EntireMessage entMsg = null;
		if (destination.getMessageType() == MessageType.RECEIVE_REQUEST) {
		    // 1) we KNOW the sourceObjectID and sendingDate
		    String searchedSourceObjectId = destination.getSourceObjectId();
		    
		    // 2) we try to locate the objectID
		    ObjectMessage srcObject = corbaSrcMsgs.getObject(searchedSourceObjectId);
		    HalfMessageSource srcTmp = null;
		    
		    if (srcObject != null) {
				ListIterator srcMsg = srcObject.getMessagesIterator();
				boolean found = false;
			    while(!found && srcMsg.hasNext()) {
					srcTmp = (HalfMessageSource)srcMsg.next();
					found = (destination.compareTo(srcTmp) == 0);
			    }
			    // yes : it fits !
			    if (found) {
					// we delete the half-source message from the collection
					srcMsg.remove();
					
					// we merge them and creates the new entire message
					entMsg = new EntireMessage(srcTmp, destination);
			    }
		    } // else this objectID was not found : we can't complete the message.
		}
		return entMsg;
    }


    /** 
     * try to find the destination part of any local request, reply or exception message.
     * and if found, delete the two parts from the lists and return a merged Message.
     * @param the source of the incomplete message
     * @return null if source part of this source message is not found
     */
	// In this method every non local message is linked to a request message.
    // If message type is a sending reply, we know that "distantObjectID" and
    // "distantMessageId" have the same value
    private EntireMessage mergeOthersWithSource(HalfMessageSource srcMsg) {
		EntireMessage entMsg = null;
		
		// Merge EMIT_LOCAL_MESSAGE and RECEIVE_LOCAL_MESSAGE messages
		
		if (srcMsg.getMessageType() == MessageType.LOCAL_CALL_BEGIN) {
			
		    // 1) we KNOW the sourceObjectID and sendingDate
		    String expectedDestObjectId = srcMsg.getDestinationObjectId();
//seb		    System.out.println(srcMsg.toString() + "\n ---------> " + expectedDestObjectId);
		    // 2) we try to locate the objectID
		    ObjectMessage destObject = corbaDestMsgs.getObject(expectedDestObjectId);
		    HalfMessageDestination destTmp = null;
		//seb	System.out.println(" ---------> 1");		    
		    if (destObject != null) {
   	//seb			System.out.println(" ---------> 2");		    
				ListIterator destMsg = destObject.getMessagesIterator();
				boolean found = false;
				if (destMsg != null) {		    
				    while(!found && destMsg.hasNext()) {
						destTmp = (HalfMessageDestination)destMsg.next();
						// we compare request_id of the two parts
						
	   					//seb System.out.println(" ---------> " + destTmp.getDestinationObjectId());
						
						if (destTmp.getMessageType() == MessageType.LOCAL_CALL_END) {
						    found = srcMsg.getDestinationObjectId().equals(destTmp.getDestinationObjectId());			      
						}
						
				    }

					if (found) {
					    // we delete the half-source message from the collection
					    destMsg.remove();
					    // we merge them and creates the new entire message
					    entMsg = new EntireMessage(srcMsg, destTmp);
					}
				} // else the other part is not found, we can't complete the message
			}
			
			return entMsg;
		}
		
		// Merge SEND_REPLY and RECEIVE_REPLY messages
		if (srcMsg.getMessageType() == MessageType.SEND_REPLY) {
		    // 1) we KNOW the sourceObjectID and sendingDate
		    String expectedDestObjectId = srcMsg.getDestinationObjectId();
		    // 2) we try to locate the objectID
		    ObjectMessage destObject = corbaDestMsgs.getObject(expectedDestObjectId);
		    HalfMessageDestination destTmp = null;
		    
		    if (destObject != null) {
				ListIterator destMsg = destObject.getMessagesIterator();
				boolean found = false;
				if (destMsg != null) {
				    while(!found && destMsg.hasNext()) {
						destTmp = (HalfMessageDestination)destMsg.next();
						// we compare request_id of the two parts
						if (destTmp.getMessageType() == MessageType.RECEIVE_REPLY) {
						    found = srcMsg.getDestinationObjectId().equals(destTmp.getDestinationObjectId());			      
						}
				    }

					if (found) {
					    // we delete the half-source message from the collection
					    destMsg.remove();
					    // we merge them and creates the new entire message
					    entMsg = new EntireMessage(srcMsg, destTmp);
					}
				} // else the other part is not found, we can't complete the message
			}
			return entMsg;
		}
		
		// case of an EXCEPTION MESSAGE
		if (srcMsg.getMessageType() == MessageType.SEND_EXCEPTION) {
			// Merge with the other part
			System.out.println("Exception");
			return entMsg;		    
		}
		
		return entMsg;
    }

    //===========================================================
    // Some useful methods (to give some status infos)
    //===========================================================

    public int getNbLocalMessages() {
		return localMsgs.getNbMessages();
    }
    
    public int getNbIncompleteSourceMessages() {
		return corbaSrcMsgs.getNbMessages();
    }

    public int getNbIncompleteDestinationMessages() {
		return corbaDestMsgs.getNbMessages();
    }

    public int getNbCompleteMessages() {
		return entireMsgs.getNbMessages();
    }

    /**
     * just to print the current state of merging process.
     */
    public String showInfos(boolean moreInfos) {
        StringBuffer rsl = new StringBuffer("");
        int nblocal = getNbLocalMessages(),
        	nbsrc = getNbIncompleteSourceMessages(),
            nbdest = getNbIncompleteDestinationMessages(),
            nbentire = getNbCompleteMessages();

        if (moreInfos) { // we add more infos.

            rsl.append(
                "============= local messages ====================================\n" +
                localMsgs.toString() + "\n");        	                 
            rsl.append(
                "============= incomplete corba source messages ==================\n" +
                corbaSrcMsgs.toString() + "\n");
            rsl.append(
            	"============= incomplete corba destination messages =============\n" +
            	corbaDestMsgs.toString() + "\n");
          	rsl.append(
	           	"============= complete messages =================================\n" +
            	entireMsgs.toString() + "\n");
     rsl.append("=================================================================\n");
     
		}
	
		if (hasToBeMerged) {
		    rsl.append(">merging process has to be launched.\n");
		} else {
		    rsl.append(">merging process is over.\n");
		}

		rsl.append("\t"+(nblocal==0?"no":""+nblocal)+" local message" +(nblocal>1 ? "s are" : " is")+ " still to process.\n");	    
		rsl.append("\t"+(nbsrc==0?"no":""+nbsrc)+" source message" +(nbsrc>1 ? "s are" : " is")+ " still to complete.\n");
		rsl.append("\t"+(nbdest==0?"no":""+nbdest)+" destination message" +(nbdest>1 ? "s are" : " is")+ " still to complete.\n");
		rsl.append("\t"+nbentire+" entire message"+(nbentire>1 ? "s have" : " has")+ " been created.\n");
		if ((nbsrc+nbdest)>0) {
		   rsl.append("\t"+(nbsrc+nbdest)+" ("+nbsrc+"+"+nbdest+") broken message"
			      +((nbsrc+nbdest)>1 ? "s are " : " is ")+ "also generated at current state of parsing.\n");
		} else {
		   rsl.append("> all parsed messages have been completed successfully.\n");
		}        
	    
	    System.out.println(rsl.toString());
	
		return rsl.toString();
    }
}
