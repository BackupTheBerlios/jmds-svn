package corbaTrace.log2sequenceDiagram.message;
import java.util.*;

public class HalfMessageSource extends Message {
    
    public boolean isSource() {
    	return true;
    }
    
    public boolean isDestination() {
    	return false;
    }

    public boolean isLocal() {
    	return false;
    }

    public boolean equals (Message m) {
	
	return (this.sourceObjectId.equals(m.getSourceObjectId())) &&
		(this.sendingMessageDate.equals(m.getSendingMessageDate()));
    }
    
    public int compareTo (Message m) {
		int i = this.sourceObjectId.compareTo(m.getSourceObjectId());
		if ( i == 0 ) {
	    	// Check comparison between two dates in String format
	    	i = this.sendingMessageDate.compareTo(m.getSendingMessageDate());
		} else {
	    	System.out.println("This is not the same object.");
		}
		return  i;
    }

    public int compareToMessage (HalfMessageSource m) {
        return compareTo((Message) m);
    }

    public int compareTo (HalfMessageDestination m) {
        return compareTo((Message) m);  // we "consider" m as a source message;
                                              // this version may only be used when merging two half messages.
    }

}
