package corbaTrace.log2sequenceDiagram.synchro;

import java.util.*;
import java.lang.*;
import corbaTrace.log2sequenceDiagram.message.*;

/**
 * It's a graph structure to keep objects and value time differences.
 * In this class, it's the node with a weight and all neighbours.
 * Notes :  - this graph is directed 
              (each neighbour is the destination of an edge).
 *          - there is no double (no multi-graphe)
 *
 * @author Antoine Parra del Pozo & Brice FRANCOIS
 * @version 1.1
 */
class ObjectGraphNode implements Comparable {

    /** the identifier of the object */
    private String objectName;         
    /** its weight */
    private long weight;
    /** its maximal weight: to calculate longest ways of the graph */
    private long weightMax;
    /** its neighbours (nodes) */
    private LinkedList nodes;   
    /** its neighbours (edges) */
    private LinkedList edges;    
    /** for going through the whole graph and marking nodes */
    private boolean marked;      

/*---------------------------------------------------------------------------*/
   
    /** the constructor of node */
    public ObjectGraphNode(String objectName){
        this.objectName = objectName;
	weight = 0;
	weightMax = -1000; // -->  -infinite
        nodes = new LinkedList();
        edges = new LinkedList();
        marked = false;
    }

/*---------------------------------------------------------------------------*/
   
    /** determine wheight of the node */
    public void setWeight(long newWeight){weight = newWeight;}

/*---------------------------------------------------------------------------*/

    /** get weight of the node */
    public long getWeight(){return weight;}

/*---------------------------------------------------------------------------*/
   
    /** determine maximal wheight of the node */
    public void setWeightMax(long newWeightMax){weightMax = newWeightMax;}

/*---------------------------------------------------------------------------*/

    /** get maximal weight of the node */
    public long getWeightMax(){return weightMax;}

/*---------------------------------------------------------------------------*/
    
    /**
     * adds a neighbour (node + its edge).
     * @returns the replaced edge if there was another one before.
     * @returns null if a the new edge in paramater has been added.
     */
    public ObjectGraphEdge addNeighbour(ObjectGraphNode node, 
					ObjectGraphEdge edge){
          int findit = getIndex(node); // -1 if not in.
          if (findit == -1) {  // we just add a new node at the end
               nodes.add(node);
               edges.add(edge);
              return null; 
	      /* no edge between these nodes before this adding*/
	      
          } else {  // else this node is already in. We do nothing.
              return (ObjectGraphEdge)edges.get(findit);
          }
    }

/*---------------------------------------------------------------------------*/
   
    /** method to verify if a node is a neighbour of this one */
    public boolean isNeighBour(ObjectGraphNode node) {
        ListIterator lTmp = nodes.listIterator();
        boolean found = false;
        while (!found && lTmp.hasNext()) {
             // test just references, not values
	    found = (node == (lTmp.next()));  
        }
        return found;
    }

/*---------------------------------------------------------------------------*/
   
    /**
     * gets index of this neigbour.
     * @return -1 if not found.
     */
     int getIndex(ObjectGraphNode node) {
        ListIterator lTmp = nodes.listIterator();
        boolean found = false;
        int cpt = -1;
        while (!found && lTmp.hasNext()) {
	    // test just references, not values
	    found = (node == (lTmp.next()));  
             cpt++;
        }
        if (found)
           return cpt;
        else
           return -1;
    }

/*---------------------------------------------------------------------------*/
   
    /** get the value of the node: the identifier */
    public String getValue() {
        return objectName;
    }

/*---------------------------------------------------------------------------*/
  
    /** method to verify if the node is marked */
    public boolean isMarked() {
        return(marked);
    }

/*---------------------------------------------------------------------------*/
 
    /** method to mark the node */
    public void markIt() {
        marked = true;
    }

/*---------------------------------------------------------------------------*/
 
    /** method to unmark the node*/
    public void unmarkIt() {
        marked = false;
    }

/*---------------------------------------------------------------------------*/
   
    /** method to compare if two nodes are equals */
    public boolean equals(Object o){
	return ((o instanceof ObjectGraphNode) && 
		(objectName.equals(((ObjectGraphNode)o).objectName)));
    }
    
/*---------------------------------------------------------------------------*/
    
    /** method to compare the node with another */
    public int compareTo(Object o) throws ClassCastException{
       if (o instanceof ObjectGraphNode)
          return(objectName.compareTo( ((ObjectGraphNode)o).objectName ));
       else
          throw(new ClassCastException("not a correct ObjectGraphNode"));
    }

/*---------------------------------------------------------------------------*/
    
    /** @return neighbour(s) number for this node. */
    public int countNeighbours(){
	return nodes.size();
    }
    
/*---------------------------------------------------------------------------*/
 
    /** get its neighbour nodes in a LinkedList */
    public LinkedList getNeighbourNodesList(){
        return nodes;
    }

/*---------------------------------------------------------------------------*/
 
    /** get its related edges. */
    public LinkedList getNeighbourEdgesList(){
        return edges;
    }

}


