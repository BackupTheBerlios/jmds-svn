package corbaTrace.log2sequenceDiagram.stream;

import java.io.*;

/**
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public interface LogStream {

    public InputStream getStream();
    
    /** to get a filename or an URL for example. */
    public String getStringValue();

    public short getStreamType();

}
