package corbaTrace.log2sequenceDiagram.log2svg;

/**
 * CorbaTraceObject records information of a corba trace object 
 *
 * @author FRANCHETEAU Aurelien
 */

public class CorbaTraceObject{

    
    private String name;
    private int width;
    private long x;
    
    public CorbaTraceObject(String name,int width,long x){
	this.name = name;
	this.width = width;
	this.x = x;
    }
    //===========================================================
    // Access Methods
    //===========================================================
    public String getName(){
	return name;
    }
    public int getWidth(){
	return width;
    }
    public long getX(){
	return x;
    }
    public void setX(long x){
	this.x = x;
    }
   
}
