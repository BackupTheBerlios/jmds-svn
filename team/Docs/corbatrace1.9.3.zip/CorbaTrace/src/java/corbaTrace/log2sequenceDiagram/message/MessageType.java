	/**
 * This file is a part of the project : CorbaTrace
 * It's under LGPL licence.
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 * @author Sebastien Helbert
 * @version 1.0
 */
package corbaTrace.log2sequenceDiagram.message;
/**
 * just some constants and methods to identify some message types.
 */
public abstract class MessageType {
	// --------------------------------------------------------------------------------
	// NOTE TO DEVELOPPERS :
	// to add a new type :  1) adds it in current class.
	//                      2) modify giveMessageType() method.
	//                      3) modify parsing process if necessary (log2xmi/parser/LogHandler.java)
	// --------------------------------------------------------------------------------

    // types of messages for Requests
    public static final String RECEIVE_REQUEST = "RECEIVE_REQUEST";
    public static final String SEND_REQUEST = "SEND_REQUEST";
    public static final String REQUEST = "REQUEST";

    // types of messages for Replies
    public static final String RECEIVE_REPLY = "RECEIVE_REPLY";
    public static final String SEND_REPLY = "SEND_REPLY";
    public static final String REPLY = "REPLY";

    // types of messages for Local Messages
    public static final String LOCAL_CALL_BEGIN = "localCallBegin";
    public static final String LOCAL_CALL_END = "localCallEnd";
    public static final String LOCAL_ACTIVITY_BEGIN = "localActivityBegin";
    public static final String LOCAL_ACTIVITY_END = "localActivityEnd";
    public static final String LOCAL_TRACE = "localTrace";

    // types of messages for Exceptions
    public static final String SEND_EXCEPTION = "SEND_EXCEPTION";
    public static final String RECEIVE_EXCEPTION = "RECEIVE_EXCEPTION";
    public static final String EXCEPTION = "EXCEPTION";

    // broken messages (means one of SEND/RECEIVE... but for an entire message)
    public static final String BROKEN_REQUEST = "BROKEN_REQUEST";
    public static final String BROKEN_REPLY = "BROKEN_REPLY";
    public static final String BROKEN_EXCEPTION = "BROKEN_EXCEPTION";
    
    public static final String NONE = "";


    /** a method that "validate" a type.
      * @returns one of defined constants (RECEIVE_REQUEST, etc.)
      * constant NONE is returned if type as parameter is not correct.
      */
	public static String giveMessageType(String type) {
	    	
		if (type.equalsIgnoreCase(RECEIVE_REQUEST))		return RECEIVE_REQUEST;
		if (type.equalsIgnoreCase(SEND_REQUEST))		return SEND_REQUEST;
		if (type.equalsIgnoreCase(RECEIVE_REPLY))		return RECEIVE_REPLY;
		if (type.equalsIgnoreCase(SEND_REPLY))			return SEND_REPLY;
		if (type.equalsIgnoreCase(RECEIVE_EXCEPTION)) 	return RECEIVE_EXCEPTION;
		if (type.equalsIgnoreCase(SEND_EXCEPTION)) 		return SEND_EXCEPTION;
		
		if (type.equalsIgnoreCase(LOCAL_CALL_BEGIN))	return LOCAL_CALL_BEGIN;
		if (type.equalsIgnoreCase(LOCAL_CALL_END))		return LOCAL_CALL_END;
		if (type.equalsIgnoreCase(LOCAL_ACTIVITY_BEGIN))return LOCAL_ACTIVITY_BEGIN;
		if (type.equalsIgnoreCase(LOCAL_ACTIVITY_END))	return LOCAL_ACTIVITY_END;
		if (type.equalsIgnoreCase(LOCAL_TRACE)) 		return LOCAL_TRACE;
    
		if (type.equalsIgnoreCase(REPLY)) 				return REPLY;
		if (type.equalsIgnoreCase(REQUEST))				return REQUEST;
		if (type.equalsIgnoreCase(EXCEPTION))			return EXCEPTION;
		
		if (type.equalsIgnoreCase(BROKEN_REQUEST))		return BROKEN_REQUEST;
		if (type.equalsIgnoreCase(BROKEN_REPLY))		return BROKEN_REPLY;
		if (type.equalsIgnoreCase(BROKEN_EXCEPTION))	return BROKEN_EXCEPTION;
		

		
	    return NONE;
    }

    /** a method that tells, depending on the type of the message, whether the operation of this message
      * is available on source object or destination object.
      *
      * for exemple, a request message returns false because the operation of this message is available on destination object (not on source)
      * whereas a reply message returns true because the operation of this message is available on source object.
      * @returns true if source object offers this message's operation; false if it's destination object.
      * @returns true if type of message is not precise enough (type NONE for example).
      * @param the type of the message to test (supposed already validated).
      */
    public static boolean operationIsAvailableOnSourceObject(String type) {
       return !(
       	(type == RECEIVE_REQUEST) ||
       	(type == SEND_REQUEST) ||
       	(type == REQUEST) ||
       	(type == BROKEN_REQUEST)
       );
    }
    
    /** a method that give the broken equivalent message type for this half-message type.
      *
      * @param the type of the message to test (supposed already validated).
      * @returns NONE if the message type as parameter is not a broken one.
      */
    static String getBrokenType(String type) {
	if ((type == RECEIVE_REQUEST) || (type == SEND_REQUEST) || (type == BROKEN_REQUEST))
	    return BROKEN_REQUEST;
	else if ((type == RECEIVE_REPLY) || (type == SEND_REPLY) || (type == BROKEN_REPLY))
	    return BROKEN_REPLY;
	else if ((type == RECEIVE_EXCEPTION) || (type == SEND_EXCEPTION) || (type == BROKEN_EXCEPTION))
	    return BROKEN_EXCEPTION;
 	else 
	    return NONE;
    }

    /** tells whether this message type is a half destination message type or not. */
    public static boolean isDestinationType(String type) {
       return ((type == RECEIVE_REQUEST) || (type == RECEIVE_REPLY) || (type == RECEIVE_EXCEPTION));
    }
    
    /** tells whether this message type is a half source message type or not. */
    public static boolean isSourceType(String type) {
       return ((type == SEND_REQUEST) || (type == SEND_REPLY) || (type == SEND_EXCEPTION));
    }
    
    /** tells whether this message type is broken or not. */
    public static boolean isBrokenType(String type) {
       return (!(type == BROKEN_REQUEST) || (type == BROKEN_REPLY) || (type == BROKEN_EXCEPTION));
    }
    
    /** tells whether this message type is local or not. */
    public static boolean isLocalType(String type) {
       return ((type == LOCAL_CALL_BEGIN) || (type == LOCAL_CALL_END) || (type == LOCAL_ACTIVITY_BEGIN) || (type == LOCAL_ACTIVITY_END) || (type == LOCAL_TRACE));
    }

}
