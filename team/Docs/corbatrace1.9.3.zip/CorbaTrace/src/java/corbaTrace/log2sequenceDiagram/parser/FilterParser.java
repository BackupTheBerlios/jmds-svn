package corbaTrace.log2sequenceDiagram.parser;

import java.util.*;

import corbaTrace.log2sequenceDiagram.message.filter.MessagesFilter;

/**
 * This is the parser for our filter file.
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public class FilterParser extends GenericParser {
    
    // inherited attributes
    //    DefaultHandler handler;
    //    SAXParser saxParser;

    // constructor

    /**
     * initialization of a general parser with its handler
     * @param validatedXML indicates whether the parser must validate xml files with their DTD.
     */
    public FilterParser(boolean validatedXML) {
		super(new FilterHandler(validatedXML), validatedXML);
    }

    public MessagesFilter getMessagesFilter() {
		return (((FilterHandler)handler).getMessagesFilter());
    }

}
