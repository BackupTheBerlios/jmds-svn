package corbaTrace.log2sequenceDiagram.message;

import java.util.*;
import corbaTrace.utils.IndentString;

/**
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public class MessageOption {
    protected String name;
    protected Hashtable properties;

    /** note :  a MessageOption can encapsulate other MessageOption as a list.
     * when the name of a property is the same name as the current MessageOption, 
     * then the value associated with that property name is a LinkedList of other MessageOption.
     */
    public MessageOption(String name) {
	this.name = name;
	this.properties = new Hashtable();
    }

    public String getName() {
	return name;
    }
    
    public void setName(String name) {
	if (name != null)
	    this.name = name;
    }
    
    public void addProperty(String propertyName, Object propertyValue) {
	properties.put(propertyName, propertyValue);
    }

    /** does not take the encapsulated MessageOption (just count it for one) */
    public int getNbProperties() {
	return properties.size();
    }
    
    public Object getPropertyValue(String propertyName) {
	return properties.get(propertyName);
    }

    public boolean propertyIsDefined(String propertyName) {
	return properties.containsKey(propertyName);
    }



    //===========================================================
    // Utility Methods
    //===========================================================

    public String toString() {
	return toString(new IndentString());
    }




    public String toString(IndentString s) {
	String propertyName;
	ListIterator listTmp = null;

	s.append("\n"); s.indent(); s.append("<"+name);
	// get a list of its properties
	Enumeration e = properties.keys();
	// print it with their attributes
	while (e.hasMoreElements()) {
	    s.inc();
	    propertyName = (String)e.nextElement();
	    if (propertyName.equals(name)) { // it's an encapsuled list of other MessageOptions : we will treat it later.
		listTmp = ((LinkedList)properties.get(propertyName)).listIterator(0);
	    } else {  // it's just a property with a String value
		s.append(" "); s.append(propertyName + "=\"" + (String)properties.get(propertyName) + "\"");
	    }
	    s.dec();
	}

	if (listTmp != null) {  // there is encapsuled options : we treat them now.
	    s.append(">");
	    s.inc();
	    while (listTmp.hasNext()) {
		((MessageOption)listTmp.next()).toString(s);
	    }
	    s.dec();
	    s.append("\n"); s.indent(); s.append("</"+name+">");
	} else {  // we just close this option tag
	    s.append("/>");
	}

	return s.toString();
    }

}
