package corbaTrace.log2sequenceDiagram.parser;

import java.util.*;

import corbaTrace.log2sequenceDiagram.message.*;

/**
 * This is the parser for our logs.
 * After some parsed files, there are two MessageCollection in the Handler.
 * (one is for half-messages with source infos, and the other one with destination infos).
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public class LogsParser extends GenericParser {
    
    /**
     * initialization of a general parser with its handler
     * @param validatedXML indicates whether the parser must validate xml files with their DTD.
     */
    public LogsParser(boolean validatedXML) {
		super(new LogsHandler(validatedXML), validatedXML);
    }

	/** return the collection of parsed local Messages */    
    public MessageCollection getLocalMessages() {
        return (((LogsHandler) handler).getLocalMessages());
    }

	/** return the collection of parsed destination Message */    
    public MessageCollection getHalfDestinationMessages() {
		return (((LogsHandler) handler).getHalfDestinationMessages());
    }

	/** return the collection of parsed source Message */
    public MessageCollection getHalfSourceMessages() {
		return (((LogsHandler) handler).getHalfSourceMessages());
    }
    
    /** initialize parser */
    public void clearAll() {
		((LogsHandler) handler).clearAll();
    }

    /** asks for some informations at current state of parsing (number of complete and incomplete messages read) */
    public String showInfos(boolean silent) {
		return ((LogsHandler) handler).showInfos(silent);
    }

	/** returns the number of icomplete source messages at current state of parsing */
    public int getNbIncompleteSourceMessages() {
		return (((LogsHandler) handler).getNbIncompleteSourceMessages());
    }

	/** returns the number of icomplete destination messages at current state of parsing */
    public int getNbIncompleteDestinationMessages() {
		return (((LogsHandler) handler).getNbIncompleteDestinationMessages());
    }
}
