package corbaTrace.log2sequenceDiagram.parser;


import corbaTrace.log2sequenceDiagram.stream.*;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.SAXException;
import java.io.*;

import java.io.File;

/**
 * It's a generic Parsing class (to make it simpler to initialize java parser's class).
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public class GenericParser {

    protected DefaultHandler handler;
    protected SAXParser saxParser;

    /**
     * initialization of a general parser with its handler
     * @param validatedXML indicates whether the parser must validate xml files with their DTD.
     */
    public GenericParser(DefaultHandler handler, boolean validatedXML) {
	
		try {
	    	this.handler = handler;  // Use an instance of our handler as the SAX event handler
		    // use default parser in that case
			SAXParserFactory factory = SAXParserFactory.newInstance();
			// uses a validating XML parser (to use with a DTD)
			factory.setValidating(validatedXML);
			// Parse the input
			saxParser = factory.newSAXParser();
		} catch (org.xml.sax.SAXParseException e) {
			System.err.println("> error while parsing (org.xml.sax.SAXParseException), line " + e.getLineNumber() + ", uri "+e.getSystemId()+"   "+e.getMessage());
	    	e.printStackTrace();
        } catch (org.xml.sax.SAXException e) {
            System.err.println("> error while parsing (org.xml.sax.SAXException) : "+e.getMessage());
            e.printStackTrace();
        } catch (javax.xml.parsers.ParserConfigurationException e) {
            System.err.println("> configuration error : javax.xml.parsers.ParserConfigurationException\n" + e.getMessage());
	    	e.printStackTrace();
            System.exit(1);
        }
	
    }

    public void parse(InputStream stream) {
		try {
			saxParser.parse(stream, handler);
		} catch (Exception e) {
		    System.out.println(e.getMessage());
		    e.printStackTrace(); // mieux gerer les differents types d'exceptions ici
		}
    }
    
    public void parse(LogStream stream) {
		try {
			switch(stream.getStreamType()) {
				case LogFile.FILE_ID :
					File file = ((LogFile) stream).getFile();
					if (file == null) return;
			    	saxParser.parse(file, handler);
			        break;
			    case LogUrl.URL_ID :
			    	java.net.URL url = ((LogUrl) stream).getURL();
	    			if (url == null) return;
					saxParser.parse(url.toString(), handler);
			        break;
			}
		} catch (org.xml.sax.SAXParseException e) {	
		    String message = "> error while parsing file : '"+ stream.getStringValue() + "', line "+e.getLineNumber() + " : ";
		    if (e.getException() != null) {
			    System.err.println(message+"check whether DTD file is in same dir as logs. (-d for more infos)");
		    } else {
				System.err.println(message+e.getMessage());
		    }
		} catch (SAXException e) {
		    String message = "> error while parsing file : '"+ stream.getStringValue() + "' ";
		    if (e.getException() != null) {
			    System.err.println(message+"check whether DTD file is in same dir as logs. (-d for more infos)");
		    } else {
				System.err.println(message+e.getMessage());
		    }
		} catch (java.io.IOException e) {
		    System.err.println("> I/O error : I/O error while trying to read log file " + stream.getStringValue());
		} catch (Exception e) {
		    System.err.println("> error : error while trying to read log file " + stream.getStringValue());
		}
    }
    
    public void startParsingFile(File file) throws java.io.IOException, org.xml.sax.SAXException, java.lang.IllegalArgumentException {
		if (file == null) return;
		saxParser.parse(file, handler);	    
    }

    public void startParsingFile(java.net.URL url) throws java.io.IOException, org.xml.sax.SAXException, java.lang.IllegalArgumentException {
		if (url == null) return;
		saxParser.parse(url.toString(), handler);
    }
}
