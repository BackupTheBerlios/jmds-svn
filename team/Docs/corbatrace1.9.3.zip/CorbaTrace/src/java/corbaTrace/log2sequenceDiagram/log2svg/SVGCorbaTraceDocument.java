package corbaTrace.log2sequenceDiagram.log2svg;

import org.w3c.dom.*;
import java.util.Vector;
import java.math.BigDecimal;
import svgSequenceDiagramObjects.*;



/**
 * The SVGCorbaTraceDocument class creates a SVGSequenceDiagram for CorbaTrace
 * 
 * @author FRANCHETEAU Aurelien
 */

public class SVGCorbaTraceDocument{

    private String svgNS;
    private Document doc;
    private Element svgRoot;
    private long width;
    private long height;
    private int margin;
    //endWidth is the latest x coordinate
    private int endWidth;
    //endHeight is the latest y coordinate
    private int endHeight;
    //vector of all objects
    private Vector objects;
    //vector of all messages
    private Vector messages;
    //vector of all comments
    private Vector comments;
    //vector of all actions
    private Vector actions;
    //interval between classifierRole on the diagram
    private long interval;
    //vector of all concurrentObjects
    private Vector concurrentObjects;
    
    

    /** Constructor takes the svg namespace, the svg document and the root element of the document. TimeUnit parameter is the time unit("s" for second,"ms" millisecond...). MaxTime parameter is the maximun duration of the diagram. Its time unit must be the same of the parameter Time Unit. ActorNumber is the number of actors which appear on the diagram. 
     */
    
    public SVGCorbaTraceDocument(String svgNS,Document doc,Element svgRoot){
    
	this.svgNS = svgNS;
	this.doc = doc;
	this.svgRoot = svgRoot;
	width = 700;
	height = 500;
	margin = 10;
	endWidth = (new Integer(margin)).intValue();
	endHeight = (new Integer(margin)).intValue();
	interval = 50;
	objects = new Vector();
	messages = new Vector();
	comments = new Vector();
	actions = new Vector();
	concurrentObjects = new Vector();
	createMarkers();
    }
    
    //===========================================================
    // Access Methods
    //===========================================================

     
    public String getSvgNS(){
	return svgNS;
    } 
    public Document getDocument(){
	return doc;
    }
    public Element getSvgRoot(){
	return svgRoot;
    }
     
    //method wich calculate width
    private int calculWidth(String obj){
      	return ((obj.length()*5)+25);
    }

    /**Method add message creates a message between two concurrents objects. The type of message is ProcedureCall Type
     */
    public void addMessage(String sender,long timeSender,String receiver,long timeReceiver,String txt){
	//stock objects if exist
	boolean senderExist = false;
	boolean receiverExist = false;
	CorbaTraceObject obj;
	
	for(int i = 0;(i<objects.size());i++){
	    obj = (CorbaTraceObject)objects.elementAt(i);
	    if((obj.getName()).compareTo(sender)==0)
		senderExist = true;
	    if((receiver == null)||(obj.getName()).compareTo(receiver)==0)
		receiverExist = true;	    
	}
	
	if(!senderExist){
	    
	    CorbaTraceObject obj1 = new CorbaTraceObject(sender,calculWidth(sender),0);
	    objects.addElement(obj1);
	  
	}
	if(!receiverExist){
	    CorbaTraceObject obj2 = new CorbaTraceObject(receiver,calculWidth(receiver),0);
	    objects.addElement(obj2);

	}
	//stock message
	CorbaTraceMessage msg = new CorbaTraceMessage(sender,receiver,txt,timeSender,timeReceiver);
	messages.addElement(msg);
     }

    /**Method add message creates a message between two concurrents objects. The type of message is ReturnFromProcedureCall Type.
     *If the receiver is null, this method add an abort message with a cross at the end of the mesage
     */
    public void addMessage(String sender,long timeSender,String receiver,long timeReceiver){
	
	//stock objects if exist
	boolean senderExist = false;
	boolean receiverExist = false;
	CorbaTraceObject obj;

	for(int i = 0;(i<objects.size());i++){
	    obj = (CorbaTraceObject) objects.elementAt(i);
	    if((obj.getName()).compareTo(sender)==0)
		senderExist = true;
	    if((receiver == null)||((obj.getName()).compareTo(receiver)==0))
		receiverExist = true;	    
	}
	
	if(!senderExist){
	    
	    CorbaTraceObject obj1 = new CorbaTraceObject(sender,calculWidth(sender),0);
	    objects.addElement(obj1);
	}
	if(!receiverExist){
	    CorbaTraceObject obj2 = new CorbaTraceObject(receiver,calculWidth(receiver),0);
	    objects.addElement(obj2);
	}
	//stock message
	CorbaTraceMessage msg = new CorbaTraceMessage(sender,receiver,null,timeSender,timeReceiver);
	messages.addElement(msg);

     }

    /**Method add comment creates a comment creates a comment on the time axis of the object passed in parameter.The second parameter is the time it appears. 
     * The first is the comments.
     */
    public void addComment(String sender,long timeSender,String comment){
	
	//stock objects if exist
	boolean senderExist = false;
	boolean receiverExist = false;
	CorbaTraceObject obj;

	for(int i = 0;(i<objects.size());i++){
	    obj = (CorbaTraceObject) objects.elementAt(i);
	    if((obj.getName()).compareTo(sender)==0)
		senderExist = true;
	}
	
	if(!senderExist){
	    
	    CorbaTraceObject obj1 = new CorbaTraceObject(sender,calculWidth(sender),0);
	    objects.addElement(obj1);
	}
	
	//stock comment
	CorbaTraceComment cmt = new CorbaTraceComment(sender,timeSender,comment);
	comments.addElement(cmt);

     }
    
    /**Method add action creates an action on the time axis of the object passed in parameter. The second parameter is the time it appears 
     *and the last one is its duration
     */
    public void addAction(String object,long timeStart,long time){
	
	//stock objects if exist
	boolean objectExist = false;

	CorbaTraceObject obj;

	for(int i = 0;(i<objects.size());i++){
	    obj = (CorbaTraceObject) objects.elementAt(i);
	    if((obj.getName()).compareTo(object)==0)
		objectExist = true;
	}
	
	if(!objectExist){
	    
	    CorbaTraceObject obj1 = new CorbaTraceObject(object,calculWidth(object),0);
	    objects.addElement(obj1);
	}
	
	//stock comment
	CorbaTraceAction act = new CorbaTraceAction(object,timeStart,time);
	actions.addElement(act);

    }
    
    //calcul first element with comment
    private int xFirstElement(){
	CorbaTraceObject obj;
	CorbaTraceComment cmt;
	Vector cmts = new Vector();
	//last element
	obj = (CorbaTraceObject)objects.elementAt(0);
	for(int i = 0;(i<comments.size());i++){
	    cmt = (CorbaTraceComment)comments.elementAt(i);
	    if((cmt.getSender()).compareTo(obj.getName())==0)
	       cmts.addElement(cmt);	       		    
	}
	int xfe = 0;
	int len =0;
	for(int i = 0;(i<cmts.size());i++){
	    cmt = (CorbaTraceComment)cmts.elementAt(i);
	    len = (((cmt.getText()).length()*5)+15);
	    if (xfe < len)
		xfe =len;	    
	}
    return xfe;
    }

     //calcul first element with comment
    private int xLastElement(){
	CorbaTraceObject obj;
	CorbaTraceComment cmt;
	Vector cmts = new Vector();
	//first element
	obj = (CorbaTraceObject)objects.lastElement();;
	for(int i = 0;(i<comments.size());i++){
	    cmt = (CorbaTraceComment)comments.elementAt(i);
	    if((cmt.getSender()).compareTo(obj.getName())==0)
	       cmts.addElement(cmt);	       		    
	}
	int xle = 0;
	int len =0;
	for(int i = 0;(i<cmts.size());i++){
	    cmt = (CorbaTraceComment)cmts.elementAt(i);
	    len = (((cmt.getText()).length()*5)+15);
	    if (xle < len)
		xle =len;	    
	}
    return xle;
    }

    //calcul x absyss for all objects
    private void calculX(){
	CorbaTraceObject obj;
	long size = width;
	long endX = 0;
	int marge = margin + xFirstElement();
	//first element
	obj = (CorbaTraceObject)objects.elementAt(0);
	obj.setX(marge);
	size = size -(marge + obj.getWidth());
	endX = marge + obj.getWidth();
	//last element
	if(objects.size() > 1){
	    obj = (CorbaTraceObject)objects.lastElement();
	    obj.setX(width-marge-obj.getWidth()-xLastElement());
	    size = size - (marge + obj.getWidth()+xLastElement());
	}
	//the others
	if(objects.size() > 2){
	    for(int i = 1;(i<(objects.size()-1));i++){
		obj = (CorbaTraceObject)objects.elementAt(i);
		size = size - obj.getWidth();	    
	    }

	    long bg = objects.size()-1;
	    long bg2 = size;
	    bg = bg2/bg;
	    interval = bg;
	   
	    for(int i = 1;(i<(objects.size()-1));i++){
		obj = (CorbaTraceObject)objects.elementAt(i);
		
		obj.setX(endX + interval);
		endX = endX+interval + obj.getWidth();
	    }
	}
    }

    //calcul y ordinate of the SVG frame
    private void calculY(){
	//take the maximum time 
	long maxTime = 0;
	//take the minimum time
	long minTime = 0;
	CorbaTraceMessage msg;
	CorbaTraceAction act;
	for(int i = 0;(i<messages.size());i++){
	    msg = (CorbaTraceMessage)messages.elementAt(i);
	    if(msg.getTimeSender()>maxTime)
		maxTime = msg.getTimeSender();
	    if(msg.getTimeReceiver()>maxTime)
		maxTime = msg.getTimeReceiver();	    
	}
	for(int i = 0;(i<messages.size());i++){
	    msg = (CorbaTraceMessage)messages.elementAt(i);
	    if(i!=0){
	    	if(msg.getTimeSender()<minTime)
			minTime = msg.getTimeSender();
	    	if(msg.getTimeReceiver()<minTime)
			minTime = msg.getTimeReceiver();	    
	    }
	    else{
	    	if(msg.getTimeSender()<msg.getTimeReceiver()){
	    		minTime = msg.getTimeSender();
	    	}
	    	else{
	    		minTime = msg.getTimeReceiver();
	    	}
	    }
	}
	for(int i = 0;(i<actions.size());i++){
	    act = (CorbaTraceAction)actions.elementAt(i);
	    if(act.getMaxTime()>maxTime)
		maxTime = act.getMaxTime();
	}
		
	for(int i = 0;(i<actions.size());i++){
	    act = (CorbaTraceAction)actions.elementAt(i);
	    if(act.getTimeObject()<minTime)
		minTime = act.getTimeObject();
	      
	}
	//calcul height
	 long bg = height-(2*margin)-40;
	 long bg2 = maxTime - minTime;
	
	 if(bg<bg2){
	     bg = bg2;
	     bg2 = (2*margin)+40;
	     bg = bg + bg2;
	     height = bg;
	     for(int i = 0;(i<messages.size());i++){
		msg = (CorbaTraceMessage)messages.elementAt(i);
		
	   
		long x1 = msg.getTimeSender();
	
		msg.setTimeSender(x1-minTime);
		long x2 = msg.getTimeReceiver();  
		msg.setTimeReceiver(x2-minTime);
		}
	    
	    CorbaTraceComment cmt;
	    for(int i = 0;(i<comments.size());i++){
		cmt = (CorbaTraceComment)comments.elementAt(i);
		long x3 = cmt.getTimeSender();
		cmt.setTimeSender(x3-minTime);
		
	    } 
	   
	    for(int i = 0;(i<actions.size());i++){
		act = (CorbaTraceAction)actions.elementAt(i);
		long x4 = act.getTimeObject();
		act.setTimeObject(x4-minTime);
		
	    }  
	 }  
	 else{  
	    
	    bg =  bg/bg2;
	    long h = bg;
	    
	    for(int i = 0;(i<messages.size());i++){
		msg = (CorbaTraceMessage)messages.elementAt(i);
		
	   
		long x1 = msg.getTimeSender();
		
		msg.setTimeSender(h * (x1-minTime));
		long x2 = msg.getTimeReceiver();  
		msg.setTimeReceiver(h * (x2-minTime));
		}
	    
	    CorbaTraceComment cmt;
	    for(int i = 0;(i<comments.size());i++){
		cmt = (CorbaTraceComment)comments.elementAt(i);
		long x3 = cmt.getTimeSender();
		cmt.setTimeSender(h * (x3-minTime));
		
	    } 
	   
	    for(int i = 0;(i<actions.size());i++){
		act = (CorbaTraceAction)actions.elementAt(i);
		long x4 = act.getTimeObject();
		act.setTimeObject(h * (x4-minTime));
		
	    }  
	    
	}   
    }
 
//calcul y ordinate of the SVG frame with a scale
    private void changeScale(long scale){
	CorbaTraceMessage msg ;
	CorbaTraceAction act;
	CorbaTraceComment cmt;
	    
	    for(int i = 0;(i<messages.size());i++){
		msg = (CorbaTraceMessage)messages.elementAt(i);
		
	   
		long x1 = msg.getTimeSender();
		
		msg.setTimeSender(x1*scale);
		long x2 = msg.getTimeReceiver();  
		msg.setTimeReceiver(x2*scale);
		}
	    
	    for(int i = 0;(i<comments.size());i++){
		cmt = (CorbaTraceComment)comments.elementAt(i);
		long x3 = cmt.getTimeSender();
		cmt.setTimeSender(x3*scale);
		
	    } 
	   
	    for(int i = 0;(i<actions.size());i++){
		act = (CorbaTraceAction)actions.elementAt(i);
		long x4 = act.getTimeObject();
		act.setTimeObject(x4*scale);
		
	    }  
	    
	}   
     private void changeScale(float s){
	  
	float sc = (1/s);
	long scale = (long)sc;	
	height = height / (scale);
	
	
	CorbaTraceMessage msg ;
	CorbaTraceAction act;
	CorbaTraceComment cmt;
	    
	    for(int i = 0;(i<messages.size());i++){
		msg = (CorbaTraceMessage)messages.elementAt(i);
		
	   
		long x1 = msg.getTimeSender();
		
		msg.setTimeSender(x1/scale);
		long x2 = msg.getTimeReceiver();  
		msg.setTimeReceiver(x2/scale);
		}
	    
	    for(int i = 0;(i<comments.size());i++){
		cmt = (CorbaTraceComment)comments.elementAt(i);
		long x3 = cmt.getTimeSender();
		cmt.setTimeSender(x3/scale);
		
	    } 
	   
	    for(int i = 0;(i<actions.size());i++){
		act = (CorbaTraceAction)actions.elementAt(i);
		long x4 = act.getTimeObject();
		act.setTimeObject(x4/scale);
		
	    }  
	    
	}

    // Methode generateObjects generates all object of the frame
	private void generateObject(){
	    //generate corbaTrace objects
	    CorbaTraceObject obj;
	    for(int i = 0;(i<objects.size());i++){
		
		obj = (CorbaTraceObject)objects.elementAt(i);
		String x = ""+obj.getX();
		String y = ""+margin;
		
		SVGConcurrentObject concurrentObject = new SVGConcurrentObject(x,y,obj.getName());
		concurrentObject.createSVGConcurrentObject(svgNS,doc,svgRoot);
		String length = ""+height;
		concurrentObject.addTimeAxis(length);
		
		concurrentObjects.addElement(concurrentObject);
		
	    }
	    //generate corbaTrace messages
	    CorbaTraceMessage msg;
	    SVGConcurrentObject sco;
	    SVGConcurrentObject sender = null;
	    SVGConcurrentObject receiver = null;
	    for(int i = 0;(i<messages.size());i++){
		msg = (CorbaTraceMessage)messages.elementAt(i);
		for(int j = 0;(j<concurrentObjects.size());j++){
		    sco = (SVGConcurrentObject)concurrentObjects.elementAt(j);
		    
		    if(msg.getSender().compareTo(sco.getName()) == 0)
			sender = sco;
		    if((msg.getReceiver() != null)&&(msg.getReceiver().compareTo(sco.getName()) == 0))
			receiver = sco;
		}
		
		String y = ""+msg.getTimeSender();
		if(msg.getReceiver() == null){
		    String y1 = y;
		    String end = ""+(interval/2);
		    if((sender.getName()).compareTo(((CorbaTraceObject)objects.lastElement()).getName()) == 0){
			if(msg.getText() == null)
			    sender.addAbortReturnMessage(end,y,"left");
			else
			    sender.addAbortMessage(end,y,"left");
		    }
		    else{
			if(msg.getText() == null)
			    sender.addAbortReturnMessage(end,y,"right");
			else
			    sender.addAbortMessage(end,y,"right");
		    }
		}
		else{
			
		    String y1 = ""+msg.getTimeReceiver();         
		    if (msg.getText() == null)
			sender.addReturnFromProcedureCallMessage(receiver,y,y1);
		    else
			sender.addProcedureCallMessage(receiver,y,y1,msg.getText());
		}
	    }
	    //generate corbatrace comments
	    CorbaTraceComment cmt;
	    SVGConcurrentObject scoC;
	    SVGConcurrentObject senderC = null;
	    for(int i = 0;(i<comments.size());i++){
		cmt = (CorbaTraceComment)comments.elementAt(i);
		for(int j = 0;(j<concurrentObjects.size());j++){
		    scoC = (SVGConcurrentObject)concurrentObjects.elementAt(j);
		    
		    if(cmt.getSender().compareTo(scoC.getName()) == 0)
			senderC = scoC;
	      	}
		
		String yCmt = (new Integer((new Float(cmt.getTimeSender())).intValue())).toString();
		String endCmt = (new Integer(10)).toString();
		if((senderC.getName()).compareTo(((CorbaTraceObject)objects.lastElement()).getName()) == 0){
		    int w = ((SVGConcurrentObject)concurrentObjects.lastElement()).getWidth();
		    endCmt = (new Integer((w/2)+1)).toString();
		    
		    senderC.addComment(endCmt,yCmt,"right-center",cmt.getText());
		}
		else if((senderC.getName()).compareTo(((CorbaTraceObject)objects.firstElement()).getName()) == 0){
		    int w = ((SVGConcurrentObject)concurrentObjects.firstElement()).getWidth();
		    endCmt = (new Integer((w/2)+1)).toString();
		    senderC.addComment(endCmt,yCmt,"left-center",cmt.getText());
		}
		else{
		    senderC.addComment(endCmt,yCmt,"right",cmt.getText());
		}
	    }

	    //generate actions
	    CorbaTraceAction act;
	    SVGConcurrentObject scoA;
	    SVGConcurrentObject object = null;
	    for(int i = 0;(i<actions.size());i++){
		act = (CorbaTraceAction)actions.elementAt(i);
		for(int j = 0;(j<concurrentObjects.size());j++){
		    scoA = (SVGConcurrentObject)concurrentObjects.elementAt(j);
		    
		    if(act.getObject().compareTo(scoA.getName()) == 0)
			object = scoA;
		}
		
		String y = ""+act.getTimeObject();
		object.addAction(y,""+act.getTime()+"");
		
	    }
	}	
    
    /** Methode createSVGFrame creates the frame of the document with a scale. 
     */    
    public void createSVGFrame(float scale){
	
	//test if the frame is large enought
	long maxSize = 0;
	for(int i = 0;(i<objects.size());i++){
	    maxSize = maxSize + ((CorbaTraceObject)objects.elementAt(i)).getWidth();	    
	}
	if (maxSize > (width-(2*margin)-(30*(objects.size()-1))-xFirstElement()-xLastElement()))
	    width = maxSize+(2*margin)+(30*(objects.size()-1))+xFirstElement()+xLastElement();
	
	calculX();
	calculY();
		
	if (scale >= 1){
	    changeScale((long)scale);
	    height = height * ((long)scale);
	}
      	else
	    changeScale(scale);
	   
	
	
       	String w = ""+width;
	String h = ""+height;
	
	svgRoot.setAttributeNS(null, "width", w);
	svgRoot.setAttributeNS(null, "height", h);
	generateObject();
    }


/** Methode createSVGFrame creates the frame of the document with a scale at 1. 
     */    
    public void createSVGFrame(){
	createSVGFrame((float) 1);
        }

    /** Methode createSVGFrame creates the frame of the document with width and height in parameter. 
     */    
    public void createSVGFrame(long width,long height){
	this.width = width;
	this.height = height;
    }
  
    // Methode which create marker for arrowhead
    private void createMarkers(){
	 
	 //marker definition for procedure call
	 Element definition2 = doc.createElementNS(svgNS,"defs");
	 //Arrow
	 Element marker2 = doc.createElementNS(svgNS,"marker");
	 marker2.setAttributeNS(null,"id","svgProcedureCallArrowhead");
	 marker2.setAttributeNS(null,"viewBox","0 0 50 50");
	 marker2.setAttributeNS(null,"refX","0");
	 marker2.setAttributeNS(null,"refY","25");
	 marker2.setAttributeNS(null,"markerUnits","strokeWidth");
	 marker2.setAttributeNS(null,"markerWidth","15");
	 marker2.setAttributeNS(null,"markerHeight","12");
	 marker2.setAttributeNS(null,"orient","auto");
	 Element markerPath2 = doc.createElementNS(svgNS,"path");
	 markerPath2.setAttributeNS(null,"d","M 0 0 L 50 25 L 0 25 L 50 25 L 0 50 z");
	 markerPath2.setAttributeNS(null,"fill","black");
	 markerPath2.setAttributeNS(null,"stroke","black");
	 markerPath2.setAttributeNS(null,"stroke-width","3");
	 marker2.appendChild(markerPath2);
	 definition2.appendChild(marker2);
	 svgRoot.appendChild(definition2);
	 
	 //marker definition for return from procedure call
	 Element definition3 = doc.createElementNS(svgNS,"defs");
	 //Arrow
	 Element marker3 = doc.createElementNS(svgNS,"marker");
	 marker3.setAttributeNS(null,"id","svgReturnFromProcedureCallArrowhead");
	 marker3.setAttributeNS(null,"viewBox","0 0 50 50");
	 marker3.setAttributeNS(null,"refX","0");
	 marker3.setAttributeNS(null,"refY","25");
	 marker3.setAttributeNS(null,"markerUnits","strokeWidth");
	 marker3.setAttributeNS(null,"markerWidth","15");
	 marker3.setAttributeNS(null,"markerHeight","12");
	 marker3.setAttributeNS(null,"orient","auto");
	 Element markerPath3 = doc.createElementNS(svgNS,"path");
	 markerPath3.setAttributeNS(null,"d","M 0 0 L 50 25 L 0 25 L 50 25 L 0 50");
	 markerPath3.setAttributeNS(null,"fill","none");
	 markerPath3.setAttributeNS(null,"stroke","black");
	 markerPath3.setAttributeNS(null,"stroke-width","4");
	 marker3.appendChild(markerPath3);
	 definition3.appendChild(marker3);
	 svgRoot.appendChild(definition3);
    }

   
    
}
