package corbaTrace.log2sequenceDiagram.synchro;
import java.util.*;

/**
 * It's a graph structure to keep objects and value time differences.
 * Here it's the edge with a simple weight.
 *
 * @author Antoine Parra del Pozo & Brice FRANCOIS
 * @version 1.1
 */

class ObjectGraphEdge {
    private long weight;

    public ObjectGraphEdge() {
        weight = 0;
    }

    public ObjectGraphEdge(long weight) {
        this.weight = weight;
    }

    public void setWeight(long val) {
        weight = val;
    }

    public long getWeight() {
        return weight;
    }
}
