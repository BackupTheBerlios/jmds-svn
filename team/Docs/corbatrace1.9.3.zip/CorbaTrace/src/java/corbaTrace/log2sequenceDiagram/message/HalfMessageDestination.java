package corbaTrace.log2sequenceDiagram.message;
import java.util.*;

public class HalfMessageDestination extends Message {

    public boolean isSource() {
        return false;
    }

    public boolean isDestination() {
        return true;
    }

    public boolean isLocal() {
        return false;
    }

    public boolean equals(Message m) {
        return // (this.messageId.equals(m.getMessageId())) &&
        (this.destinationObjectId.equals(m.getDestinationObjectId()))
            && (this.receivingMessageDate.equals(m.getReceivingMessageDate()));
    }

    public int compareTo(Message m) {
        if (m instanceof HalfMessageSource)
            return compareTo((HalfMessageSource) m);
        else
            return compareToMessage((HalfMessageDestination) m);
    }

    public int compareToMessage(HalfMessageDestination m) {
        int i = this.destinationObjectId.compareTo(m.getDestinationObjectId());
        if (i == 0) {
            // Check comparison between two dates in String format
            i = this.receivingMessageDate.compareTo(m.getReceivingMessageDate());
        } else {
            System.out.println("This is not the same object.");
        }
        return i;
    }

    public int compareTo(HalfMessageSource m) {
        // !!! if we compare a source with a destination, it is considered
        // as a comparison of their source informations (ID, date), even for destination object.
        // This method is used only for merging.
        int i = this.sourceObjectId.compareTo(m.getSourceObjectId());
        if (i == 0) {
            // Check comparison between two dates in String format
            i = this.sendingMessageDate.compareTo(m.getSendingMessageDate());
        } else {
            System.out.println("This is not the same object.");
        }
        return i;
    }
}
