package corbaTrace.log2sequenceDiagram.message;
import java.util.*;

/**
 * A MessageCollection is an ordered collection (list) of Objects,
 * each object is an "ObjectMessage" (composed of its objectID and its messages)
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public class MessageCollection {
    private LinkedList objectMessageList;

    // Constructors

    public MessageCollection() {
        objectMessageList = new LinkedList();
    }

    public MessageCollection(Collection c) {
        objectMessageList = new LinkedList(c);
    }

    /*
     * @returns number of messages in the whole collection
     */
    public int getNbMessages() {
        int counter = 0;
        ListIterator l = objectMessageList.listIterator(0);
        while (l.hasNext()) {
            counter += ((ObjectMessage) l.next()).getNbMessages();
        }
        return counter;
    }

    public int getNbObjects() {
        return objectMessageList.size();
    }

    /** adds a new message to this collection.
      */
    public void addMessage(Message m) {
        String objectSourceID = null, objectDestID = null;
        // 1) we locate the objectID of the new message
        if(m.isLocal() || m.isSource()) {
            addMessage(m.getSourceObjectId(), m);
        } else if (m.isDestination()) {
            addMessage(m.getDestinationObjectId(), m);
	   	} else {
    		// else if it's an entiere message, we don't know what
	        // object to use for ordering it !  the source or the destination ???
        	// so : we add it to the 2 objects (if it's different).
			addMessage(m.getSourceObjectId(), m);
			//addMessage(m.getDestinationObjectId(), m);
        }
    }

    // same private addMessage method.
    private ObjectMessage addMessage(String objectID_in, Message m) {
        // we add the object (and we get it)
        // then we add the message to this object's messages.
        ObjectMessage oTmp = addObject(objectID_in);
        oTmp.addMessage(m);
        return oTmp;
    }

    // just add an object (with no message) if not already in; returns this object
    private ObjectMessage addObject(String objectID_in) {
        ListIterator l = objectMessageList.listIterator(0);
        ObjectMessage oTmp = null;
        int rsl = 1;
        while ((rsl > 0) && l.hasNext()) { // we try to locate the object
            oTmp = (ObjectMessage) l.next();
            rsl = (objectID_in.compareTo(oTmp.getIdObject()));
        }
        if (rsl > 0) { // we reached the end of the list and the objectID to add
            // was after the last element : it is the last element.
            oTmp = new ObjectMessage(objectID_in);
            objectMessageList.addLast(oTmp);
        } else if (rsl < 0) { // it is before the last one we read
            l.previous();
            oTmp = new ObjectMessage(objectID_in);
            l.add(oTmp);
        }
        // else if rsl==0, oTmp IS objectID : nothing to add : it's oTmp.

        return oTmp;
    }

    // locate an object 
    public ObjectMessage getObject(String objectId) {
        ListIterator l = objectMessageList.listIterator(0);
        ObjectMessage oTmp = null;
        // we try to locate the object
        while (l.hasNext()) {
            oTmp = (ObjectMessage) l.next();
            if ((objectId.compareTo(oTmp.getIdObject())) == 0) {
                return oTmp;
            }
        }
        return null;
    }

    // gets object i
    public ObjectMessage getObject(int numObject) {
        return (ObjectMessage) objectMessageList.get(numObject);
    }

    // gets object's messages
    public ListIterator getMessagesIterator(int numObject) {
        Object oTmp = objectMessageList.get(numObject);
        if (oTmp != null)
            return ((ObjectMessage) oTmp).getMessagesIterator();
        else
            return null;
    }

    // gets object's messages
    public ListIterator getMessagesIterator(String objectId) {
        Object oTmp = getObject(objectId);
        if (oTmp != null)
            return ((ObjectMessage) oTmp).getMessagesIterator();
        else {
            return null;
        }
    }

    // gets objects
    public ListIterator getObjectsIterator() {
        return (objectMessageList.listIterator(0));
    }

    public Object clone() {
        return new MessageCollection((Collection) this.objectMessageList.clone());
    }

    public void clear() {
        objectMessageList.clear();
    }

    /**
      * gets an iterator to trough all messages stored in this collection
      */
    public Iterator iterator() {
        return new MessageCollectionIterator(this);
    }

    public String toString() {
        StringBuffer s = new StringBuffer();
        ListIterator l = objectMessageList.listIterator();
        while (l.hasNext()) {
            s.append(((ObjectMessage) l.next()).toString());
        }
        return s.toString();
    }

}
