package corbaTrace.log2sequenceDiagram.log2svg;

/**
 * CorbaTraceAction records information of a corba trace action 
 *
 * @author FRANCHETEAU Aurelien
 */

public class CorbaTraceAction{

    
    private String object;
    private long time;
    private long timeObject;

    
    public CorbaTraceAction(String object,long timeObject,long time){
	this.object = object;
	this.time = time   ;
	this.timeObject = timeObject;
    }
    //===========================================================
    // Access Methods
    //===========================================================
    public String getObject(){
	return object;
    }

    public long getTime(){
	return time;
    }
    public long getTimeObject(){
	return timeObject;
    }
   
    public void setTimeObject(long time){
	timeObject = time;
    }
    public long getMaxTime(){
	return (timeObject+time);
    }
    
}
