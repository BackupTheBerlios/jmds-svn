package corbaTrace.log2sequenceDiagram.stream;

import java.io.*;
import java.net.URL;

/**
 * extends LogStream for using log file as an URL.
 *
 * @author Nicolas Lemoullec
 * @author Antoine Parra del Pozo
 */
public class LogUrl implements LogStream {
    
    private String url;
    public static final short URL_ID = 1;
    
    public LogUrl(String url) {
		this.url = url;
    }
    
    public InputStream getStream() {
		try {
		    return (new URL(url).openStream());
		} catch (java.net.MalformedURLException e) {
		    System.err.println(">>> error : URL is malformed (" + url + ")");
		} catch (java.io.IOException e) {
		    System.err.println(">>> I/O error : I/O error while trying to read log file " + url);
		}
		return null;
	    }
	    
	    public String getStringValue() {
		return url;
    }

    public URL getURL() {
		try {
		    return (new URL(url));
		} catch (java.net.MalformedURLException e) {
		    System.err.println(">>> error : URL is malformed (" + url + ")");
	            return null;
		}
	    }
	
	    public short getStreamType() {
		return URL_ID;
    }
}

