package corbaTrace.log2sequenceDiagram.message;
import java.util.*;

import corbaTrace.utils.DateUtilities;

public class EntireMessage extends Message {

    public static final String BROKEN_OBJECT = "unknown";
    public static final Date BROKEN_DATE = DateUtilities.BAD_DATE; // we use the one from DateUtilities

    public EntireMessage() {
        super();
    }

    public boolean isSource() {
        return MessageType.isSourceType(messageType);
    }

    public boolean isDestination() {
        return MessageType.isDestinationType(messageType);
    }

    public boolean isLocal() {
        return MessageType.isLocalType(messageType);
    }

    public EntireMessage(HalfMessageSource src, HalfMessageDestination dest) {
        super();
        setRequestId(src.getRequestId());
        if (src.getMessageType() == MessageType.SEND_REQUEST) {
            messageType = MessageType.REQUEST;
        } else if (src.getMessageType() == MessageType.SEND_REPLY) {
            messageType = MessageType.REPLY;
        } else if (src.getMessageType() == MessageType.SEND_EXCEPTION) {
            messageType = MessageType.EXCEPTION;
        }
        // else it is MessageType.NONE   (default when calling superclass constructor)

        // we keep messageID from the server object side
        if (MessageType.operationIsAvailableOnSourceObject(this.getMessageType())) {
            setMessageId(src.getMessageId());
        } else {
            setMessageId(dest.getMessageId());
        }

        setSourceObjectId(src.getSourceObjectId());
        setSendingMessageDate(src.getSendingMessageDate());
        setDestinationObjectId(dest.getDestinationObjectId());
        setReceivingMessageDate(dest.getReceivingMessageDate());

        addOperation(src.getOperation()); // operation

        // then we merge options
        // first, we keep MessageOptions from source part of the message as the entire ones.
        messageOptionList =
            (src.getMessageOptionList() != null ? (Vector) ((Vector) src.getMessageOptionList()).clone() : null);

        // then we add options from destination part of the message (if they are not already set).
        Vector destinationOptions =
            (dest.getMessageOptionList() != null ? (Vector) ((Vector) dest.getMessageOptionList()).clone() : null);
        if (destinationOptions != null) {
            MessageOption destOptionTmp = null;
            for (int i = 0; i < destinationOptions.size(); ++i) {
                destOptionTmp = (MessageOption) destinationOptions.elementAt(i);
                if (!optionIsDefined(destOptionTmp.getName())) {
                    addMessageOption(destOptionTmp);
                }
            }
        }
        // voil�.
    }

    /** constructor to create an EntireMessage from only an HalfMessageSource.
      *  Warning : this entire message is a broken one !!!  (messagetype = BROKEN)
      */
    public EntireMessage(HalfMessageSource src) {
        super();
        setMessageId(src.getMessageId());
        setRequestId(src.getRequestId());
        messageType = MessageType.getBrokenType(src.getMessageType());

        setSourceObjectId(src.getSourceObjectId());
        setSendingMessageDate(src.getSendingMessageDate());
        setDestinationObjectId(BROKEN_OBJECT);
        setReceivingMessageDate(BROKEN_DATE);

        addOperation(src.getOperation()); // operation
        // first, we keep MessageOptions from source part of the message as the entire ones.
        messageOptionList =
            (src.getMessageOptionList() != null ? (Vector) ((Vector) src.getMessageOptionList()).clone() : null);
    }

    /** constructor to create an EntireMessage from only an HalfMessageDestination.
      *  Warning : this entire message is a broken one !!!  (messagetype = BROKEN)
      */
    public EntireMessage(HalfMessageDestination dest) {
        super();
        setMessageId(dest.getMessageId());
        setRequestId(dest.getRequestId());
        messageType = MessageType.getBrokenType(dest.getMessageType());

        setSourceObjectId(BROKEN_OBJECT);
        setSendingMessageDate(BROKEN_DATE);
        setDestinationObjectId(dest.getDestinationObjectId());
        setReceivingMessageDate(dest.getReceivingMessageDate());

        addOperation(dest.getOperation()); // operation
        // first, we keep MessageOptions from source part of the message as the entire ones.
        messageOptionList =
            (dest.getMessageOptionList() != null ? (Vector) ((Vector) dest.getMessageOptionList()).clone() : null);
    }

    /**
     * Constructor EntireMessage. Copy a localMessage to an EntireMessage
     * @param localMessage
     */
    public EntireMessage(LocalMessage localMessage) {
    	super();
        setMessageId(localMessage.getMessageId());
        messageType = localMessage.getMessageType();
        setSourceObjectId(localMessage.getSourceObjectId());
        if(localMessage.getDestinationObjectId() == null) {
			setDestinationObjectId(localMessage.getSourceObjectId());
        } else {
        	setDestinationObjectId(localMessage.getDestinationObjectId());
        }
        setSendingMessageDate(localMessage.getSendingMessageDate());
        setReceivingMessageDate(localMessage.getSendingMessageDate());

        addOperation(localMessage.getOperation());
    }


    public boolean equals(Message m) {
        return (this.sourceObjectId.equals(m.getSourceObjectId()))
            && (this.sendingMessageDate.equals(m.getSendingMessageDate()));
    }

    // order depend of the type of the message and the object
    public int compareTo(Message m) {
        // we've got 4 cases :
        //    - this source object is source object of m
        //    - this source object is dest object of m
        //    - this dest object is source object of m
        //    - this dest object is dest object of m
        // 1) try to locate the common object.
        Date dateThis, datem;
        if (this.sourceObjectId.equals(m.getSourceObjectId())) {
            dateThis = sendingMessageDate;
            datem = m.getSendingMessageDate();
        } else if (this.sourceObjectId.equals(m.getDestinationObjectId())) {
            dateThis = sendingMessageDate;
            datem = m.getReceivingMessageDate();
        } else if (this.destinationObjectId.equals(m.getSourceObjectId())) {
            dateThis = receivingMessageDate;
            datem = m.getSendingMessageDate();
        } else if (this.destinationObjectId.equals(m.getDestinationObjectId())) {
            dateThis = receivingMessageDate;
            datem = m.getReceivingMessageDate();
        } else {
            System.out.println("This is not the same object.");
            // Be CAREFULL !!!!!!!!!!!! Should NEVER happen !
            return -1;
        }

        // Check comparison between two dates.
        return dateThis.compareTo(datem);
    }
}
