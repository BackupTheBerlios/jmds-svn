package corbaTrace.log2sequenceDiagram.message.filter;

import java.util.*;
import corbaTrace.log2sequenceDiagram.message.MessageOption;
import corbaTrace.log2sequenceDiagram.message.Message;
import corbaTrace.utils.IndentString;

/** It's a class that define some restriction for an attribute (based on its value).
 *
 * @author Antoine Parra del Pozo
 */

public class AttributeFilter {

    private int attributePosition;
    private String attributeValue;
    private String attributeType;


    /**  build an AttributeFilter that filters operations :
      *   1st type of filter : ask to test the value of an attribute of given type.
      */
    public AttributeFilter(String attributeType, String attributeValue) {
        this.attributeType = attributeType;
        this.attributeValue = attributeValue;
        this.attributePosition = -1;
    }

    /**  build an AttributeFilter that filters operations :
      *   2nd type of filter : ask to test the value of the i-th argument of operation
      */
    public AttributeFilter(int attributePosition, String attributeValue) {
        this.attributePosition = attributePosition;
        this.attributeValue = attributeValue;
        this.attributeType = null;
    }

    /** tells whether this message is allowed for that attribute */
    boolean isAllowed (Message m) {
        // gets a list of all attribute for current operation.
        LinkedList lArgs = m.getOperationArguments();
        boolean allowed = false;
        MessageOption argTmp;

        // 1st type of filter
        if (attributeType != null) {
           if (lArgs != null) {
              ListIterator itArg = lArgs.listIterator(0);
              // for each attribute check whether this filter can be applied.
              while (!allowed && itArg.hasNext()) {
                  argTmp = (MessageOption)itArg.next();
                  allowed = attributeType.equals(argTmp.getPropertyValue("type")) && attributeValue.equals(argTmp.getPropertyValue("value"));
              }
           }

        // 2nd type of filter
        } else if ((attributePosition > 0) && (attributePosition <= lArgs.size())) {
             argTmp = (MessageOption)lArgs.get(attributePosition-1);
             allowed = attributeValue.equals(argTmp.getPropertyValue("value"));  // same value ?
        } // else it's an error (wrong number of attribute : we return false.

        return allowed;
    }

    //===========================================================
    // Printing methods.
    //===========================================================
    protected void toString(IndentString s) {
	s.indent();
        if (attributeType != null) {
             s.append("<argumentAt position=\""+attributePosition+"\" value=\""+attributeValue+"\"/>\n");
	} else {
             s.append("<typedArgument type=\""+attributeType+"\" value=\""+attributeValue+"\"/>\n");
	}
    }
}
