package corbaTrace.log2sequenceDiagram.message;
import java.util.*;

public class ObjectMessage {
    String IdObject;
    LinkedList messageList;

    public ObjectMessage() {
        IdObject = new String();
        messageList = new LinkedList();
    }

    public ObjectMessage(String s) {
        IdObject = s;
        messageList = new LinkedList();
    }

    public ObjectMessage(String s, Collection c) {
        IdObject = s;
        messageList = new LinkedList(c);
    }

    public void addMessage(Message m) {
        int i = 0;
        int j = messageList.size();
        while (i < j) {
            int k = m.compareTo((Message) messageList.get(i));
            if (k <= 0) {
                messageList.add(i, m);
                return;
            }
            ++i;
        }
        messageList.add(m);
    }

    public String getIdObject() {
        return this.IdObject;
    }

    public int getNbMessages() {
        return messageList.size();
    }

    public void removeMessage(Message m) {
        messageList.remove(m);
    }

    public int getIndexMessage(Message m) {
        return messageList.indexOf(m);
    }

    public Message getMessage(int i) {
        return ((Message) (messageList.get(i)));
    }

    public ListIterator getMessagesIterator() {
        return (messageList.listIterator(0));
    }

    public boolean contains(Message m) {
        return messageList.contains(m);
    }

    public Object clone() {
        String s = new String(this.getIdObject());
        return new ObjectMessage(s, (Collection) this.messageList.clone());
    }

    public void clear() {
        this.messageList.clear();
    }

    public boolean equals(ObjectMessage o) {
        return this.IdObject.equals(o.getIdObject());
    }

    public int compareToObjectMessage(ObjectMessage o) {
        return this.IdObject.compareTo(o.getIdObject());
    }

    public String toString() {
        StringBuffer s = new StringBuffer();
        ListIterator l = messageList.listIterator();
        while (l.hasNext()) {
            s.append(((Message) l.next()).toString());
        }
        return s.toString();
    }

}
