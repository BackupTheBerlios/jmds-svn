package corbaTrace.xmi2tex;

import javax.xml.parsers.*;
import org.xml.sax.*;
import org.w3c.dom.*;
import javax.xml.transform.*;

import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.*;

import java.io.*;

public class Xmi2tex
{
    // Global value so it can be ref'd by the tree-adapter
    static Document document;

    public Xmi2tex (String texFile)
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setValidating(false);

        File stylesheet= new File("msc.xsl");
        File datafile = new File("out.xmi");
        File outputFile = new File(texFile);

        try {
          DocumentBuilder builder = factory.newDocumentBuilder();
          document = builder.parse(datafile);

          // Use a Transformer for output
          TransformerFactory tFactory =  TransformerFactory.newInstance();
          StreamSource stylesource= new StreamSource(stylesheet);

          Transformer transformer = tFactory.newTransformer(stylesource);

          DOMSource source = new DOMSource(document);
          StreamResult result = new StreamResult(outputFile);
          transformer.transform(source, result);

        }
        catch (TransformerConfigurationException tce) {
          System.out.println("Error: transformer configuration error!");
        }
        catch (TransformerException te) {
          System.out.println("Error: the ouput file could not be created in the specified path!");
        }
        catch (SAXException sxe) {
          System.out.println("Error: the file uml13.dtd must be in the same directory as your XMI file!");

        }
        catch (ParserConfigurationException pce) {
          // Parser with specified options can't be built
          System.out.println("Error: parser configuration error!");
        }
        catch (IOException ioe) {
          System.out.println("Error: the XMI file could not be found in the specified path!");
        }
    }
}
