package corbaTrace.logger;

import corbaTrace.utils.*;
import java.util.Vector;
import java.util.Collection;
import java.util.Iterator;
import java.util.Date;
import java.util.logging.*;

/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Sebastien HELBERT
 */
public class CbtLogRecord extends java.util.logging.LogRecord {
	IndentString out = null;

	private static CbtLogger logger = null;

	private String laDate = null;
	private String mesgId = null;
	private String requestId = null;
	private String mesgType = null;
	private String localObjectId = null;
	private String distantObjectId = null;
	private String distantObjectDate = null;
	private String distantRequestId = null;
	private String operationName = null;
	private Collection arguments = null;
	private String result = null;
	private Collection exceptions = null;
	private String responseExpected = null;
	private String replyStatus = null;
	private String logDetail = null;
	private String sendingException = null;

	public CbtLogRecord(Date date) {
		super(Level.INFO, "");
		laDate = DateUtilities.dateToString(date);
	}

	public CbtLogRecord() {
		this(new Date());
	}

	/* Setters */
	public void setMesgId(int id) {
		mesgId = String.valueOf(id);
	}

	public void setMesgType(String type) {
		mesgType = type;
	}

	public void setLocalObjectId(int id) {
		localObjectId = (new Integer(id)).toString();
	}
	
	public void setLocalObjectId(String id) {
		localObjectId = id;
	}

	public void setDistantDate(String date) {
		distantObjectDate = date;
	}

	public void setRequestId(int id) {
		requestId = String.valueOf(id);
	}
	
	public void setDistantObjectId(int id) {
		distantObjectId = (new Integer(id)).toString();
	}
	
	public void setDistantObjectId(String id) {
		distantObjectId = id;
	}

	public void setDistantRequestId(int id) {
		distantRequestId = String.valueOf(id);
	}

	public void setOperationName(String name) {
		operationName = name;
	}

	public void addArgument(String inout, String value, String type) {
		if(arguments == null) {
			arguments = new Vector();
		}
		
		String[] args = new String[3];
		args[0] = inout;
		args[1] = value;
		args[2] = type;
		arguments.add(args);
	}

	public void setResult(String res) {
		result = res;
	}

	public void setLogDetail(String log) {
		logDetail = log;
	}

	public void setResponseExpected(boolean resp) {
		responseExpected = String.valueOf(resp);
	}

	public void setSendingException(String send) {
		sendingException = send;
	}

	public void addException(String ex) {
		if(exceptions == null) {
			exceptions = new Vector();
		}
		exceptions.add(ex);
	}
	
	public void setReplyStatus(String rep) {
		replyStatus = rep;
	}
	
	/**
	 * Returns the logger.
	 * @return Logger
	 */
	public static CbtLogger getLogger() {
		return logger;
	}

	/**
	 * Returns the arguments.
	 * @return Collection
	 */
	public Collection getArguments() {
		return arguments;
	}

	/**
	 * Returns the distantObjectDate.
	 * @return String
	 */
	public String getDistantObjectDate() {
		return distantObjectDate;
	}

	/**
	 * Returns the distantObjectId.
	 * @return String
	 */
	public String getDistantObjectId() {
		return distantObjectId;
	}

	/**
	 * Returns the distantRequestId.
	 * @return String
	 */
	public String getDistantRequestId() {
		return distantRequestId;
	}

	/**
	 * Returns the exceptions.
	 * @return Collection
	 */
	public Collection getExceptions() {
		return exceptions;
	}

	/**
	 * Returns the laDate.
	 * @return String
	 */
	public String getLaDate() {
		return laDate;
	}

	/**
	 * Returns the localObjectId.
	 * @return String
	 */
	public String getLocalObjectId() {
		return localObjectId;
	}

	/**
	 * Returns the logDetail.
	 * @return String
	 */
	public String getLogDetail() {
		return logDetail;
	}

	/**
	 * Returns the mesgId.
	 * @return String
	 */
	public String getMesgId() {
		return mesgId;
	}

	/**
	 * Returns the mesgType.
	 * @return String
	 */
	public String getMesgType() {
		return mesgType;
	}

	/**
	 * Returns the operationName.
	 * @return String
	 */
	public String getOperationName() {
		return operationName;
	}

	/**
	 * Returns the out.
	 * @return IndentString
	 */
	public IndentString getOut() {
		return out;
	}

	/**
	 * Returns the replyStatus.
	 * @return String
	 */
	public String getReplyStatus() {
		return replyStatus;
	}

	/**
	 * Returns the requestId.
	 * @return String
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * Returns the responseExpected.
	 * @return String
	 */
	public String getResponseExpected() {
		return responseExpected;
	}
	
	/**
	 * Returns the result.
	 * @return String
	 */
	public String getResult() {
		return result;
	}

	/**
	 * Returns the sendingException.
	 * @return String
	 */
	public String getSendingException() {
		return sendingException;
	}

	/**
	 * Sets the laDate.
	 * @param laDate The laDate to set
	 */
	public void setLaDate(String laDate) {
		this.laDate = laDate;
	}

	/**
	 * Method haveOptions.
	 * @return boolean
	 */
	public boolean haveOptions() {
		return (
				exceptions != null ||
				responseExpected !=null ||
				replyStatus != null ||
				sendingException != null
				);
	}

}
