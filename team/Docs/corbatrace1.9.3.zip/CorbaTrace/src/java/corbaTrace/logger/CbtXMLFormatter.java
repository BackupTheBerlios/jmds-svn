package corbaTrace.logger;

import java.util.*;
import java.util.logging.*;
import corbaTrace.utils.*;

public class CbtXMLFormatter extends XMLFormatter {
	private IndentString out;
	private CbtLogRecord record = null;

	public String format(LogRecord rec) {
		out = new IndentString();
		record = (CbtLogRecord) rec;

		out.inc();
		
		/* insert the message type, the date and time. */
		out.openTag("message");
		out.attribute("mesg_id", record.getMesgId());
		if(record.getRequestId() != null) {
			out.attribute("request_id", record.getRequestId());
		}
		out.attribute("type", record.getMesgType());
		out.closeTag();

		/* insert Local Object */
		out.openTag("local_object");
		out.attribute("id", record.getLocalObjectId());
		out.attribute("date", record.getLaDate());
		out.endTag();


		/* insert Distant Object */
		if (record.getDistantObjectId() != null) {
			out.openTag("distant_object");
			out.attribute("id", record.getDistantObjectId());
			if (record.getDistantObjectDate() != null) {
				out.attribute("date", record.getDistantObjectDate());
			}
			if(record.getDistantRequestId() != null) {
				out.attribute("request_id", record.getDistantRequestId());
			}
			out.endTag();
		}

		/* insert the operation */
		if (record.getOperationName() != null) {
			
			out.openTag("operation");
			out.attribute("name", record.getOperationName());
			out.closeTag();
						
			/* insert arguments */
			if(record.getArguments() != null) {
				Iterator it = record.getArguments().iterator();
				while (it.hasNext()) {
					String[] arg = (String[]) it.next();
					out.openTag("argument");
					if (arg[0] != null) {
						out.attribute("inout", arg[0]);
					}
					out.attribute("value", arg[1]);
					out.attribute("type", arg[2]);
					out.endTag();
				}
			}
			out.endTag("operation");
		}

		/* insert result */
		if (record.getResult() != null) {
			out.openTag("result");
			out.attribute("value", record.getResult());
			out.endTag();
		}

		/* insert options */
		if (record.haveOptions()) {
			formatOptions();
		}

		out.endTag("message");
		out.dec();

		return out.toString();
	}

	/**
	  * XMLized call options 
	  */
	private void formatOptions() {
		out.beginTag("options");
	
		/* insert Exception */
		if (record.getExceptions() != null) {
			out.beginTag("exceptions");

			java.util.Iterator iter = record.getExceptions().iterator();
			while (iter.hasNext()) {
				out.beginTag("exception");
				out.insert((String) iter.next());
				out.endTag("exception");
			}
			out.endTag("exceptions");
		}

		/* insert Response Expected */
		if (record.getResponseExpected() != null) {
			out.openTag("responseExpected");
			out.attribute("value", record.getResponseExpected());
			out.endTag();
		}

		/* insert Reply Status */
		if (record.getReplyStatus() != null) {
			out.openTag("reply_status");
			out.attribute("value", record.getReplyStatus());
			out.endTag();
		}

		/* inserts sending informations (for Servers only) */
		if (record.getSendingException() != null) {
			out.beginTag("sending_exception");
			out.insert(record.getSendingException());
			out.endTag("sending_exception");
		}

		/* insert Log Detail */
		if (record.getLogDetail() != null) {
			out.insert(record.getLogDetail());
		}

		out.endTag("options");
	}
}
