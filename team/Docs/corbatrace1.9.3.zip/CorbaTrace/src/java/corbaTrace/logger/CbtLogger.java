package corbaTrace.logger;

/**
 * @author spall
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */

import java.util.logging.*;
import java.util.*;

public class CbtLogger extends Logger {
	
	private static Hashtable names = new Hashtable();
	private static int localMsgId = 0;

	protected CbtLogger(String name, String resourceBundleName) {
		super(name, resourceBundleName);
		
		//set FileHandler to the logger
		try {
			Handler handler = new FileHandler(name + ".xml", false);
			handler.setFormatter(new CbtXMLFormatter());
			this.addHandler(handler);
		} catch (java.io.IOException e) {
			System.err.println("Error : can't create log file \"" + name + ".xml\"");
			e.printStackTrace();
		}
	}

	public static synchronized Logger getLogger(String name) {
		LogManager manager = LogManager.getLogManager();
		Logger result = manager.getLogger(name);
		if (result == null) {
			result = new CbtLogger(name, null);
			manager.addLogger(result);
			result = manager.getLogger(name);
		}
		return result;
	}

	public static void clearNames(){
		names = new Hashtable();
	}

	public static String setName(Object object, String name) {
		String oldName = (String) names.get(object);
		names.put(object, name);
		return oldName;
	}

	public static String getName(Object object) {
		String name = (String) names.get(object);
		if (name == null) {
			return (new Integer(object.hashCode())).toString();
		} else {
			return name;
		}
	}
	
	public static void logCallBegin(String loggerName, Object src, Object dest,	String method, String[] args) {
		CbtLogRecord log = new CbtLogRecord();
		log.setMesgType("localCallBegin");
		log.setLocalObjectId(getName(src));
		log.setDistantObjectId(getName(dest));
		log.setOperationName(method);

		for (int i = 0; i < args.length; i++) {
			log.addArgument(null, args[i], args[i].getClass().toString());
		}
		
		CbtLogger.getLogger(loggerName).log(log);
	}
	
	public static void logCallEnd(String loggerName, Object src, Object dest,
	String method, String result) {
		CbtLogRecord log = new CbtLogRecord();
		log.setMesgType("localCallEnd");
		log.setLocalObjectId(getName(dest));
		log.setDistantObjectId(getName(src));
		log.setOperationName(method);

		log.setResult(result);
		
		CbtLogger.getLogger(loggerName).log(log);
	}
	
	public static void logActivityBegin(String loggerName, Object obj) {
		CbtLogRecord log = new CbtLogRecord();
		log.setMesgType("localActivityBegin");
		log.setLocalObjectId(getName(obj));
		CbtLogger.getLogger(loggerName).log(log);
	}
	
	public static void logActivityEnd(String loggerName, Object obj) {
		CbtLogRecord log = new CbtLogRecord();
		log.setMesgType("localActivityEnd");
		log.setLocalObjectId(getName(obj));
		CbtLogger.getLogger(loggerName).log(log);
	}

	
	public static void logTrace(String loggerName, Object obj, String message) {
		CbtLogRecord log = new CbtLogRecord();
		log.setMesgType("localTrace");
		log.setLocalObjectId(getName(obj));
		log.setOperationName(message);
		CbtLogger.getLogger(loggerName).log(log);
	}
	
	
    /**
     * set a unique message identifier in the record of class CLogRecord
     * before logging it
     * @see java.util.logging.Logger#log(LogRecord)
     */
    public void log(LogRecord record) {
        ((CbtLogRecord) record).setMesgId(localMsgId++);
        super.log(record);
    }

}
