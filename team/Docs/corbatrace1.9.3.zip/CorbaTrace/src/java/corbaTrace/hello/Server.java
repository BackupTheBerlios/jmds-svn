/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace.hello;

import java.io.IOException;

import corbaTrace.InterceptorServer;

import org.omg.PortableServer.POA;
import org.omg.CORBA.ORB;

/**
 * Test file
 * The Server Side
 * @author Etienne Juliot
 * @version 0.1
 */
public class Server {

    static InterceptorServer interceptorServer;

    public static void main(String args[]) {
        interceptorServer = new InterceptorServer();

        java.util.Properties props = System.getProperties();
        props.put("org.omg.CORBA.ORBClass", "com.ooc.CORBA.ORB");
        props.put("org.omg.CORBA.ORBSingletonClass", "com.ooc.CORBA.ORBSingleton");

        org.omg.CORBA.Object obj = null;
        POA poa_interceptor = null;
        ORB orb = null;

        try {
            // Initialize the ORB
            orb = org.omg.CORBA.ORB.init(args, props);

            // Resolve Root POA
            obj = orb.resolve_initial_references("RootPOA");

            POA rootPOA = org.omg.PortableServer.POAHelper.narrow(obj);

            // Create default POA with or without logging policy (according to the logging level)
            poa_interceptor = interceptorServer.create_poa(orb, rootPOA, "monHelloPOA");
        } catch (org.omg.CORBA.BAD_PARAM ex) {
            throw new RuntimeException();
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(1);
        }

        runHello(orb, poa_interceptor);

        System.out.println("Server launching ...");
        orb.run();
        System.out.println("Server closing ...");
        orb.destroy();
    }

    private static void runHello(ORB orb, POA poa) {
        String message = new String("Hello");

        org.omg.CORBA.Object obj = null;

        try {
            Hello_impl helloImpl = new Hello_impl();

            obj = interceptorServer.activate_object(poa, helloImpl, message);
            Hello hello = HelloHelper.narrow(obj);
            writeObjectToFile(orb, hello, "Hello.ref");
            //interceptorServer.activate_POA(poa);

        } catch (org.omg.PortableServer.POAManagerPackage.AdapterInactive e) {
            e.printStackTrace();
            System.exit(1);
        } catch (org.omg.CORBA.UserException ex) {
            System.out.println("Object Hello_impl not activated");
            ex.printStackTrace();
            System.exit(1);
        }
    }

    private static void runHello(ORB orb) {
        Hello_impl helloImpl = new Hello_impl();
        Hello hello = helloImpl._this(orb);
        writeObjectToFile(orb, hello, "Hello.ref");
    }

    private static void writeObjectToFile(ORB orb, org.omg.CORBA.Object myObject, String filename) {
        try {
            String ref = orb.object_to_string(myObject);
            java.io.PrintWriter out = new java.io.PrintWriter(new java.io.FileOutputStream(filename));
            out.println(ref);
            out.close();
        } catch (IOException e) {
            System.out.println("No ref write");
        }
    }

}
