/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace.hello;

/**
 * Test file<br/>
 * A servant object file which just say : <code>Ask Hello World! Mr. "name"</code> and return "Hello World!"
 * @author Etienne Juliot
 * @version 0.1
 */
public class Hello_impl extends HelloPOA { 

    /**
     * The test operation
     * @param A name (just for test argument in logs)
     * @return "Hello World!"
     */
    public String say_hello(String name) { 
	System.out.println("Ask Hello World! Mr. " + name);
	return("Hello World!");
    }
}
