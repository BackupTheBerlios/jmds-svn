/**
 * This file is a part of the project : CorbaTrace
 *
 * It's under LGPL licence.
 * @author Etienne Juliot
 */

package corbaTrace.hello;

import java.util.*;
import java.io.*;
import org.omg.CORBA.*;
import corbaTrace.interceptorCore.*;
import corbaTrace.logger.*;


import corbaTrace.InterceptorClient;

/**
 * Test file
 * The Client Side
 * @author Etienne Juliot
 * @version 0.1
 */
public class Client { 

    static InterceptorClient interceptorClient;

    public static void main(String args[]) {

	interceptorClient = new InterceptorClient();


	Properties props = System.getProperties(); 
	props.put("org.omg.CORBA.ORBClass", "com.ooc.CORBA.ORB"); 
	props.put("org.omg.CORBA.ORBSingletonClass", "com.ooc.CORBA.ORBSingleton");
	
	int status = 0;
	org.omg.CORBA.ORB orb = null;
	try {
	    orb = org.omg.CORBA.ORB.init(args, props); 
	    status = run(orb);
	} 
	catch(Exception ex) { 
	    ex.printStackTrace(); 
	    status = 1;
	}

	if(orb != null) {
	    try { 
		orb.destroy();
	    }  
	    catch(Exception ex) { 
		ex.printStackTrace(); 
		status = 1; 
	    }
	} 
	System.exit(status);
    }

    static int run(ORB orb) {
		String loggerName = new String("helloClient");
		
		org.omg.CORBA.Object obj = null; 
		try { 
		    String refFile = "Hello.ref"; 
		    BufferedReader in = new BufferedReader(new FileReader(refFile)); 
		    String ref = in.readLine();
		    obj = orb.string_to_object(ref); 
		} 
		catch(IOException ex) { 
		    ex.printStackTrace(); 
		    return 1; 
		}
	
		String emitter = "f";
		obj = interceptorClient.active_interception(obj, orb);
		interceptorClient.activate_log(loggerName, orb);	
	
		try {
			
		    Hello hello = HelloHelper.narrow(obj); 

			CbtLogger.setName(emitter, "emitter");
			CbtLogger.setName(System.out, "System.out"); 	
    	   
		    String[] params = {"arg1", "arg2"};
			CbtLogger.logTrace(loggerName, emitter, "bonjour");
			CbtLogger.logTrace(loggerName, emitter, "bonjour2");
			java.lang.Thread.sleep(2000);
			CbtLogger.logCallBegin(loggerName, emitter, System.out, "println", params);
			java.lang.Thread.sleep(200);
			CbtLogger.logActivityBegin(loggerName, emitter);
			CbtLogger.logCallEnd(loggerName, emitter, System.out, "println", "ok");
			java.lang.Thread.sleep(200);
			CbtLogger.logActivityEnd(loggerName, emitter);
			java.lang.Thread.sleep(200);
			CbtLogger.logActivityBegin(loggerName, emitter);			
			java.lang.Thread.sleep(200);
			CbtLogger.logActivityEnd(loggerName, emitter);
			
			
		    System.out.println("Receive : " + hello.say_hello("Test1"));
		    System.out.println("Receive3 : " + hello.say_hello("Test2"));
		} catch(Exception e) {
		    System.err.println("Cannot connect to server");
		    e.printStackTrace(); 
		    return -1;
		}
		
		return 0; 
    } 
}
